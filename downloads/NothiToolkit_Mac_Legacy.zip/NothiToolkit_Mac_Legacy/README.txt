NOTHI TOOLKIT 1.9 (beta)
Free all-in-one panel for After Effects 2019, 2020 and 2021.
By Nothi Labs. Guide with pictures and updates: https://nothilabs.com

INSTALL
  1. Double-click the zip to unzip it.
  2. Right-click "Install Nothi Toolkit.command" > Open > Open.
     If macOS blocks it: System Settings > Privacy & Security > scroll down > Open Anyway.
  No luck? Paste this in Terminal, then drag the com.nothi.toolkit folder into
  ~/Library/Application Support/Adobe/CEP/extensions/ :
     for v in 9 10 11 12 13; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done

OPEN THE PANEL
  Restart After Effects, then: Window > Extensions > Nothi Toolkit.
  Dock it where you like, then save your workspace
  (Window > Workspace > Save as New Workspace) so it opens every time.

TOOLS (one icon per tool at the top)
  Create    One-click text, adjustment, solid, null, shape, camera, light.
            In a tall window it also holds the layer tools and copy style.
  Curves    Draw an ease on the graph (scroll to zoom), save your own, apply.
  Beat      Finds the bass hits of a song: markers, snap, sequence or cut clips on beats.
  Captions  Auto captions from speech (runs on your computer, nothing is uploaded).
            Split text into words, lines or letters, each on its own layer.
  Layers    Anchor point, precompose, decompose, duplicate precomp, sequence, rename.
  Style     Copy the look and animation of a layer, paste it on others.

  Search every action: Ctrl+K (Cmd+K on Mac) while the panel is focused.

AUTO CAPTIONS
  The first time, the panel downloads the speech model (142 MB, once) from
  Hugging Face. After that it works offline. Transcription by whisper.cpp
  (MIT license, see com.nothi.toolkit/bin/LICENSE-whisper.cpp.txt).
  The sound of videos is read with FFmpeg (LGPL, see bin/LICENSE-ffmpeg.txt).

UPDATE
  When a new version is out, an "Update" button appears in the panel.
  Click it: the right zip downloads. Close After Effects, run the installer again.
  It replaces the old version by itself. Your settings stay.

TERMS & PRIVACY
  See "Terms of use.txt" and https://nothilabs.com/legal
  Contact: nothicontact@gmail.com

UNINSTALL
  Open Uninstall.command, or delete ~/Library/Application Support/Adobe/CEP/extensions/com.nothi.toolkit
