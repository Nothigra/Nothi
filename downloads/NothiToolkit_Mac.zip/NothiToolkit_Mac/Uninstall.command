#!/bin/bash
rm -rf "$HOME/Library/Application Support/Adobe/CEP/extensions/com.nothi.toolkit"
echo "Nothi Toolkit removed. You can close this window."
