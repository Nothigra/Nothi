#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions/com.nothi.toolkit"
echo "Installing Nothi Toolkit..."
for v in 9 10 11 12 13; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
rm -rf "$DEST"; mkdir -p "$(dirname "$DEST")"
cp -R "$DIR/com.nothi.toolkit" "$DEST" && xattr -dr com.apple.quarantine "$DEST" 2>/dev/null
chmod +x "$DEST/bin/mac/whisper-cli" 2>/dev/null
echo ""
echo "Done. Restart After Effects, then open Window > Extensions > Nothi Toolkit"
echo "You can close this window."
