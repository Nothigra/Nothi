NOTHI TOOLKIT 1.4 (beta)
Free all-in-one panel for After Effects 2022 and newer.
By Nothi Labs. Guide with pictures and updates: https://nothilabs.com

INSTALL
  1. Right-click the zip > Extract All (the installer can't run from inside the zip).
  2. Double-click "Install Nothi Toolkit.bat".
     If Windows says "Windows protected your PC": More info > Run anyway.

OPEN THE PANEL
  Restart After Effects, then: Window > Extensions > Nothi Toolkit.
  Dock it where you like, then save your workspace
  (Window > Workspace > Save as New Workspace) so it opens every time.

TOOLS (one icon per tool at the top)
  Create   One-click text, adjustment, solid, null, shape, camera, light.
  Curves   8 eases + save your own from selected keyframes.
  Beat     Drop an audio layer: beats on the visible part only, markers,
           click the waveform to listen, snap or sequence layers on beats.
  Layers   Anchor point (layer stays in place), precompose, decompose, rename.
  Style    Copy the look of a layer, paste it on others.
  Effects  Favorites in one click (Alt+click: on a new adjustment layer).

  Search every action: Ctrl+K (Cmd+K on Mac) while the panel is focused.
  Change the shortcut in the "..." menu. Undo: button in the status bar or Ctrl/Cmd+Z.

UPDATE
  When a new version is out, an "Update" button appears in the panel.
  Download the new zip, close After Effects, run the installer again.
  It replaces the old version by itself.

TERMS & PRIVACY
  See "Terms of use.txt" and https://nothilabs.com/legal
  Contact: nothicontact@gmail.com

UNINSTALL
  Double-click Uninstall.bat, or delete %APPDATA%\Adobe\CEP\extensions\com.nothi.toolkit
