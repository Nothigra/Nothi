/*  Nothi Toolkit — After Effects side (ExtendScript, ES3).
    Every public function returns a JSON string: { ok: true, ... } or { ok: false, error: "..." }.
    Each action is wrapped in its own undo group, so Ctrl/Cmd+Z undoes it in one step. */

// ───────────────────────── JSON (ExtendScript has no native JSON)
function nt_json(v) {
  var t = typeof v;
  if (v === null || t === 'undefined') return 'null';
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') {
    return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
  }
  if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(nt_json(v[i])); return '[' + a.join(',') + ']'; }
  var o = []; for (var k in v) { if (v.hasOwnProperty(k)) o.push(nt_json(String(k)) + ':' + nt_json(v[k])); }
  return '{' + o.join(',') + '}';
}
function nt_ok(o) { o = o || {}; o.ok = true; return nt_json(o); }
function nt_err(msg) { return nt_json({ ok: false, error: msg }); }
function nt_comp() { var c = app.project && app.project.activeItem; return (c && c instanceof CompItem) ? c : null; }
function nt_run(name, fn) {
  var comp = nt_comp();
  if (!comp) return nt_err('NO_COMP');
  app.beginUndoGroup('Nothi: ' + name);
  try { var r = fn(comp); app.endUndoGroup(); return r; }
  catch (e) { app.endUndoGroup(); return nt_err(String(e.message || e)); }
}

// ───────────────────────── context (polled by the panel)
function nt_context() {
  var c = nt_comp();
  if (!c) return nt_ok({ comp: null });
  var sel = c.selectedLayers, names = [];
  for (var i = 0; i < sel.length && i < 3; i++) names.push(sel[i].name);
  return nt_ok({ comp: c.name, w: c.width, h: c.height, fps: Math.round(c.frameRate * 100) / 100, selected: sel.length, names: names });
}

// ───────────────────────── CREATE
function nt_create(type, opts) {
  opts = opts || {};
  return nt_run('Add ' + type, function (comp) {
    var sel = comp.selectedLayers, ref = sel.length ? sel[0] : null;
    var w = comp.width, h = comp.height, d = comp.duration, l;
    var col = opts.color || [0.55, 0.48, 1];
    if (type === 'text') {
      l = comp.layers.addText(opts.text || 'Your text');
      var td = l.property('Source Text').value;
      td.fontSize = Math.round(h / 9); td.fillColor = [1, 1, 1]; td.justification = ParagraphJustification.CENTER_JUSTIFY;
      l.property('Source Text').setValue(td);
      var r = l.sourceRectAtTime(comp.time, false);
      l.property('Anchor Point').setValue([r.left + r.width / 2, r.top + r.height / 2]);
      l.property('Position').setValue([w / 2, h / 2]);
    } else if (type === 'adjustment') {
      l = comp.layers.addSolid([1, 1, 1], opts.name || 'Adjustment Layer', w, h, comp.pixelAspect, d);
      l.adjustmentLayer = true; l.label = 5;
    } else if (type === 'solid') {
      l = comp.layers.addSolid(col, opts.name || 'Solid', w, h, comp.pixelAspect, d);
    } else if (type === 'null') {
      l = comp.layers.addNull(d); l.name = opts.name || 'Control';
      l.property('Position').setValue([w / 2, h / 2]);
    } else if (type === 'camera') {
      l = comp.layers.addCamera(opts.name || 'Camera', [w / 2, h / 2]);
    } else if (type === 'light') {
      l = comp.layers.addLight(opts.name || 'Light', [w / 2, h / 2]);
    } else if (type === 'shape') {
      l = comp.layers.addShape(); l.name = opts.name || 'Shape';
      var grp = l.property('Contents').addProperty('ADBE Vector Group');
      var rect = grp.property('Contents').addProperty('ADBE Vector Shape - Rect');
      rect.property('Size').setValue([Math.round(w / 3), Math.round(h / 3)]);
      rect.property('Roundness').setValue(Math.round(h / 40));
      var fill = grp.property('Contents').addProperty('ADBE Vector Graphic - Fill');
      fill.property('Color').setValue(col);
      l.property('Position').setValue([w / 2, h / 2]);
    } else return nt_err('UNKNOWN_TYPE');
    if (opts.name && type !== 'null' && type !== 'shape') try { l.name = opts.name; } catch (e1) {}
    if (ref) {
      l.moveBefore(ref);
      if (opts.matchDuration) { l.inPoint = Math.max(0, ref.inPoint); l.outPoint = ref.outPoint; }
    } else if (opts.fromPlayhead) { l.inPoint = comp.time; }
    for (var i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
    l.selected = true;
    return nt_ok({ name: l.name });
  });
}

// ───────────────────────── CURVES (temporal ease, stored as ratios of the average speed)
function nt_isEaseable(p) { return p && p.propertyType === PropertyType.PROPERTY && p.numKeys > 1 && p.propertyValueType !== PropertyValueType.NO_VALUE && p.propertyValueType !== PropertyValueType.CUSTOM_VALUE && p.propertyValueType !== PropertyValueType.SHAPE && p.propertyValueType !== PropertyValueType.TEXT_DOCUMENT && p.propertyValueType !== PropertyValueType.MARKER; }
function nt_avgSpeeds(p, k) { // per-dimension average speed between key k and k+1
  var v1 = p.keyValue(k), v2 = p.keyValue(k + 1), dt = p.keyTime(k + 1) - p.keyTime(k);
  if (dt <= 0) dt = 1e-6;
  var spatial = p.isSpatial;
  if (!(v1 instanceof Array)) return [Math.abs(v2 - v1) / dt];
  if (spatial) { var s = 0; for (var i = 0; i < v1.length; i++) s += (v2[i] - v1[i]) * (v2[i] - v1[i]); return [Math.sqrt(s) / dt]; }
  var out = []; for (var j = 0; j < v1.length; j++) out.push(Math.abs(v2[j] - v1[j]) / dt); return out;
}
function nt_selectedPairs(comp) {
  var props = comp.selectedProperties, pairs = [];
  for (var i = 0; i < props.length; i++) {
    var p = props[i]; if (!nt_isEaseable(p)) continue;
    var keys = p.selectedKeys; if (!keys || keys.length === 0) continue;
    if (keys.length === 1) { if (keys[0] < p.numKeys) pairs.push([p, keys[0]]); continue; }
    for (var k = 0; k < keys.length - 1; k++) pairs.push([p, keys[k]]);
  }
  return pairs;
}
function nt_curveRead() {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var pairs = nt_selectedPairs(comp);
  if (!pairs.length) return nt_err('NO_KEYS');
  var p = pairs[0][0], k = pairs[0][1];
  var avg = nt_avgSpeeds(p, k)[0] || 1e-6;
  var o = p.keyOutTemporalEase(k)[0], n = p.keyInTemporalEase(k + 1)[0];
  return nt_ok({ curve: { outInf: o.influence, inInf: n.influence, outRatio: Math.abs(o.speed) / avg, inRatio: Math.abs(n.speed) / avg }, prop: p.name });
}
function nt_curveApply(c) {
  return nt_run('Apply curve', function (comp) {
    var pairs = nt_selectedPairs(comp);
    if (!pairs.length) return nt_err('NO_KEYS');
    var done = 0;
    for (var i = 0; i < pairs.length; i++) {
      var p = pairs[i][0], k = pairs[i][1];
      var avg = nt_avgSpeeds(p, k), dims = p.keyOutTemporalEase(k).length;
      var outE = [], inE = [];
      for (var d = 0; d < dims; d++) {
        var a = avg[Math.min(d, avg.length - 1)];
        outE.push(new KeyframeEase(c.outRatio * a, Math.max(0.1, Math.min(100, c.outInf))));
        inE.push(new KeyframeEase(c.inRatio * a, Math.max(0.1, Math.min(100, c.inInf))));
      }
      p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), KeyframeInterpolationType.BEZIER);
      p.setInterpolationTypeAtKey(k + 1, KeyframeInterpolationType.BEZIER, p.keyOutInterpolationType(k + 1));
      p.setTemporalEaseAtKey(k, p.keyInTemporalEase(k), outE);
      p.setTemporalEaseAtKey(k + 1, inE, p.keyOutTemporalEase(k + 1));
      done++;
    }
    return nt_ok({ count: done });
  });
}

// ───────────────────────── BEAT
function nt_audioInfo() {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var sel = comp.selectedLayers, l = null;
  for (var i = 0; i < sel.length; i++) if (sel[i].hasAudio && sel[i].source && sel[i].source.file) { l = sel[i]; break; }
  if (!l) return nt_err('NO_AUDIO');
  return nt_ok({ path: l.source.file.fsName, name: l.name, index: l.index, startTime: l.startTime, inPoint: l.inPoint, outPoint: l.outPoint, stretch: l.stretch, timeRemap: l.timeRemapEnabled, compDuration: comp.duration, workStart: comp.workAreaStart, workEnd: comp.workAreaStart + comp.workAreaDuration });
}
function nt_beatMarkers(index, times, target, label) {
  return nt_run('Beat markers', function (comp) {
    var l = comp.layer(index), mk = (target === 'comp') ? comp.markerProperty : l.property('Marker');
    var n = 0;
    for (var i = 0; i < times.length; i++) {
      var mv = new MarkerValue(label ? String(i + 1) : '');
      mv.label = 7;
      mk.setValueAtTime(times[i], mv); n++;
    }
    return nt_ok({ count: n });
  });
}
function nt_clearMarkers(index, target) {
  return nt_run('Clear markers', function (comp) {
    var mk = (target === 'comp') ? comp.markerProperty : comp.layer(index).property('Marker');
    var n = mk.numKeys; for (var i = n; i >= 1; i--) mk.removeKey(i);
    return nt_ok({ count: n });
  });
}

// ───────────────────────── ANCHOR (moves the anchor, the layer stays in place)
function nt_anchor(ax, ay) {
  return nt_run('Anchor point', function (comp) {
    var sel = comp.selectedLayers, n = 0, skipped = 0;
    for (var i = 0; i < sel.length; i++) {
      var l = sel[i];
      if (l instanceof CameraLayer || l instanceof LightLayer) { skipped++; continue; }
      var ap = l.property('ADBE Transform Group').property('ADBE Anchor Point');
      if (ap.numKeys > 0) { skipped++; continue; }
      var r = l.sourceRectAtTime(comp.time, false);
      var oldA = ap.value, newA = [r.left + r.width * ax, r.top + r.height * ay];
      var dx = newA[0] - oldA[0], dy = newA[1] - oldA[1];
      var sc = l.property('ADBE Transform Group').property('ADBE Scale').valueAtTime(comp.time, false);
      var rotP = l.threeDLayer ? l.property('ADBE Transform Group').property('ADBE Rotate Z') : l.property('ADBE Transform Group').property('ADBE Rotate Z');
      var rot = (rotP ? rotP.valueAtTime(comp.time, false) : 0) * Math.PI / 180;
      var sx = sc[0] / 100, sy = sc[1] / 100;
      var px = dx * sx * Math.cos(rot) - dy * sy * Math.sin(rot);
      var py = dx * sx * Math.sin(rot) + dy * sy * Math.cos(rot);
      var pos = l.property('ADBE Transform Group').property('ADBE Position');
      if (pos.dimensionsSeparated) {
        var X = l.property('ADBE Transform Group').property('ADBE Position_0'), Y = l.property('ADBE Transform Group').property('ADBE Position_1');
        nt_offset(X, px); nt_offset(Y, py);
      } else nt_offsetVec(pos, px, py);
      ap.setValue(l.threeDLayer ? [newA[0], newA[1], oldA[2] || 0] : [newA[0], newA[1]]);
      n++;
    }
    return nt_ok({ count: n, skipped: skipped });
  });
}
function nt_offset(p, d) { if (p.numKeys) { for (var k = 1; k <= p.numKeys; k++) p.setValueAtKey(k, p.keyValue(k) + d); } else p.setValue(p.value + d); }
function nt_offsetVec(p, dx, dy) {
  var f = function (v) { var o = [v[0] + dx, v[1] + dy]; if (v.length > 2) o.push(v[2]); return o; };
  if (p.numKeys) { for (var k = 1; k <= p.numKeys; k++) p.setValueAtKey(k, f(p.keyValue(k))); } else p.setValue(f(p.value));
}

// ───────────────────────── PRECOMPOSE SMART
function nt_precompose(name, trim) {
  return nt_run('Smart precompose', function (comp) {
    var sel = comp.selectedLayers; if (!sel.length) return nt_err('NO_SELECTION');
    var idx = [], minIn = 1e9, maxOut = -1e9, top = sel[0];
    for (var i = 0; i < sel.length; i++) { idx.push(sel[i].index); minIn = Math.min(minIn, sel[i].inPoint); maxOut = Math.max(maxOut, sel[i].outPoint); if (sel[i].index < top.index) top = sel[i]; }
    var label = top.label;
    var nm = name || (sel.length === 1 ? sel[0].name : top.name + ' +' + (sel.length - 1));
    var nc = comp.layers.precompose(idx, nm, true);
    var pl = null; for (var j = 1; j <= comp.numLayers; j++) if (comp.layer(j).source === nc) { pl = comp.layer(j); break; }
    if (trim && pl && maxOut > minIn) {
      for (var k = 1; k <= nc.numLayers; k++) { var L = nc.layer(k); var locked = L.locked; L.locked = false; L.startTime -= minIn; L.locked = locked; }
      nc.duration = maxOut - minIn;
      pl.startTime = minIn;
    }
    if (pl) { pl.label = label; pl.name = nm; }
    return nt_ok({ name: nm, duration: nc.duration });
  });
}

// ───────────────────────── DECOMPOSE (bring the layers of a precomp back into this comp)
function nt_isIdentity(l, inner, comp) {
  var tr = l.property('ADBE Transform Group');
  var a = tr.property('ADBE Anchor Point').value, p = tr.property('ADBE Position').value, s = tr.property('ADBE Scale').value, r = tr.property('ADBE Rotate Z').value;
  var animated = tr.property('ADBE Position').numKeys || tr.property('ADBE Scale').numKeys || tr.property('ADBE Rotate Z').numKeys || tr.property('ADBE Anchor Point').numKeys;
  return !animated && !l.parent && !l.threeDLayer && Math.abs(a[0] - p[0]) < 0.01 && Math.abs(a[1] - p[1]) < 0.01 && Math.abs(s[0] - 100) < 0.01 && Math.abs(s[1] - 100) < 0.01 && Math.abs(r) < 0.01 && inner.width === comp.width && inner.height === comp.height;
}
function nt_decompose(removeItem) {
  return nt_run('Decompose', function (comp) {
    var sel = comp.selectedLayers, l = null;
    for (var i = 0; i < sel.length; i++) if (sel[i].source instanceof CompItem) { l = sel[i]; break; }
    if (!l) return nt_err('NO_PRECOMP');
    var inner = l.source, offset = l.startTime, lost = [];
    if (l.timeRemapEnabled) lost.push('time remap');
    if (l.stretch !== 100) lost.push('time stretch');
    if (l.property('ADBE Effect Parade').numProperties) lost.push('effects');
    if (l.property('ADBE Mask Parade').numProperties) lost.push('masks');
    if (l.property('ADBE Transform Group').property('ADBE Opacity').value !== 100) lost.push('opacity');
    // a null that carries the precomp layer's transform, so everything stays exactly where it was
    var holder = null;
    if (!nt_isIdentity(l, inner, comp)) {
      holder = comp.layers.addNull(comp.duration);
      holder.name = l.name + ' (transform)';
      holder.threeDLayer = l.threeDLayer;
      var src = l.property('ADBE Transform Group'), dst = holder.property('ADBE Transform Group');
      var names = ['ADBE Anchor Point', 'ADBE Position', 'ADBE Scale', 'ADBE Rotate Z'];
      for (var n = 0; n < names.length; n++) {
        var sp = src.property(names[n]), dp = dst.property(names[n]);
        if (sp.numKeys) { for (var k = 1; k <= sp.numKeys; k++) dp.setValueAtTime(sp.keyTime(k), sp.keyValue(k)); }
        else dp.setValue(sp.value);
      }
      if (l.parent) holder.setParentWithJump(l.parent);
      holder.inPoint = l.inPoint; holder.outPoint = l.outPoint;
    }
    var copies = [];
    for (var j = inner.numLayers; j >= 1; j--) { inner.layer(j).copyToComp(comp); copies.unshift(comp.layer(1)); }
    for (var c = 0; c < copies.length; c++) {
      var L = copies[c];
      L.moveBefore(l);
      L.startTime += offset;
      try { if (L.inPoint < l.inPoint) L.inPoint = l.inPoint; if (L.outPoint > l.outPoint) L.outPoint = l.outPoint; } catch (e1) {}
      if (holder && !L.parent) L.setParentWithJump(holder);
    }
    if (holder) holder.moveBefore(copies[0]);
    var nm = l.name;
    l.remove();
    var deleted = false;
    if (removeItem && inner.usedIn.length === 0) { inner.remove(); deleted = true; }
    return nt_ok({ name: nm, count: copies.length, lost: lost, deleted: deleted, holder: !!holder });
  });
}

// ───────────────────────── SMART RENAME
function nt_kind(l) {
  if (l instanceof CameraLayer) return 'CAM';
  if (l instanceof LightLayer) return 'LIGHT';
  if (l instanceof TextLayer) return 'TXT';
  if (l instanceof ShapeLayer) return 'SHAPE';
  if (l.nullLayer) return 'NULL';
  if (l.adjustmentLayer) return 'ADJ';
  var s = l.source;
  if (s instanceof CompItem) return 'COMP';
  if (s && s.mainSource instanceof SolidSource) return 'SOLID';
  if (s && s.mainSource && s.mainSource.isStill) return 'IMG';
  if (s && !s.hasVideo && s.hasAudio) return 'AUDIO';
  return 'VID';
}
function nt_desc(l, kind) {
  try {
    if (kind === 'TXT') { var t = String(l.property('Source Text').value.text).replace(/[\r\n]+/g, ' '); return t.length > 26 ? t.substr(0, 25) + '…' : t; }
    if (kind === 'ADJ') { var fx = l.property('ADBE Effect Parade'); return fx.numProperties ? fx.property(1).name : 'Adjustment'; }
    if (kind === 'SHAPE') { var c = l.property('Contents'); return c.numProperties ? c.property(1).name : 'Shape'; }
    if (kind === 'COMP') return l.source.name;
    if (kind === 'SOLID') return l.source.name;
    if (kind === 'IMG' || kind === 'VID' || kind === 'AUDIO') { var f = l.source.file ? l.source.file.name : l.source.name; return decodeURI(f).replace(/\.[^.]+$/, ''); }
    if (kind === 'NULL') return 'Control';
    if (kind === 'CAM') return 'Camera';
    if (kind === 'LIGHT') return 'Light';
  } catch (e) {}
  return l.name;
}
function nt_rename(scope, tags) {
  return nt_run('Smart rename', function (comp) {
    var list = [];
    if (scope === 'all') { for (var i = 1; i <= comp.numLayers; i++) list.push(comp.layer(i)); } else list = comp.selectedLayers;
    if (!list.length) return nt_err('NO_SELECTION');
    var seen = {}, out = [];
    for (var j = 0; j < list.length; j++) {
      var l = list[j], kind = nt_kind(l), d = nt_desc(l, kind);
      var nm = tags ? kind + ' – ' + d : d;
      var base = nm, n = 2; while (seen[nm]) nm = base + ' ' + (n++); seen[nm] = true;
      var locked = l.locked; l.locked = false; l.name = nm; l.locked = locked;
      if (out.length < 6) out.push(nm);
    }
    return nt_ok({ count: list.length, sample: out });
  });
}

// ───────────────────────── STYLE COPY / PASTE
$.global.nt_style = $.global.nt_style || null;
// Keyframes are stored with their full speed graph (interpolation, ease speed + influence, tangents),
// so a pasted animation moves exactly like the original.
function nt_readKeys(p) {
  var ks = [], spatial = false;
  try { spatial = p.isSpatial; } catch (e0) {}
  for (var k = 1; k <= p.numKeys; k++) {
    var e = { t: p.keyTime(k), v: p.keyValue(k) };
    try { e.ii = p.keyInInterpolationType(k); e.oi = p.keyOutInterpolationType(k); } catch (e1) {}
    try {
      var ie = p.keyInTemporalEase(k), oe = p.keyOutTemporalEase(k); e.ie = []; e.oe = [];
      for (var d = 0; d < ie.length; d++) { e.ie.push([ie[d].speed, ie[d].influence]); e.oe.push([oe[d].speed, oe[d].influence]); }
    } catch (e2) {}
    try { e.tc = p.keyTemporalContinuous(k); e.ab = p.keyTemporalAutoBezier(k); } catch (e3) {}
    if (spatial) { try { e.si = p.keyInSpatialTangent(k); e.so = p.keyOutSpatialTangent(k); e.sc = p.keySpatialContinuous(k); e.sab = p.keySpatialAutoBezier(k); } catch (e4) {} }
    ks.push(e);
  }
  return ks;
}
// map: { a: source in, b: target in, k: time scale }. Speeds are divided by k so the graph keeps its shape.
function nt_writeKeys(p, ks, map) {
  var times = [], vals = [], i;
  for (i = 0; i < ks.length; i++) { times.push(map.b + (ks[i].t - map.a) * map.k); vals.push(ks[i].v); }
  p.setValuesAtTimes(times, vals);
  for (i = 0; i < ks.length; i++) {
    var e = ks[i], key = p.nearestKeyIndex(times[i]);
    try { if (e.ii !== undefined) p.setInterpolationTypeAtKey(key, e.ii, e.oi); } catch (x1) {}
    try { if (e.tc !== undefined) { p.setTemporalContinuousAtKey(key, e.tc); p.setTemporalAutoBezierAtKey(key, e.ab); } } catch (x2) {}
    if (e.ie && !e.ab) {
      try {
        var inE = [], outE = [];
        for (var d = 0; d < e.ie.length; d++) { inE.push(new KeyframeEase(e.ie[d][0] / map.k, e.ie[d][1])); outE.push(new KeyframeEase(e.oe[d][0] / map.k, e.oe[d][1])); }
        p.setTemporalEaseAtKey(key, inE, outE);
      } catch (x3) {}
    }
    if (e.si) { try { p.setSpatialTangentsAtKey(key, e.si, e.so); p.setSpatialContinuousAtKey(key, e.sc); p.setSpatialAutoBezierAtKey(key, e.sab); } catch (x4) {} }
  }
}
function nt_readProps(group, withKeys) {
  var out = [];
  for (var i = 1; i <= group.numProperties; i++) {
    var p = group.property(i), e = { i: i };
    if (p.propertyType === PropertyType.PROPERTY) {
      var vt = p.propertyValueType;
      if (vt === PropertyValueType.NO_VALUE || vt === PropertyValueType.CUSTOM_VALUE || vt === PropertyValueType.LAYER_INDEX || vt === PropertyValueType.MASK_INDEX) continue;
      try { e.v = p.value; } catch (x) { continue; }
      if (p.canSetExpression && p.expressionEnabled && p.expression) e.x = p.expression;
      if (withKeys && p.numKeys > 0) { e.k = nt_readKeys(p); $.global.nt_keyCount = ($.global.nt_keyCount || 0) + p.numKeys; }
      out.push(e);
    } else { e.g = nt_readProps(p, withKeys); if (e.g.length) out.push(e); }
  }
  return out;
}
function nt_writeProps(group, list, map) {
  for (var i = 0; i < list.length; i++) {
    var e = list[i], p; try { p = group.property(e.i); } catch (x) { continue; }
    if (!p) continue;
    if (e.g) { nt_writeProps(p, e.g, map); continue; }
    try {
      while (p.numKeys) p.removeKey(1);
      if (e.k && map) nt_writeKeys(p, e.k, map);
      else p.setValue(e.v);
      if (e.x) p.expression = e.x;
    } catch (y) {}
  }
}
function nt_styleCopy(withKeys) {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var l = comp.selectedLayers[0]; if (!l) return nt_err('NO_SELECTION');
  $.global.nt_keyCount = 0;
  var fxGroup = l.property('ADBE Effect Parade'), fx = [];
  for (var i = 1; i <= fxGroup.numProperties; i++) { var f = fxGroup.property(i); fx.push({ match: f.matchName, name: f.name, props: nt_readProps(f, withKeys) }); }
  var tr = l.property('ADBE Transform Group');
  $.global.nt_style = {
    layer: l.name, inPoint: l.inPoint, duration: l.outPoint - l.inPoint, keys: $.global.nt_keyCount, effects: fx,
    opacity: tr.property('ADBE Opacity').value, scale: tr.property('ADBE Scale').value, rotation: tr.property('ADBE Rotate Z').value,
    blend: l.blendingMode, motionBlur: l.motionBlur, threeD: l.threeDLayer
  };
  var names = []; for (var j = 0; j < fx.length; j++) names.push(fx[j].name);
  return nt_ok({ layer: l.name, effects: names, keys: $.global.nt_keyCount, duration: l.outPoint - l.inPoint });
}
// o.timing: 'shift' keeps the original timing from the clip's start; 'fit' stretches it to each clip's length.
function nt_stylePaste(o) {
  var s = $.global.nt_style; if (!s) return nt_err('NO_STYLE');
  return nt_run('Paste style', function (comp) {
    var sel = comp.selectedLayers; if (!sel.length) return nt_err('NO_SELECTION');
    var n = 0, fitted = 0;
    for (var i = 0; i < sel.length; i++) {
      var l = sel[i]; if (l instanceof CameraLayer || l instanceof LightLayer) continue;
      var map = null;
      if (o.keys && s.keys) {
        var d = l.outPoint - l.inPoint, k = (o.timing === 'fit' && s.duration > 0 && d > 0) ? d / s.duration : 1;
        map = { a: s.inPoint, b: l.inPoint, k: k };
        if (k !== 1) fitted++;
      }
      if (o.effects) {
        var fxg = l.property('ADBE Effect Parade');
        if (o.replace) for (var r = fxg.numProperties; r >= 1; r--) fxg.property(r).remove();
        for (var j = 0; j < s.effects.length; j++) {
          var fx = fxg.addProperty(s.effects[j].match);
          try { fx.name = s.effects[j].name; } catch (x) {}
          nt_writeProps(fx, s.effects[j].props, map);
        }
      }
      if (o.transform) {
        var tr = l.property('ADBE Transform Group');
        tr.property('ADBE Scale').setValue(l.threeDLayer && s.scale.length < 3 ? [s.scale[0], s.scale[1], 100] : (!l.threeDLayer && s.scale.length > 2 ? [s.scale[0], s.scale[1]] : s.scale));
        tr.property('ADBE Rotate Z').setValue(s.rotation);
      }
      if (o.blend) { l.blendingMode = s.blend; l.property('ADBE Transform Group').property('ADBE Opacity').setValue(s.opacity); l.motionBlur = s.motionBlur; }
      n++;
    }
    return nt_ok({ count: n, fitted: fitted });
  });
}

// ───────────────────────── SEQUENCE (selected layers one after another)
// order: 'stack' (top to bottom in the timeline) or 'selection' (the order you clicked them)
// start: 'first' (earliest selected clip) or 'playhead'. gap: frames between clips, negative = overlap.
function nt_sequence(order, start, gap) {
  return nt_run('Sequence layers', function (comp) {
    var sel = comp.selectedLayers, list = [], i;
    for (i = 0; i < sel.length; i++) list.push(sel[i]);
    if (list.length < 2) return nt_err('NEED_TWO');
    if (order !== 'selection') list.sort(function (a, b) { return a.index - b.index; });
    var t;
    if (start === 'playhead') t = comp.time;
    else { t = list[0].inPoint; for (i = 1; i < list.length; i++) if (list[i].inPoint < t) t = list[i].inPoint; }
    var step = (gap || 0) * comp.frameDuration;
    for (i = 0; i < list.length; i++) {
      var L = list[i], locked = L.locked; L.locked = false;
      L.startTime += t - L.inPoint;
      t = L.outPoint + step;
      L.locked = locked;
    }
    return nt_ok({ count: list.length, end: t - step });
  });
}

// ───────────────────────── EFFECTS
function nt_listEffects() {
  var out = [];
  for (var i = 0; i < app.effects.length; i++) { var e = app.effects[i]; if (e.displayName) out.push({ n: e.displayName, m: e.matchName, c: e.category }); }
  return nt_ok({ effects: out });
}
function nt_applyEffect(match, name, forceAdjustment) {
  return nt_run('Apply ' + name, function (comp) {
    var sel = comp.selectedLayers, targets = [];
    for (var i = 0; i < sel.length; i++) if (!(sel[i] instanceof CameraLayer) && !(sel[i] instanceof LightLayer)) targets.push(sel[i]);
    var created = false;
    if (!targets.length || forceAdjustment) {
      var adj = comp.layers.addSolid([1, 1, 1], name, comp.width, comp.height, comp.pixelAspect, comp.duration);
      adj.adjustmentLayer = true; adj.label = 5;
      if (sel.length) adj.moveBefore(sel[0]);
      targets = [adj]; created = true;
    }
    for (var j = 0; j < targets.length; j++) {
      var fxg = targets[j].property('ADBE Effect Parade');
      if (!fxg.canAddProperty(match)) return nt_err('CANNOT_ADD');
      fxg.addProperty(match);
    }
    return nt_ok({ count: targets.length, adjustment: created });
  });
}

// ───────────────────────── UNDO (Edit > Undo)
function nt_undo() {
  try { app.executeCommand(16); return nt_ok({}); } catch (e) { return nt_err(String(e.message || e)); }
}

// ───────────────────────── SNAP / SEQUENCE LAYERS ON BEATS
// mode "snap": each selected layer starts on the nearest beat.
// mode "sequence": selected layers play one after another, one per beat (trimmed to the next beat).
function nt_snapLayers(times, mode, skipIndex) {
  return nt_run(mode === 'sequence' ? 'Sequence on beats' : 'Snap to beats', function (comp) {
    var sel = comp.selectedLayers, list = [];
    for (var i = 0; i < sel.length; i++) if (sel[i].index !== skipIndex && !(sel[i] instanceof CameraLayer) && !(sel[i] instanceof LightLayer)) list.push(sel[i]);
    if (!list.length) return nt_err('NO_SELECTION');
    if (!times || !times.length) return nt_err('NO_BEATS');
    var n = 0;
    if (mode === 'sequence') {
      list.sort(function (a, b) { return a.index - b.index; });
      var first = 0, t0 = list[0].inPoint;
      for (var f = 0; f < times.length; f++) { if (times[f] >= t0 - 0.0001) { first = f; break; } }
      for (var j = 0; j < list.length && first + j < times.length; j++) {
        var L = list[j], start = times[first + j], end = times[first + j + 1];
        var locked = L.locked; L.locked = false;
        L.startTime += start - L.inPoint;
        if (end !== undefined && end > start) { try { L.outPoint = end; } catch (e1) {} }
        L.locked = locked; n++;
      }
    } else {
      for (var k = 0; k < list.length; k++) {
        var M = list[k], best = times[0];
        for (var b = 1; b < times.length; b++) if (Math.abs(times[b] - M.inPoint) < Math.abs(best - M.inPoint)) best = times[b];
        var lk = M.locked; M.locked = false; M.startTime += best - M.inPoint; M.locked = lk; n++;
      }
    }
    return nt_ok({ count: n });
  });
}
