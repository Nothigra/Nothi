/* Nothi Toolkit — compact panel (CEP). Also runs in a plain browser in preview mode (actions are simulated). */
(() => {
  'use strict';

  // ───────────────────────── host bridge & storage
  const CEP = !!window.__adobe_cep__;
  const IS_MAC = /Mac/i.test(navigator.platform || navigator.userAgent);
  const SITE = 'https://nothi.io';
  const VERSION = '1.2';
  const host = (fn, ...args) => new Promise((resolve) => {
    if (!CEP) return setTimeout(() => resolve(MOCK(fn, args)), 60);
    window.__adobe_cep__.evalScript(`${fn}(${args.map((a) => JSON.stringify(a)).join(',')})`, (res) => {
      try { resolve(JSON.parse(res)); } catch { resolve({ ok: false, error: res || 'Script error' }); }
    });
  });
  const store = {
    get(k, d) { try { const v = localStorage.getItem('nothi-tk2-' + k); return v ? JSON.parse(v) : d; } catch { return d; } },
    set(k, v) { try { localStorage.setItem('nothi-tk2-' + k, JSON.stringify(v)); } catch { /* ignore */ } },
  };
  const ERR = {
    NO_COMP: 'Open a composition first', NO_SELECTION: 'Select one or more layers', NO_KEYS: 'Select two keyframes or more',
    NO_AUDIO: 'Select a layer with audio', NO_STYLE: 'Copy a style first', CANNOT_ADD: 'This effect can’t go on that layer',
    NO_PRECOMP: 'Select a precomp layer', NO_BEATS: 'Find the beats first',
  };

  // ───────────────────────── icons
  const I = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const ICON = {
    create: I('<path d="M12 5v14M5 12h14"/>'),
    curves: I('<path d="M4 19C10 19 9 5 20 5"/>'),
    beat: I('<path d="M4 10v4M8 6v12M12 9v6M16 4v16M20 10v4"/>'),
    layers: I('<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>'),
    style: I('<path d="M14 4l6 6-9 9H5v-6z"/><path d="M12 6l6 6"/>'),
    effects: I('<path d="M12 4v4M12 16v4M4 12h4M16 12h4M6.5 6.5l2.5 2.5M15 15l2.5 2.5M6.5 17.5 9 15M15 9l2.5-2.5"/>'),
    search: I('<circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5"/>'),
    sliders: I('<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>'),
    menu: I('<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'),
    text: I('<path d="M6 6h12M12 6v13"/>'),
    adjustment: I('<circle cx="12" cy="12" r="7"/><path d="M12 5a7 7 0 0 1 0 14z" fill="currentColor"/>'),
    solid: I('<rect x="5" y="5" width="14" height="14" fill="currentColor" stroke="none"/>'),
    null: I('<rect x="5" y="5" width="14" height="14" stroke-dasharray="2.5 2.5"/>'),
    shape: I('<path d="M12 4l8 14H4z"/>'),
    camera: I('<rect x="3" y="7" width="12" height="10"/><path d="m15 11 6-3v8l-6-3"/>'),
    light: I('<circle cx="12" cy="10" r="5"/><path d="M10 18h4M11 21h2"/>'),
    plus: I('<path d="M12 6v12M6 12h12"/>'),
    x: I('<path d="M7 7l10 10M17 7 7 17"/>'),
    trash: I('<path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/>'),
    copy: I('<rect x="9" y="9" width="11" height="11"/><path d="M15 9V4H4v11h5"/>'),
    paste: I('<rect x="5" y="5" width="14" height="16"/><path d="M9 3h6v4H9z"/>'),
    precomp: I('<rect x="4" y="4" width="16" height="16"/><rect x="8" y="8" width="8" height="8"/>'),
    decomp: I('<rect x="4" y="4" width="10" height="10"/><rect x="10" y="10" width="10" height="10"/>'),
    rename: I('<path d="M4 8h9M4 13h6M4 18h8"/><path d="m14 19 6-6-2-2-6 6v2z"/>'),
    anchor: I('<circle cx="12" cy="12" r="2.5"/><path d="M12 3v5M12 16v5M3 12h5M16 12h5"/>'),
    star: I('<path d="M12 4l2.4 5 5.6.8-4 3.9 1 5.5L12 16.6 7 19.2l1-5.5-4-3.9 5.6-.8z"/>'),
    starOn: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 4l2.4 5 5.6.8-4 3.9 1 5.5L12 16.6 7 19.2l1-5.5-4-3.9 5.6-.8z"/></svg>',
    play: I('<path d="M7 5v14l11-7z"/>'),
    marker: I('<path d="M7 4h10v9l-5 6-5-6z"/>'),
    stop: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1.5" fill="currentColor"/></svg>',
    playOn: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M7 5v14l11-7z"/></svg>',
    reload: I('<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/>'),
    snap: I('<path d="M6 4v16M18 4v16"/><rect x="9" y="9" width="6" height="6"/>'),
    seq: I('<path d="M4 6h5M8 12h6M13 18h7"/>'),
    undo: I('<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>'),
  };

  // ───────────────────────── helpers
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;

  // status bar: the panel's only feedback channel (no toasts)
  let stTimer;
  function status(msg, kind = 'done', undoable = false) {
    const el = $('#status');
    el.classList.remove('done', 'err'); el.classList.add(kind);
    $('#stMsg').textContent = msg;
    $('#stUndo').hidden = !undoable;
    clearTimeout(stTimer);
    stTimer = setTimeout(() => { el.classList.remove('done', 'err'); $('#stMsg').textContent = idleMsg(); $('#stUndo').hidden = true; }, undoable ? 7000 : 3200);
  }
  const idleMsg = () => (ctx.comp ? (ctx.selected ? plural(ctx.selected, 'layer') + ' selected' : 'Ready') : 'No composition open');
  function flash(el, ok) { if (!el) return; el.classList.remove('ok', 'bad'); void el.offsetWidth; el.classList.add(ok ? 'ok' : 'bad'); setTimeout(() => el.classList.remove('ok', 'bad'), 650); }
  async function run(btn, promise, okMsg) {
    const r = await promise;
    const ok = !!(r && r.ok);
    flash(btn, ok);
    if (ok) { if (okMsg) status(typeof okMsg === 'function' ? okMsg(r) : okMsg, 'done', true); }
    else status(ERR[r && r.error] || (r && r.error) || 'Something went wrong', 'err');
    return r;
  }

  // recent actions (shown first in the search)
  const remember = (id) => { const r = store.get('recent', []).filter((x) => x !== id); r.unshift(id); store.set('recent', r.slice(0, 5)); };

  // ───────────────────────── context polling
  let ctx = { comp: null };
  async function poll() {
    const r = await host('nt_context');
    if (!r || !r.ok) return;
    ctx = r;
    document.body.classList.toggle('nocomp', !r.comp);
    $('#status').classList.toggle('live', !!r.comp);
    $('#stCtx').textContent = r.comp ? `${r.comp} · ${r.w}×${r.h} · ${r.fps} fps` : '';
    if (!$('#status').classList.contains('done') && !$('#status').classList.contains('err')) $('#stMsg').textContent = idleMsg();
  }

  // ───────────────────────── size classes (the panel adapts to its window)
  new ResizeObserver(() => {
    document.body.classList.toggle('xs', innerWidth < 250);
    document.body.classList.toggle('short', innerHeight < 300);
  }).observe(document.documentElement);

  // ───────────────────────── options popover
  const pop = $('#pop');
  let popFor = null;
  function openPop(anchorBtn, html, bind) {
    if (popFor === anchorBtn) return closePop();
    pop.innerHTML = html; pop.hidden = false; popFor = anchorBtn;
    $$('.ib').forEach((b) => b.classList.toggle('on', b === anchorBtn));
    bind && bind(pop);
  }
  function closePop() { pop.hidden = true; popFor = null; $$('.ib').forEach((b) => b.classList.remove('on')); }
  document.addEventListener('mousedown', (e) => { if (!pop.hidden && !pop.contains(e.target) && !e.target.closest('.ib')) closePop(); });
  const opt = (key, label, on, sub = '', radio = false) => `<div class="opt ${on ? 'on' : ''}" data-opt="${key}"><span class="box ${radio ? 'radio' : ''}"></span><span class="k">${label}${sub ? `<small>${sub}</small>` : ''}</span></div>`;
  function bindOpts(root, state, save, rerender) {
    $$('[data-opt]', root).forEach((el) => el.addEventListener('click', () => {
      const [k, v] = el.dataset.opt.split('=');
      if (v !== undefined) { state[k] = v; $$(`[data-opt^="${k}="]`, root).forEach((x) => x.classList.toggle('on', x === el)); }
      else { state[k] = !state[k]; el.classList.toggle('on', state[k]); }
      save(); rerender && rerender();
    }));
  }

  // ───────────────────────── tabs
  const TABS = [['create', 'Create layers', 'Text, adjustment, solid, null… matched to the selected layer'], ['curves', 'Curves', 'Apply an ease to the selected keyframes, or save your own'], ['beat', 'Beat markers', 'Find the beats of a song and put layers on them'], ['layers', 'Layers', 'Anchor point, precompose, decompose, rename'], ['style', 'Copy style', 'Copy effects and look from one layer to others'], ['effects', 'Effects', 'Your favorite effects, one click away']];
  let current = store.get('tab', 'create');
  function renderTabs() {
    $('#tabs').innerHTML = TABS.map(([k, n, t]) => `<button class="tab ${k === current ? 'on' : ''}" data-tab="${k}" title="${n} · ${t}">${ICON[k]}</button>`).join('');
    $$('.tab').forEach((b) => b.addEventListener('click', () => go(b.dataset.tab)));
  }
  function go(tab) { if (tab !== 'beat') stop(); current = tab; store.set('tab', tab); closePop(); renderTabs(); render(); }
  function render() { const v = $('#view'); v.innerHTML = ''; $('#btnTabSettings').hidden = !VIEWS[current].options; VIEWS[current].render(v); }

  // ═════════════ CREATE
  const CREATE = [['text', 'Text'], ['adjustment', 'Adjust'], ['solid', 'Solid'], ['null', 'Null'], ['shape', 'Shape'], ['camera', 'Camera'], ['light', 'Light']];
  const COLORS = ['#FFFFFF', '#0A0A0A', '#8A8A93', '#FF6A3D', '#2FC6A0'];
  const cState = store.get('create', { match: true, color: '#FFFFFF', name: '' });
  const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16) / 255);
  const doCreate = (type, btn) => (remember('create:' + type), run(btn, host('nt_create', type, { name: cState.name || undefined, color: rgb(cState.color), matchDuration: cState.match }), (r) => `${r.name} added`));
  const CREATE_TIPS = { text: 'Centered, at the playhead', adjustment: 'Covers the selected layer’s duration', solid: 'Comp size, your chosen color', null: 'Handy as a controller: parent layers to it', shape: 'Empty shape layer, ready for the pen', camera: '2-node camera, layers switched to 3D stay put', light: 'Point light with soft shadows' };
  const Create = {
    render(v) {
      v.innerHTML = `<div class="grid">${CREATE.map(([k, n]) => `<button class="t needs-comp" data-k="${k}" title="${k === 'adjustment' ? 'Adjustment' : n} layer · ${CREATE_TIPS[k]}">${ICON[k]}<span>${n}</span></button>`).join('')}</div>`;
      $$('.t', v).forEach((b) => b.addEventListener('click', () => doCreate(b.dataset.k, b)));
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">New layers</div>
        <div class="field"><input class="in" id="oName" placeholder="Name (optional)" value="${esc(cState.name)}"></div>
        <div class="sw">${COLORS.map((c) => `<button data-c="${c}" class="${cState.color === c ? 'on' : ''}" style="background:${c}" title="${c}"></button>`).join('')}<button class="${COLORS.includes(cState.color) ? '' : 'on'}" style="background:${COLORS.includes(cState.color) ? '#333' : cState.color}" title="Custom color"><input type="color" id="oColor" value="${cState.color}"></button></div>
        <hr>${opt('match', 'Match selected layer', cState.match, 'Same start, end and position in the stack')}`, (p) => {
        const save = () => store.set('create', cState);
        $('#oName', p).addEventListener('input', (e) => { cState.name = e.target.value; save(); });
        $$('.sw button[data-c]', p).forEach((b) => b.addEventListener('click', () => { cState.color = b.dataset.c; save(); popFor = null; Create.options(btn); }));
        $('#oColor', p).addEventListener('input', (e) => { cState.color = e.target.value; save(); });
        bindOpts(p, cState, save);
      });
    },
  };

  // ═════════════ CURVES
  const PRESETS = [['Easy Ease', [0.33, 0, 0.67, 1]], ['Smooth', [0.65, 0, 0.35, 1]], ['Silk', [0.8, 0, 0.2, 1]], ['Expo Out', [0.16, 1, 0.3, 1]], ['Expo In', [0.7, 0, 0.84, 0]], ['Punch', [0.95, 0, 0.05, 1]], ['Snap Out', [0.05, 0.7, 0.1, 1]], ['Glide', [0.25, 0.1, 0.25, 1]]];
  const toAE = ([x1, y1, x2, y2]) => ({ outInf: Math.max(0.1, x1 * 100), outRatio: x1 > 0 ? y1 / x1 : 0, inInf: Math.max(0.1, (1 - x2) * 100), inRatio: x2 < 1 ? (1 - y2) / (1 - x2) : 0 });
  const fromAE = (c) => { const x1 = c.outInf / 100, x2 = 1 - c.inInf / 100; return [x1, Math.min(1.6, x1 * c.outRatio), x2, Math.max(-0.6, 1 - (c.inInf / 100) * c.inRatio)]; };
  function curveSVG(b) {
    const X = (x) => 2 + x * 36, Y = (y) => 26 - y * 24, d = `M${X(0)} ${Y(0)} C${X(b[0])} ${Y(b[1])} ${X(b[2])} ${Y(b[3])} ${X(1)} ${Y(1)}`;
    return `<svg class="g" viewBox="0 0 40 28"><path d="${d}" stroke="currentColor" stroke-width="1.6" fill="none"/><circle r="1.8" fill="#FFFFFF"><animateMotion dur="1.4s" repeatCount="indefinite" path="${d}" keyPoints="0;1" keyTimes="0;1" calcMode="linear"/></circle></svg>`;
  }
  const applyCurve = (name, b, btn) => (remember('curve:' + name), run(btn, host('nt_curveApply', toAE(b)), (r) => `${name} → ${plural(r.count, 'keyframe pair')}`));
  async function saveCurve(btn) {
    const r = await host('nt_curveRead');
    if (!r.ok) { flash(btn, false); return status(ERR[r.error] || r.error, 'err'); }
    const list = store.get('curves', []);
    const name = `My curve ${list.length + 1}`;
    list.unshift({ name, b: fromAE(r.curve).map((v) => Math.round(v * 1000) / 1000) }); store.set('curves', list);
    status(`${name} saved · double-click to rename`); render();
  }
  const Curves = {
    render(v) {
      const mine = store.get('curves', []);
      const tile = (n, b, i) => `<button class="t cv needs-comp" data-b="${b.join(',')}" data-n="${esc(n)}" ${i != null ? `data-i="${i}"` : ''} title="${esc(n)} · ${i != null ? 'Your curve. Double-click to rename' : 'Click to apply on the selected keyframes'}">${i != null ? '<i class="mine-tag"></i>' : ''}${curveSVG(b)}<span>${esc(n)}</span>${i != null ? `<i class="x" data-del="${i}" title="Delete">${ICON.x}</i>` : ''}</button>`;
      v.innerHTML = `<div class="grid"><button class="t cv add needs-comp" id="cvAdd" title="Save a curve · Select two keyframes with the ease you like, then click">${ICON.plus}<span>Save</span></button>${mine.map((c, i) => tile(c.name, c.b, i)).join('')}${PRESETS.map(([n, b]) => tile(n, b)).join('')}</div>`;
      $('#cvAdd', v).addEventListener('click', (e) => saveCurve(e.currentTarget));
      $$('.cv[data-b]', v).forEach((t) => {
        t.addEventListener('click', (e) => { if (e.target.closest('[data-del]')) return; applyCurve(t.dataset.n, t.dataset.b.split(',').map(Number), t); });
        if (t.dataset.i != null) t.addEventListener('dblclick', () => {
          const span = $('span', t); const inp = document.createElement('input'); inp.className = 'in'; inp.value = t.dataset.n; inp.style.height = '18px'; inp.style.fontSize = '10px';
          span.replaceWith(inp); inp.focus(); inp.select();
          const done = () => { const list = store.get('curves', []); list[Number(t.dataset.i)].name = inp.value.trim() || t.dataset.n; store.set('curves', list); render(); };
          inp.addEventListener('keydown', (e) => { e.stopPropagation(); if (e.key === 'Enter') done(); if (e.key === 'Escape') render(); });
          inp.addEventListener('blur', done);
        });
      });
      $$('[data-del]', v).forEach((x) => x.addEventListener('click', (e) => { e.stopPropagation(); const list = store.get('curves', []); const [g] = list.splice(Number(x.dataset.del), 1); store.set('curves', list); status(`${g.name} deleted`); render(); }));
    },
    options: null,
  };

  // ═════════════ BEAT
  const bState = store.get('beat', { sens: 55, mode: 'mix', target: 'layer', numbers: false, workArea: false, replace: true });
  let beat = null; // { info, audio, res, times }
  async function decodeAudio(path) {
    let buf;
    if (CEP && typeof require === 'function') { const b = require('fs').readFileSync(path); buf = b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength); }
    else buf = await (await fetch(path)).arrayBuffer();
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    try { return await ac.decodeAudioData(buf); } finally { ac.close && ac.close(); }
  }
  async function envelope(audio, mode) {
    const sr = audio.sampleRate, len = audio.length;
    let data;
    if (mode === 'kick') {
      const oc = new OfflineAudioContext(1, len, sr), s = oc.createBufferSource(), lp = oc.createBiquadFilter();
      s.buffer = audio; lp.type = 'lowpass'; lp.frequency.value = 140; s.connect(lp); lp.connect(oc.destination); s.start();
      data = (await oc.startRendering()).getChannelData(0);
    } else {
      data = new Float32Array(len);
      for (let c = 0; c < audio.numberOfChannels; c++) { const ch = audio.getChannelData(c); for (let i = 0; i < len; i++) data[i] += ch[i] / audio.numberOfChannels; }
    }
    const hop = 512, win = 1024, n = Math.floor((len - win) / hop), env = new Float32Array(n), flux = new Float32Array(n);
    for (let f = 0; f < n; f++) { let s2 = 0; const o = f * hop; for (let i = 0; i < win; i++) s2 += data[o + i] * data[o + i]; env[f] = Math.log1p(Math.sqrt(s2 / win) * 100); }
    for (let f = 1; f < n; f++) flux[f] = Math.max(0, env[f] - env[f - 1]);
    const W = 400, peaks = [], step = Math.max(1, Math.floor(len / W));
    for (let x = 0; x < W; x++) { let mx = 0; for (let i = x * step; i < (x + 1) * step && i < len; i += 32) mx = Math.max(mx, Math.abs(data[i])); peaks.push(mx); }
    return { flux, fps: sr / hop, duration: len / sr, peaks };
  }
  function pickBeats(env, sens) {
    const { flux, fps } = env, n = flux.length, half = Math.round(fps * 0.5);
    const k = 2.2 - (sens / 100) * 1.9, gap = 0.34 - (sens / 100) * 0.22, out = [];
    let last = -1e9;
    for (let f = 2; f < n - 2; f++) {
      const a = Math.max(0, f - half), b = Math.min(n, f + half);
      let m = 0, m2 = 0; for (let i = a; i < b; i++) { m += flux[i]; m2 += flux[i] * flux[i]; }
      const c = b - a; m /= c; const sd = Math.sqrt(Math.max(0, m2 / c - m * m));
      const peak = flux[f] > flux[f - 1] && flux[f] >= flux[f + 1] && flux[f] >= flux[f - 2] && flux[f] >= flux[f + 2];
      const t = f / fps;
      if (peak && flux[f] > m + k * sd && flux[f] > 0.01 && t - last >= gap) { out.push(t); last = t; }
    }
    return out;
  }
  function bpmOf(times) {
    const iv = times.slice(1).map((t, i) => t - times[i]).filter((d) => d > 0.2 && d < 2).sort((a, b) => a - b);
    let bpm = iv.length ? 60 / iv[Math.floor(iv.length / 2)] : 0;
    while (bpm && bpm < 70) bpm *= 2; while (bpm > 180) bpm /= 2;
    return Math.round(bpm);
  }
  // Only the part of the layer that is actually on the timeline (trimmed in/out), optionally only the work area.
  function windowOf(info) {
    const k = info.stretch / 100;
    let from = info.inPoint, to = info.outPoint;
    if (bState.workArea) { from = Math.max(from, info.workStart); to = Math.min(to, info.workEnd); }
    return { from, to, srcFrom: (from - info.startTime) / k, srcTo: (to - info.startTime) / k, k };
  }
  function computeTimes() {
    if (!beat) return;
    const w = windowOf(beat.info);
    beat.all = pickBeats(beat.env, bState.sens);
    beat.times = beat.all.filter((t) => t >= w.srcFrom && t <= w.srcTo).map((t) => beat.info.startTime + t * w.k);
    beat.w = w; beat.bpm = bpmOf(beat.all);
  }
  function drawBeat() {
    const zone = $('#drop'); if (!zone || !beat) return;
    zone.classList.add('has');
    zone.title = 'Click the waveform to listen from there · Drop another audio layer to replace it';
    zone.innerHTML = `<canvas></canvas><div class="meta"><span>${esc(beat.info.name)}</span><span><b>${beat.times.length}</b> beats${beat.bpm ? ` · <b>${beat.bpm}</b> BPM` : ''}</span></div><button class="play" id="bPlay" title="Listen · Space-free preview of the visible part">${player.src ? ICON.stop : ICON.playOn}</button>`;
    const cv = $('canvas', zone), dpr = devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr;
    const g = cv.getContext('2d'); g.scale(dpr, dpr);
    const env = beat.env, dur = env.duration, max = Math.max(1e-4, ...env.peaks), bw = W / env.peaks.length;
    const x0 = (beat.w.srcFrom / dur) * W, x1 = (beat.w.srcTo / dur) * W;
    env.peaks.forEach((p, i) => { const x = i * bw, h = Math.max(1, (p / max) * (H - 26)); g.fillStyle = x >= x0 && x <= x1 ? '#4C4C54' : '#222226'; g.fillRect(x, (H + 14 - h) / 2, Math.max(1, bw - 0.5), h); });
    g.fillStyle = 'rgba(0,0,0,.45)'; g.fillRect(0, 0, Math.max(0, x0), H); g.fillRect(Math.min(W, x1), 0, W, H);
    g.fillStyle = 'rgba(255,255,255,.9)';
    beat.all.forEach((t) => { const x = (t / dur) * W; if (x >= x0 && x <= x1) g.fillRect(x - 0.5, 18, 1, H - 22); });
    cv.addEventListener('click', (e) => { e.stopPropagation(); const r = cv.getBoundingClientRect(); play(((e.clientX - r.left) / r.width) * dur); });
    $('#bPlay', zone).addEventListener('click', (e) => { e.stopPropagation(); if (player.src) stop(); else play(Math.max(beat.w.srcFrom, player.at || 0)); });
    const btn = $('#bAdd'); if (btn) { btn.disabled = false; $('.lbl', btn).textContent = `Add ${plural(beat.times.length, 'marker')}`; }
    $$('.needs-beat').forEach((x) => { x.disabled = false; });
  }

  // listen: click the waveform to hear the song from that point, with a moving playhead
  const player = { ac: null, src: null, at: 0, t0: 0, raf: 0 };
  function stop() {
    if (player.src) { try { player.src.onended = null; player.src.stop(); } catch { /* already stopped */ } player.src = null; }
    cancelAnimationFrame(player.raf); $('#drop .ph-line')?.remove();
    const pb = $('#bPlay'); if (pb) pb.innerHTML = ICON.playOn;
  }
  function play(from) {
    if (!beat || !beat.audio) return;
    stop();
    from = Math.max(beat.w.srcFrom, Math.min(from, beat.w.srcTo - 0.05));
    player.ac = player.ac || new (window.AudioContext || window.webkitAudioContext)();
    const src = player.ac.createBufferSource(); src.buffer = beat.audio; src.connect(player.ac.destination);
    src.start(0, from, Math.max(0.05, beat.w.srcTo - from)); src.onended = stop;
    player.src = src; player.at = from; player.t0 = player.ac.currentTime;
    const zone = $('#drop'); zone.insertAdjacentHTML('beforeend', '<i class="ph-line"></i>');
    const pb = $('#bPlay'); if (pb) pb.innerHTML = ICON.stop;
    const tick = () => {
      const line = $('#drop .ph-line'); if (!line || !player.src) return;
      const t = player.at + (player.ac.currentTime - player.t0);
      line.style.left = `${(t / beat.env.duration) * 100}%`;
      player.raf = requestAnimationFrame(tick);
    };
    tick();
  }

  async function analyze() {
    const zone = $('#drop');
    stop();
    const info = await host('nt_audioInfo');
    if (!info.ok) { flash(zone, false); return status(ERR[info.error] || info.error, 'err'); }
    zone.insertAdjacentHTML('beforeend', '<div class="busy"><span class="spin"></span>Listening…</div>');
    try {
      const audio = await decodeAudio(info.path);
      beat = { info, audio, env: await envelope(audio, bState.mode) };
      computeTimes(); drawBeat();
      remember('beat:find');
      status(`${info.name}: ${plural(beat.times.length, 'beat')} on the timeline${info.timeRemap ? ' · time remap ignored' : ''}`);
    } catch {
      $('.busy', zone)?.remove(); flash(zone, false);
      status('Can’t read this audio here. Use WAV, MP3 or AIFF', 'err');
    }
  }
  const doSnap = (mode, btn) => {
    if (!beat) return status(ERR.NO_BEATS, 'err');
    remember('beat:' + mode);
    return run(btn, host('nt_snapLayers', beat.times, mode, beat.info.index), (r) => (mode === 'sequence' ? `${plural(r.count, 'layer')} sequenced, one per beat` : `${plural(r.count, 'layer')} snapped to the nearest beat`));
  };
  const Beat = {
    render(v) {
      v.innerHTML = `<div class="drop needs-comp" id="drop" title="Drop an audio layer · Drag it from the timeline, or select it and click here">
          <div class="hint"><b>Drop an audio layer</b><small>or select it and click</small></div></div>
        <div class="row"><span class="cap">Sens.</span><input type="range" class="grow" id="bSens" min="0" max="100" value="${bState.sens}" title="Sensitivity · Left: only the strong hits. Right: every beat"><span class="num" id="bSensV">${bState.sens}</span></div>
        <div class="row"><button class="b main grow needs-comp" id="bAdd" ${beat ? '' : 'disabled'} title="Add markers · On the layer or on the comp (see options)">${ICON.marker}<span class="lbl">Add markers</span></button><button class="b needs-comp" id="bRe" title="Read again · Uses the selected layer">${ICON.reload}</button><button class="b needs-comp" id="bClear" title="Remove the markers · Only those on the target (layer or comp)">${ICON.trash}</button></div>
        <div class="row"><span class="cap opt-cap">Layers</span><div class="seg"><button class="needs-comp needs-beat" id="bSnap" ${beat ? '' : 'disabled'} title="Snap to beats · Each selected layer starts on the nearest beat">${ICON.snap}<span>Snap</span></button><button class="needs-comp needs-beat" id="bSeq" ${beat ? '' : 'disabled'} title="Sequence on beats · Selected layers play one after another, one per beat">${ICON.seq}<span>Sequence</span></button></div></div>`;
      const zone = $('#drop', v);
      zone.addEventListener('click', () => { if (!beat) analyze(); });
      ['dragenter', 'dragover'].forEach((ev) => zone.addEventListener(ev, (e) => { e.preventDefault(); zone.classList.add('over'); }));
      zone.addEventListener('dragleave', () => zone.classList.remove('over'));
      zone.addEventListener('drop', (e) => { e.preventDefault(); zone.classList.remove('over'); analyze(); });
      $('#bSens', v).addEventListener('input', (e) => { bState.sens = Number(e.target.value); $('#bSensV').textContent = bState.sens; store.set('beat', bState); if (beat) { computeTimes(); drawBeat(); } });
      $('#bAdd', v).addEventListener('click', async (e) => {
        if (!beat) return;
        const btn = e.currentTarget;
        remember('beat:add');
        if (bState.replace) await host('nt_clearMarkers', beat.info.index, bState.target);
        run(btn, host('nt_beatMarkers', beat.info.index, beat.times, bState.target, bState.numbers), (r) => `${plural(r.count, 'marker')} added on the ${bState.target === 'comp' ? 'composition' : 'layer'}`);
      });
      $('#bRe', v).addEventListener('click', analyze);
      $('#bClear', v).addEventListener('click', async (e) => {
        const idx = beat ? beat.info.index : ((await host('nt_audioInfo')).index || 1);
        run(e.currentTarget, host('nt_clearMarkers', idx, bState.target), (r) => `${plural(r.count, 'marker')} removed`);
      });
      $('#bSnap', v).addEventListener('click', (e) => doSnap('snap', e.currentTarget));
      $('#bSeq', v).addEventListener('click', (e) => doSnap('sequence', e.currentTarget));
      if (beat) requestAnimationFrame(drawBeat);
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">Listen to</div>${opt('mode=mix', 'Full mix', bState.mode === 'mix', '', true)}${opt('mode=kick', 'Kick & bass only', bState.mode === 'kick', '', true)}
        <hr><div class="ph cap">Markers on</div>${opt('target=layer', 'The audio layer', bState.target === 'layer', '', true)}${opt('target=comp', 'The composition', bState.target === 'comp', '', true)}
        <hr>${opt('workArea', 'Work area only', bState.workArea, 'Otherwise the visible part of the layer')}${opt('replace', 'Replace previous markers', bState.replace)}${opt('numbers', 'Number the markers', bState.numbers)}`, (p) => {
        const prevMode = bState.mode;
        bindOpts(p, bState, () => store.set('beat', bState), async () => {
          if (!beat) return;
          if (bState.mode !== prevMode) { await analyze(); return; }
          computeTimes(); drawBeat();
        });
      });
    },
  };

  // ═════════════ LAYERS
  const lState = store.get('layers', { trim: true, scope: 'selected', tags: true, deleteItem: false });
  const ANCHORS = [[0, 0, 'top left'], [0.5, 0, 'top'], [1, 0, 'top right'], [0, 0.5, 'left'], [0.5, 0.5, 'center'], [1, 0.5, 'right'], [0, 1, 'bottom left'], [0.5, 1, 'bottom'], [1, 1, 'bottom right']];
  const doAnchor = (x, y, btn) => (remember(`anchor:${x},${y}`), run(btn, host('nt_anchor', x, y), (r) => `Anchor moved · ${plural(r.count, 'layer')}${r.skipped ? ` (${r.skipped} skipped)` : ''}`));
  const doPrecomp = (btn) => (remember('precomp'), run(btn, host('nt_precompose', '', lState.trim), (r) => `Precomposed as “${r.name}”`));
  const doDecomp = (btn) => (remember('decomp'), run(btn, host('nt_decompose', lState.deleteItem), (r) => `${plural(r.count, 'layer')} back in the comp${r.lost.length ? ` · not kept: ${r.lost.join(', ')}` : ''}`));
  const doRename = (btn, scope = lState.scope) => (remember('rename:' + scope), run(btn, host('nt_rename', scope, lState.tags), (r) => `${plural(r.count, 'layer')} renamed`));
  const Layers = {
    render(v) {
      v.innerHTML = `<div class="row" style="align-items:stretch">
        <div class="anchor needs-comp" title="Anchor point · The layer doesn’t move, even when scaled or rotated">${ANCHORS.map(([x, y, n]) => `<button data-x="${x}" data-y="${y}" title="Anchor: ${n}"><i></i></button>`).join('')}</div>
        <div class="stack">
          <button class="b needs-comp" id="lPre" title="Precompose · Selected layers go into a new comp, trimmed to their length">${ICON.precomp}<span class="lbl">Precompose</span></button>
          <button class="b needs-comp" id="lDec" title="Decompose · Brings a precomp’s layers back into this comp, timing kept">${ICON.decomp}<span class="lbl">Decompose</span></button>
          <button class="b needs-comp" id="lRen" title="Rename · By type and content: “TXT – Title”, “VID – Clip 04”…">${ICON.rename}<span class="lbl">Rename</span></button>
        </div></div>`;
      $$('.anchor button', v).forEach((b) => b.addEventListener('click', () => doAnchor(Number(b.dataset.x), Number(b.dataset.y), b)));
      $('#lPre', v).addEventListener('click', (e) => doPrecomp(e.currentTarget));
      $('#lDec', v).addEventListener('click', (e) => doDecomp(e.currentTarget));
      $('#lRen', v).addEventListener('click', (e) => doRename(e.currentTarget));
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">Precompose</div>${opt('trim', 'Trim to the layers', lState.trim, 'The precomp starts and ends with them')}
        <hr><div class="ph cap">Decompose</div>${opt('deleteItem', 'Delete the precomp from the project', lState.deleteItem, 'Only if it isn’t used anywhere else')}
        <hr><div class="ph cap">Rename</div>${opt('scope=selected', 'Selected layers', lState.scope === 'selected', '', true)}${opt('scope=all', 'Whole composition', lState.scope === 'all', '', true)}${opt('tags', 'Type tags', lState.tags, 'TXT – , VID – , ADJ – …')}`, (p) => bindOpts(p, lState, () => store.set('layers', lState)));
    },
  };

  // ═════════════ STYLE
  const sState = store.get('style', { effects: true, replace: false, blend: true, transform: false, keys: false });
  let copied = null;
  const doCopy = async (btn) => { remember('copy'); const r = await run(btn, host('nt_styleCopy', sState.keys), (x) => `Copied the style of “${x.layer}”`); if (r.ok) { copied = r; if (current === 'style') render(); } };
  const doPaste = (btn) => (remember('paste'), run(btn, host('nt_stylePaste', sState), (r) => `Style pasted on ${plural(r.count, 'layer')}`));
  const Style = {
    render(v) {
      v.innerHTML = `<div class="pair"><button class="b needs-comp" id="sCopy" title="Copy style · Effects, blend mode and look of the selected layer">${ICON.copy}<span>Copy</span></button><button class="b needs-comp" id="sPaste" ${copied ? '' : 'disabled'} title="Paste style · On every selected layer. Choose what in the options">${ICON.paste}<span>Paste</span></button></div>
        <div class="clip">${copied ? `<b>${esc(copied.layer)}</b><span class="fx">${copied.effects.length ? esc(copied.effects.join(', ')) : 'no effects'}</span>` : '<span>Nothing copied yet</span>'}</div>`;
      $('#sCopy', v).addEventListener('click', (e) => doCopy(e.currentTarget));
      $('#sPaste', v).addEventListener('click', (e) => doPaste(e.currentTarget));
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">Copy</div>${opt('keys', 'Include animation', sState.keys, 'Keyframes follow each layer’s start')}
        <hr><div class="ph cap">Paste</div>${opt('effects', 'Effects', sState.effects)}${opt('replace', 'Replace existing effects', sState.replace)}${opt('blend', 'Blend mode, opacity, motion blur', sState.blend)}${opt('transform', 'Scale & rotation', sState.transform)}`, (p) => bindOpts(p, sState, () => store.set('style', sState)));
    },
  };

  // ═════════════ EFFECTS
  const DEFAULT_FAVS = [['Gaussian Blur', 'ADBE Gaussian Blur 2'], ['Glow', 'ADBE Glo2'], ['Lumetri Color', 'ADBE Lumetri'], ['Directional Blur', 'ADBE Motion Blur'], ['Transform', 'ADBE Geometry2'], ['Turbulent Displace', 'ADBE Turbulent Displace'], ['Drop Shadow', 'ADBE Drop Shadow'], ['Fill', 'ADBE Fill']].map(([n, m]) => ({ n, m }));
  const eState = store.get('effects', { adjustment: false });
  let allFx = null;
  const favs = () => store.get('favs', DEFAULT_FAVS);
  const loadFx = async () => { if (!allFx) { const r = await host('nt_listEffects'); allFx = r.ok ? r.effects : []; } return allFx; };
  const doFx = (f, btn, adj = eState.adjustment) => (remember('fx:' + f.m), run(btn, host('nt_applyEffect', f.m, f.n, adj), (r) => (r.adjustment ? `${f.n} on a new adjustment layer` : `${f.n} → ${plural(r.count, 'layer')}`)));
  const Effects = {
    q: '',
    async render(v) {
      v.innerHTML = `<input class="in" id="fxQ" placeholder="Search effects" value="${esc(Effects.q)}"><div class="list" id="fxList"></div>`;
      const q = $('#fxQ', v);
      q.addEventListener('input', () => { Effects.q = q.value; list(); });
      q.addEventListener('keydown', (e) => e.stopPropagation());
      async function list() {
        const term = Effects.q.trim().toLowerCase(), fv = favs();
        let rows;
        if (!term) rows = fv.map((f) => ({ ...f, fav: true }));
        else {
          const all = await loadFx();
          const hits = all.filter((e) => e.n.toLowerCase().includes(term)).slice(0, 40);
          rows = hits.map((e) => ({ ...e, fav: fv.some((f) => f.m === e.m) }));
        }
        const L = $('#fxList');
        L.innerHTML = rows.length ? rows.map((f, i) => `<div class="li needs-comp" data-i="${i}" title="${esc(f.n)} · Click to apply. Alt+click: on a new adjustment layer"><span class="sq">${esc(f.n[0])}</span><span class="nm">${esc(f.n)}</span>${term ? `<span class="sub">${esc(f.c || '')}</span>` : ''}<span class="act"><button data-star="${i}" title="${f.fav ? 'Remove from favorites' : 'Add to favorites'}">${f.fav ? ICON.starOn : ICON.star}</button></span></div>`).join('') : '<div class="pal-empty">No effect found</div>';
        $$('.li', L).forEach((el) => el.addEventListener('click', (e) => {
          const f = rows[Number(el.dataset.i)];
          const st = e.target.closest('[data-star]');
          if (st) {
            let fv2 = favs();
            if (fv2.some((x) => x.m === f.m)) { fv2 = fv2.filter((x) => x.m !== f.m); status(`${f.n} removed from favorites`); }
            else { fv2.push({ n: f.n, m: f.m }); status(`${f.n} added to favorites`); }
            store.set('favs', fv2); list(); return;
          }
          doFx(f, el, e.altKey || eState.adjustment);
        }));
      }
      list();
    },
    options(btn) { openPop(btn, `<div class="ph cap">Apply</div>${opt('adjustment', 'Always on a new adjustment layer', eState.adjustment, 'Alt+click does it once')}`, (p) => bindOpts(p, eState, () => store.set('effects', eState))); },
  };

  const VIEWS = { create: Create, curves: Curves, beat: Beat, layers: Layers, style: Style, effects: Effects };

  // ═════════════ COMMAND PALETTE (universal search, custom shortcut)
  const DEFAULT_KEY = { key: 'K', code: 'KeyK', ctrl: !IS_MAC, meta: IS_MAC, shift: false, alt: false };
  let hotkey = store.get('hotkey', DEFAULT_KEY);
  const keyLabel = (k) => [k.ctrl && (IS_MAC ? '⌃' : 'Ctrl'), k.alt && (IS_MAC ? '⌥' : 'Alt'), k.shift && (IS_MAC ? '⇧' : 'Shift'), k.meta && (IS_MAC ? '⌘' : 'Win'), k.key === ' ' ? 'Space' : k.key].filter(Boolean).join(IS_MAC ? '' : '+');
  // After Effects keeps keyboard shortcuts for itself unless the panel asks for them.
  const MAC_CODES = { A: 0, S: 1, D: 2, F: 3, H: 4, G: 5, Z: 6, X: 7, C: 8, V: 9, B: 11, Q: 12, W: 13, E: 14, R: 15, Y: 16, T: 17, 1: 18, 2: 19, 3: 20, 4: 21, 6: 22, 5: 23, 9: 25, 7: 26, 8: 28, 0: 29, O: 31, U: 32, I: 34, P: 35, L: 37, J: 38, K: 40, N: 45, M: 46, ' ': 49 };
  function registerHotkey() {
    if (!CEP || !window.__adobe_cep__.registerKeyEventsInterest) return;
    const k = hotkey, code = IS_MAC ? MAC_CODES[k.key.toUpperCase()] : (k.key === ' ' ? 32 : k.key.toUpperCase().charCodeAt(0));
    if (code == null) return;
    const ev = { keyCode: code, ctrlKey: !!k.ctrl, altKey: !!k.alt, shiftKey: !!k.shift, metaKey: !!k.meta };
    window.__adobe_cep__.registerKeyEventsInterest(JSON.stringify([ev, { keyCode: IS_MAC ? 53 : 27 }, { keyCode: IS_MAC ? 125 : 40 }, { keyCode: IS_MAC ? 126 : 38 }, { keyCode: IS_MAC ? 36 : 13 }]));
  }
  const matches = (e, k) => e.key.toUpperCase() === k.key.toUpperCase() && !!e.ctrlKey === !!k.ctrl && !!e.metaKey === !!k.meta && !!e.shiftKey === !!k.shift && !!e.altKey === !!k.alt;

  function commands() {
    const c = [];
    CREATE.forEach(([k, n]) => c.push({ id: 'create:' + k, g: 'Create', n: `New ${n === 'Adjust' ? 'adjustment' : n.toLowerCase()} layer`, i: ICON[k], run: () => doCreate(k) }));
    ANCHORS.forEach(([x, y, n]) => c.push({ id: `anchor:${x},${y}`, g: 'Anchor', n: `Anchor ${n}`, i: ICON.anchor, run: () => doAnchor(x, y) }));
    c.push({ id: 'precomp', g: 'Layers', n: 'Precompose', i: ICON.precomp, run: () => doPrecomp() });
    c.push({ id: 'decomp', g: 'Layers', n: 'Decompose precomp', i: ICON.decomp, run: () => doDecomp() });
    c.push({ id: 'rename:selected', g: 'Layers', n: 'Rename selected layers', i: ICON.rename, run: () => doRename(null, 'selected') });
    c.push({ id: 'rename:all', g: 'Layers', n: 'Rename all layers', i: ICON.rename, run: () => doRename(null, 'all') });
    c.push({ id: 'copy', g: 'Style', n: 'Copy style', i: ICON.copy, run: () => doCopy() });
    c.push({ id: 'paste', g: 'Style', n: 'Paste style', i: ICON.paste, run: () => doPaste() });
    c.push({ id: 'beat:find', g: 'Beat', n: 'Find beats in selected layer', i: ICON.beat, run: () => { go('beat'); setTimeout(analyze, 50); } });
    c.push({ id: 'beat:snap', g: 'Beat', n: 'Snap layers to beats', i: ICON.snap, run: () => doSnap('snap') });
    c.push({ id: 'beat:sequence', g: 'Beat', n: 'Sequence layers on beats', i: ICON.seq, run: () => doSnap('sequence') });
    store.get('curves', []).forEach((cv) => c.push({ id: 'curve:' + cv.name, g: 'Curve', n: cv.name, i: ICON.curves, run: () => applyCurve(cv.name, cv.b) }));
    PRESETS.forEach(([n, b]) => c.push({ id: 'curve:' + n, g: 'Curve', n, i: ICON.curves, run: () => applyCurve(n, b) }));
    favs().forEach((f) => c.push({ id: 'fx:' + f.m, g: 'Effect', n: f.n, i: ICON.effects, run: () => doFx(f) }));
    (allFx || []).forEach((f) => { if (!favs().some((x) => x.m === f.m)) c.push({ id: 'fx:' + f.m, g: 'Effect', n: f.n, i: ICON.effects, run: () => doFx(f), low: true }); });
    TABS.forEach(([k, n]) => c.push({ id: 'go:' + k, g: 'Go to', n, i: ICON[k], run: () => go(k) }));
    c.push({ id: 'guide', g: 'Help', n: 'Show the quick guide', i: ICON.search, run: () => showGuide(0) });
    return c;
  }
  function score(q, s) {
    if (!q) return 1;
    s = s.toLowerCase(); q = q.toLowerCase();
    const at = s.indexOf(q);
    if (at === 0) return 100; if (at > 0) return 80 - at;
    let i = 0; for (const ch of s) if (ch === q[i]) i++;
    return i === q.length ? 20 : 0;
  }
  const hl = (s, q) => { if (!q) return esc(s); const at = s.toLowerCase().indexOf(q.toLowerCase()); return at < 0 ? esc(s) : esc(s.slice(0, at)) + `<mark>${esc(s.slice(at, at + q.length))}</mark>` + esc(s.slice(at + q.length)); };
  let palItems = [], palSel = 0, palRecent = 0;
  function openPal() {
    closePop(); loadFx();
    $('#pal').hidden = false; $('#palQ').value = ''; $('#palKey').textContent = keyLabel(hotkey);
    listPal(); setTimeout(() => $('#palQ').focus(), 0);
  }
  const closePal = () => { $('#pal').hidden = true; };
  function listPal() {
    const q = $('#palQ').value.trim();
    const all = commands();
    palItems = all.map((c) => ({ ...c, s: score(q, c.n) + (c.low ? -5 : 0) })).filter((c) => c.s > 0 && (q || !c.low)).sort((a, b) => b.s - a.s).slice(0, 40);
    palRecent = 0;
    if (!q) {
      const rec = store.get('recent', []).map((id) => all.find((c) => c.id === id)).filter(Boolean);
      palItems = [...rec, ...palItems.filter((c) => !rec.includes(c) && !rec.some((r) => r.id === c.id))];
      palRecent = rec.length;
    }
    palSel = 0; drawPal(q);
  }
  function drawPal(q = $('#palQ').value.trim()) {
    const head = (i) => (palRecent && !q ? (i === 0 ? '<div class="pal-h cap">Recent</div>' : i === palRecent ? '<div class="pal-h cap">All actions</div>' : '') : '');
    $('#palList').innerHTML = palItems.length ? palItems.map((c, i) => `${head(i)}<div class="pi ${i === palSel ? 'sel' : ''}" data-i="${i}">${c.i}<span class="nm">${hl(c.n, q)}</span><span class="grp">${c.g}</span></div>`).join('') : '<div class="pal-empty">No action found</div>';
    $$('.pi').forEach((el) => { el.addEventListener('mousemove', () => { if (palSel !== Number(el.dataset.i)) { palSel = Number(el.dataset.i); drawPal(); } }); el.addEventListener('click', () => runPal(Number(el.dataset.i))); });
    $('.pi.sel')?.scrollIntoView({ block: 'nearest' });
  }
  function runPal(i) { const c = palItems[i]; if (!c) return; closePal(); if (!ctx.comp && c.g !== 'Go to' && c.g !== 'Help') return status(ERR.NO_COMP, 'err'); c.run(); }
  $('#palQ').addEventListener('input', listPal);
  $('#palQ').addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); palSel = Math.min(palItems.length - 1, palSel + 1); drawPal(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); palSel = Math.max(0, palSel - 1); drawPal(); }
    else if (e.key === 'Enter') { e.preventDefault(); runPal(palSel); }
    else if (e.key === 'Escape') { e.preventDefault(); closePal(); }
  });
  $('#pal').addEventListener('mousedown', (e) => { if (e.target.id === 'pal') closePal(); });

  // global menu: shortcut recorder + about
  let recording = false;
  function openMenu(btn) {
    openPop(btn, `<div class="ph cap">Search shortcut</div>
      <div class="opt" id="mKeyRow"><span class="k">Open the search</span><kbd id="mKey">${esc(keyLabel(hotkey))}</kbd></div>
      <div class="opt" id="mKeyReset"><span class="k" style="color:var(--muted)">Reset to ${esc(keyLabel(DEFAULT_KEY))}</span></div>
      <div class="ph" style="color:var(--dim);font-size:10px;padding-top:0">The shortcut works while the panel is focused.</div>
      <hr><div class="opt" id="mGuide"><span class="k">Quick guide</span></div>
      <div class="opt" id="mSite"><span class="k">Nothi website</span><span style="color:var(--dim)">↗</span></div>
      <div class="ph" style="color:var(--dim);font-size:10px">Nothi Toolkit ${VERSION} · free</div>`, (p) => {
      $('#mGuide', p).addEventListener('click', () => { closePop(); showGuide(0); });
      $('#mKeyRow', p).addEventListener('click', () => { recording = true; const k = $('#mKey', p); k.textContent = 'Press keys…'; k.classList.add('rec'); });
      $('#mKeyReset', p).addEventListener('click', () => { hotkey = { ...DEFAULT_KEY }; store.set('hotkey', hotkey); registerHotkey(); $('#mKey', p).textContent = keyLabel(hotkey); status(`Search shortcut: ${keyLabel(hotkey)}`); });
      $('#mSite', p).addEventListener('click', () => { if (CEP && window.cep && window.cep.util) window.cep.util.openURLInDefaultBrowser(SITE); else window.open(SITE, '_blank'); });
    });
  }
  document.addEventListener('keydown', (e) => {
    if (recording) {
      e.preventDefault();
      if (['Control', 'Shift', 'Alt', 'Meta'].includes(e.key)) return;
      if (e.key === 'Escape') { recording = false; $('#mKey') && ($('#mKey').textContent = keyLabel(hotkey)); return; }
      const k = { key: e.key.length === 1 ? e.key.toUpperCase() : e.key, code: e.code, ctrl: e.ctrlKey, meta: e.metaKey, shift: e.shiftKey, alt: e.altKey };
      if (!k.ctrl && !k.meta && !k.alt && !/^F\d+$/.test(k.key)) { const el = $('#mKey'); if (el) el.textContent = 'Add Ctrl, Alt or ⌘'; return; }
      hotkey = k; store.set('hotkey', k); registerHotkey(); recording = false;
      const el = $('#mKey'); if (el) { el.textContent = keyLabel(k); el.classList.remove('rec'); }
      status(`Search shortcut: ${keyLabel(k)}`);
      return;
    }
    if (matches(e, hotkey)) { e.preventDefault(); if ($('#pal').hidden) openPal(); else closePal(); }
    else if (e.key === 'Escape') { closePop(); closePal(); hideGuide(); }
  });

  // ───────────────────────── first-run guide (3 steps, shown once)
  const GUIDE = () => [
    { i: '<i class="logo" style="width:22px;height:17px;margin:0"></i>', h: 'Six tools, one small panel', p: 'Create, Curves, Beat, Layers, Style and Effects live in the tabs at the top. Hover anything to see what it does.' },
    { i: ICON.search, h: 'Search every action', p: `Press <kbd>${esc(keyLabel(hotkey))}</kbd> while the panel is focused, type a few letters, hit Enter. You can change the shortcut in the ··· menu.` },
    { i: ICON.undo, h: 'Options and undo', p: 'The sliders icon holds each tool’s options. After every action, <b style="color:var(--text)">Undo</b> appears at the bottom, and Ctrl/Cmd+Z works as usual.' },
  ];
  let guideAt = -1;
  function showGuide(i) {
    const steps = GUIDE(), st = steps[i], g = $('#guide');
    guideAt = i; g.hidden = false;
    g.innerHTML = `<div class="guide-box"><div class="guide-step"><span>${i + 1} / ${steps.length}</span><span class="guide-dots">${steps.map((_, j) => `<i class="${j === i ? 'on' : ''}"></i>`).join('')}</span></div>
      <div class="gi">${st.i}</div><h3>${st.h}</h3><p>${st.p}</p>
      <div class="guide-nav"><button class="skip" id="gSkip">${i === steps.length - 1 ? '' : 'Skip'}</button><button class="b main" id="gNext">${i === steps.length - 1 ? 'Start' : 'Next'}</button></div></div>`;
    $('#gSkip', g).addEventListener('click', hideGuide);
    $('#gNext', g).addEventListener('click', () => (i < steps.length - 1 ? showGuide(i + 1) : hideGuide()));
    setTimeout(() => $('#gNext', g)?.focus(), 0);
  }
  function hideGuide() { if (guideAt < 0) return; guideAt = -1; $('#guide').hidden = true; store.set('guided', true); }
  $('#guide').addEventListener('mousedown', (e) => { if (e.target.id === 'guide') hideGuide(); });

  // ───────────────────────── tooltips: "Name · tip" titles become a small card (native titles are slow and plain)
  const tip = $('#tip');
  let tipEl = null, tipTimer = 0;
  document.addEventListener('mouseover', (e) => {
    const el = e.target.closest('[title],[data-tip]');
    if (el === tipEl) return;
    clearTimeout(tipTimer); tip.classList.remove('show'); tipEl = el;
    if (!el) return;
    if (el.hasAttribute('title')) { el.dataset.tip = el.getAttribute('title'); el.removeAttribute('title'); }
    tipTimer = setTimeout(() => {
      if (!document.contains(el) || !$('#pal').hidden) return;
      const [h, ...rest] = el.dataset.tip.split(' · ');
      tip.innerHTML = `<b>${esc(h)}</b>${rest.length ? `<small>${esc(rest.join(' · '))}</small>` : ''}`;
      const r = el.getBoundingClientRect(), tw = tip.offsetWidth, th = tip.offsetHeight;
      let x = Math.min(innerWidth - tw - 4, Math.max(4, r.left + r.width / 2 - tw / 2));
      let y = r.bottom + 6; if (y + th > innerHeight - 4) y = r.top - th - 6;
      tip.style.left = `${x}px`; tip.style.top = `${Math.max(4, y)}px`; tip.classList.add('show');
    }, 550);
  });
  document.addEventListener('mousedown', () => { clearTimeout(tipTimer); tip.classList.remove('show'); });
  document.addEventListener('mouseleave', () => { clearTimeout(tipTimer); tip.classList.remove('show'); tipEl = null; });

  // ───────────────────────── preview mode (outside After Effects)
  function MOCK(fn, args) {
    const ok = (o = {}) => ({ ok: true, ...o });
    switch (fn) {
      case 'nt_context': return ok({ comp: 'Edit_Final', w: 1920, h: 1080, fps: 30, selected: 2 });
      case 'nt_create': return ok({ name: (args[1] && args[1].name) || { text: 'Your text', adjustment: 'Adjustment Layer', solid: 'Solid', null: 'Control', shape: 'Shape', camera: 'Camera', light: 'Light' }[args[0]] });
      case 'nt_curveRead': return ok({ curve: { outInf: 82, inInf: 64, outRatio: 0, inRatio: 0 } });
      case 'nt_curveApply': return ok({ count: 3 });
      case 'nt_audioInfo': return ok({ path: 'demo.wav', name: 'Phonk_Edit.wav', index: 1, startTime: 0, inPoint: 1.5, outPoint: 10.5, stretch: 100, workStart: 2, workEnd: 8 });
      case 'nt_beatMarkers': return ok({ count: args[1].length });
      case 'nt_clearMarkers': return ok({ count: 0 });
      case 'nt_anchor': return ok({ count: 2, skipped: 0 });
      case 'nt_precompose': return ok({ name: 'Clip 04 +1' });
      case 'nt_decompose': return ok({ name: 'Intro', count: 5, lost: [], deleted: false });
      case 'nt_rename': return ok({ count: 8 });
      case 'nt_styleCopy': return ok({ layer: 'Title Glow', effects: ['Glow', 'Gaussian Blur', 'Fill', 'Turbulent Displace'] });
      case 'nt_stylePaste': return ok({ count: 3 });
      case 'nt_listEffects': return ok({ effects: [['Gaussian Blur', 'ADBE Gaussian Blur 2', 'Blur & Sharpen'], ['Camera Lens Blur', 'ADBE Camera Lens Blur', 'Blur & Sharpen'], ['Glow', 'ADBE Glo2', 'Stylize'], ['Gradient Ramp', 'ADBE Ramp', 'Generate'], ['Fractal Noise', 'ADBE Fractal Noise', 'Noise & Grain'], ['Wave Warp', 'ADBE Wave Warp', 'Distort'], ['CC Light Rays', 'CC Light Rays', 'Generate']].map(([n, m, c]) => ({ n, m, c })) });
      case 'nt_applyEffect': return ok({ count: 2, adjustment: !!args[2] });
      case 'nt_snapLayers': return ok({ count: 3 });
      default: return ok();
    }
  }

  // ───────────────────────── boot
  $('#btnSearch').innerHTML = ICON.search; $('#btnTabSettings').innerHTML = ICON.sliders; $('#btnMenu').innerHTML = ICON.menu; $('#palIcon').innerHTML = ICON.search;
  $('#btnSearch').title = `Search · Every action of the toolkit (${keyLabel(hotkey)})`;
  $('#btnTabSettings').title = 'Options · Settings of the current tool';
  $('#btnMenu').title = 'Toolkit · Shortcut, quick guide, website';
  $('#stUndo').addEventListener('click', async () => { const r = await host('nt_undo'); $('#stUndo').hidden = true; status(r.ok ? 'Undone' : 'Nothing to undo', r.ok ? 'done' : 'err'); });
  $('#btnSearch').addEventListener('click', openPal);
  $('#btnTabSettings').addEventListener('click', (e) => { const o = VIEWS[current].options; if (o) o(e.currentTarget); else status('No options for this tool'); });
  $('#btnMenu').addEventListener('click', (e) => openMenu(e.currentTarget));
  renderTabs(); render(); registerHotkey();
  if (!store.get('guided', false) && !/noguide/.test(location.search)) setTimeout(() => showGuide(0), 400);
  poll(); setInterval(poll, 1500);
  window.__nothi = { go, openPal, analyze, status, showGuide, hideGuide, play, stop, doSnap, openOptions: () => $('#btnTabSettings').click(), openMenu: () => $('#btnMenu').click() };
})();
