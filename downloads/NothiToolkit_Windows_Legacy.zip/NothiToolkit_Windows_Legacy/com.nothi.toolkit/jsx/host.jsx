/*  Nothi Toolkit — After Effects side (ExtendScript, ES3).
    Every public function returns a JSON string: { ok: true, ... } or { ok: false, error: "..." }.
    Each action is wrapped in its own undo group, so Ctrl/Cmd+Z undoes it in one step. */

// ───────────────────────── JSON (ExtendScript has no native JSON)
function nt_json(v) {
  var t = typeof v;
  if (v === null || t === 'undefined') return 'null';
  if (t === 'number') return isFinite(v) ? String(v) : 'null';
  if (t === 'boolean') return v ? 'true' : 'false';
  if (t === 'string') {
    return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
  }
  if (v instanceof Array) { var a = []; for (var i = 0; i < v.length; i++) a.push(nt_json(v[i])); return '[' + a.join(',') + ']'; }
  var o = []; for (var k in v) { if (v.hasOwnProperty(k)) o.push(nt_json(String(k)) + ':' + nt_json(v[k])); }
  return '{' + o.join(',') + '}';
}
function nt_ok(o) { o = o || {}; o.ok = true; return nt_json(o); }
function nt_err(msg) { return nt_json({ ok: false, error: msg }); }
function nt_comp() { var c = app.project && app.project.activeItem; return (c && c instanceof CompItem) ? c : null; }
function nt_run(name, fn) {
  var comp = nt_comp();
  if (!comp) return nt_err('NO_COMP');
  app.beginUndoGroup('Nothi: ' + name);
  try { var r = fn(comp); app.endUndoGroup(); return r; }
  catch (e) { app.endUndoGroup(); return nt_err(String(e.message || e)); }
}

// ───────────────────────── context (polled by the panel)
function nt_context() {
  var c = nt_comp();
  if (!c) return nt_ok({ comp: null });
  var sel = c.selectedLayers, names = [];
  var aud = null;
  for (var i = 0; i < sel.length; i++) {
    if (i < 3) names.push(sel[i].name);
    if (!aud && sel[i].hasAudio && sel[i].source && sel[i].source.file) aud = { i: sel[i].index, n: sel[i].name, id: sel[i].source.id, a: sel[i].inPoint, b: sel[i].outPoint };
  }
  return nt_ok({ comp: c.name, w: c.width, h: c.height, fps: Math.round(c.frameRate * 100) / 100, selected: sel.length, names: names, aud: aud });
}

// ───────────────────────── CREATE
function nt_create(type, opts) {
  opts = opts || {};
  return nt_run('Add ' + type, function (comp) {
    var sel = comp.selectedLayers, ref = sel.length ? sel[0] : null;
    var w = comp.width, h = comp.height, d = comp.duration, l;
    var col = opts.color || [0.55, 0.48, 1];
    if (type === 'text') {
      l = comp.layers.addText(opts.text || 'Your text');
      var td = l.property('Source Text').value;
      td.fontSize = Math.round(h / 9); td.fillColor = [1, 1, 1]; td.justification = ParagraphJustification.CENTER_JUSTIFY;
      l.property('Source Text').setValue(td);
      var r = l.sourceRectAtTime(comp.time, false);
      l.property('Anchor Point').setValue([r.left + r.width / 2, r.top + r.height / 2]);
      l.property('Position').setValue([w / 2, h / 2]);
    } else if (type === 'adjustment') {
      l = comp.layers.addSolid([1, 1, 1], opts.name || 'Adjustment Layer', w, h, comp.pixelAspect, d);
      l.adjustmentLayer = true; l.label = 5;
    } else if (type === 'solid') {
      l = comp.layers.addSolid(col, opts.name || 'Solid', w, h, comp.pixelAspect, d);
    } else if (type === 'null') {
      l = comp.layers.addNull(d); l.name = opts.name || 'Control';
      l.property('Position').setValue([w / 2, h / 2]);
    } else if (type === 'camera') {
      l = comp.layers.addCamera(opts.name || 'Camera', [w / 2, h / 2]);
    } else if (type === 'light') {
      l = comp.layers.addLight(opts.name || 'Light', [w / 2, h / 2]);
    } else if (type === 'shape') {
      l = comp.layers.addShape(); l.name = opts.name || 'Shape';
      var grp = l.property('Contents').addProperty('ADBE Vector Group');
      var rect = grp.property('Contents').addProperty('ADBE Vector Shape - Rect');
      rect.property('Size').setValue([Math.round(w / 3), Math.round(h / 3)]);
      rect.property('Roundness').setValue(Math.round(h / 40));
      var fill = grp.property('Contents').addProperty('ADBE Vector Graphic - Fill');
      fill.property('Color').setValue(col);
      l.property('Position').setValue([w / 2, h / 2]);
    } else return nt_err('UNKNOWN_TYPE');
    if (opts.name && type !== 'null' && type !== 'shape') try { l.name = opts.name; } catch (e1) {}
    if (ref) {
      l.moveBefore(ref);
      if (opts.matchDuration) { l.inPoint = Math.max(0, ref.inPoint); l.outPoint = ref.outPoint; }
    } else if (opts.fromPlayhead) { l.inPoint = comp.time; }
    for (var i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
    l.selected = true;
    return nt_ok({ name: l.name });
  });
}

// ───────────────────────── CURVES (temporal ease, stored as ratios of the average speed)
function nt_isEaseable(p) { return p && p.propertyType === PropertyType.PROPERTY && p.numKeys > 1 && p.propertyValueType !== PropertyValueType.NO_VALUE && p.propertyValueType !== PropertyValueType.CUSTOM_VALUE && p.propertyValueType !== PropertyValueType.SHAPE && p.propertyValueType !== PropertyValueType.TEXT_DOCUMENT && p.propertyValueType !== PropertyValueType.MARKER; }
function nt_avgSpeeds(p, k) { // per-dimension average speed between key k and k+1
  var v1 = p.keyValue(k), v2 = p.keyValue(k + 1), dt = p.keyTime(k + 1) - p.keyTime(k);
  if (dt <= 0) dt = 1e-6;
  var spatial = p.isSpatial;
  if (!(v1 instanceof Array)) return [Math.abs(v2 - v1) / dt];
  if (spatial) { var s = 0; for (var i = 0; i < v1.length; i++) s += (v2[i] - v1[i]) * (v2[i] - v1[i]); return [Math.sqrt(s) / dt]; }
  var out = []; for (var j = 0; j < v1.length; j++) out.push(Math.abs(v2[j] - v1[j]) / dt); return out;
}
function nt_selectedPairs(comp) {
  var props = comp.selectedProperties, pairs = [];
  for (var i = 0; i < props.length; i++) {
    var p = props[i]; if (!nt_isEaseable(p)) continue;
    var keys = p.selectedKeys; if (!keys || keys.length === 0) continue;
    if (keys.length === 1) { if (keys[0] < p.numKeys) pairs.push([p, keys[0]]); continue; }
    for (var k = 0; k < keys.length - 1; k++) pairs.push([p, keys[k]]);
  }
  return pairs;
}
function nt_curveRead() {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var pairs = nt_selectedPairs(comp);
  if (!pairs.length) return nt_err('NO_KEYS');
  var p = pairs[0][0], k = pairs[0][1];
  var avg = nt_avgSpeeds(p, k)[0] || 1e-6;
  var o = p.keyOutTemporalEase(k)[0], n = p.keyInTemporalEase(k + 1)[0];
  return nt_ok({ curve: { outInf: o.influence, inInf: n.influence, outRatio: Math.abs(o.speed) / avg, inRatio: Math.abs(n.speed) / avg }, prop: p.name });
}
function nt_curveApply(c) {
  return nt_run('Apply curve', function (comp) {
    var pairs = nt_selectedPairs(comp);
    if (!pairs.length) return nt_err('NO_KEYS');
    var done = 0;
    for (var i = 0; i < pairs.length; i++) {
      var p = pairs[i][0], k = pairs[i][1];
      var avg = nt_avgSpeeds(p, k), dims = p.keyOutTemporalEase(k).length;
      var outE = [], inE = [];
      for (var d = 0; d < dims; d++) {
        var a = avg[Math.min(d, avg.length - 1)];
        outE.push(new KeyframeEase(c.outRatio * a, Math.max(0.1, Math.min(100, c.outInf))));
        inE.push(new KeyframeEase(c.inRatio * a, Math.max(0.1, Math.min(100, c.inInf))));
      }
      p.setInterpolationTypeAtKey(k, p.keyInInterpolationType(k), KeyframeInterpolationType.BEZIER);
      p.setInterpolationTypeAtKey(k + 1, KeyframeInterpolationType.BEZIER, p.keyOutInterpolationType(k + 1));
      p.setTemporalEaseAtKey(k, p.keyInTemporalEase(k), outE);
      p.setTemporalEaseAtKey(k + 1, inE, p.keyOutTemporalEase(k + 1));
      done++;
    }
    return nt_ok({ count: done });
  });
}

// ───────────────────────── BEAT
function nt_audioInfo() {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var sel = comp.selectedLayers, l = null;
  for (var i = 0; i < sel.length; i++) if (sel[i].hasAudio && sel[i].source && sel[i].source.file) { l = sel[i]; break; }
  if (!l) return nt_err('NO_AUDIO');
  return nt_ok({ path: l.source.file.fsName, sourceId: l.source.id, name: l.name, index: l.index, startTime: l.startTime, inPoint: l.inPoint, outPoint: l.outPoint, stretch: l.stretch, timeRemap: l.timeRemapEnabled, compDuration: comp.duration, workStart: comp.workAreaStart, workEnd: comp.workAreaStart + comp.workAreaDuration });
}
function nt_beatMarkers(index, times, target, label) {
  return nt_run('Beat markers', function (comp) {
    var l = comp.layer(index), mk = (target === 'comp') ? comp.markerProperty : l.property('Marker');
    var n = 0;
    for (var i = 0; i < times.length; i++) {
      var mv = new MarkerValue(label ? String(i + 1) : '');
      mv.label = 7;
      mk.setValueAtTime(times[i], mv); n++;
    }
    return nt_ok({ count: n });
  });
}
function nt_clearMarkers(index, target) {
  return nt_run('Clear markers', function (comp) {
    var mk = (target === 'comp') ? comp.markerProperty : comp.layer(index).property('Marker');
    var n = mk.numKeys; for (var i = n; i >= 1; i--) mk.removeKey(i);
    return nt_ok({ count: n });
  });
}

// ───────────────────────── ANCHOR (moves the anchor, the layer stays in place)
// Moves the anchor to a spot of the layer's box (0..1), compensating the position so nothing moves.
function nt_moveAnchor(l, ax, ay, t) {
  var tg = l.property('ADBE Transform Group'), ap = tg.property('ADBE Anchor Point');
  if (ap.numKeys > 0) return false;
  var r = l.sourceRectAtTime(t, false);
  var oldA = ap.value, newA = [r.left + r.width * ax, r.top + r.height * ay];
  var dx = newA[0] - oldA[0], dy = newA[1] - oldA[1];
  var sc = tg.property('ADBE Scale').valueAtTime(t, false);
  var rotP = tg.property('ADBE Rotate Z');
  var rot = (rotP ? rotP.valueAtTime(t, false) : 0) * Math.PI / 180;
  var sx = sc[0] / 100, sy = sc[1] / 100;
  var px = dx * sx * Math.cos(rot) - dy * sy * Math.sin(rot);
  var py = dx * sx * Math.sin(rot) + dy * sy * Math.cos(rot);
  var pos = tg.property('ADBE Position');
  if (pos.dimensionsSeparated) { nt_offset(tg.property('ADBE Position_0'), px); nt_offset(tg.property('ADBE Position_1'), py); }
  else nt_offsetVec(pos, px, py);
  ap.setValue(l.threeDLayer ? [newA[0], newA[1], oldA[2] || 0] : [newA[0], newA[1]]);
  return true;
}
function nt_anchor(ax, ay) {
  return nt_run('Anchor point', function (comp) {
    var sel = comp.selectedLayers, n = 0, skipped = 0;
    for (var i = 0; i < sel.length; i++) {
      var l = sel[i];
      if (l instanceof CameraLayer || l instanceof LightLayer) { skipped++; continue; }
      if (nt_moveAnchor(l, ax, ay, comp.time)) n++; else skipped++;
    }
    return nt_ok({ count: n, skipped: skipped });
  });
}
function nt_offset(p, d) { if (p.numKeys) { for (var k = 1; k <= p.numKeys; k++) p.setValueAtKey(k, p.keyValue(k) + d); } else p.setValue(p.value + d); }
function nt_offsetVec(p, dx, dy) {
  var f = function (v) { var o = [v[0] + dx, v[1] + dy]; if (v.length > 2) o.push(v[2]); return o; };
  if (p.numKeys) { for (var k = 1; k <= p.numKeys; k++) p.setValueAtKey(k, f(p.keyValue(k))); } else p.setValue(f(p.value));
}

// ───────────────────────── PRECOMPOSE SMART
function nt_precompose(name, trim) {
  return nt_run('Smart precompose', function (comp) {
    var sel = comp.selectedLayers; if (!sel.length) return nt_err('NO_SELECTION');
    var idx = [], minIn = 1e9, maxOut = -1e9, top = sel[0];
    for (var i = 0; i < sel.length; i++) { idx.push(sel[i].index); minIn = Math.min(minIn, sel[i].inPoint); maxOut = Math.max(maxOut, sel[i].outPoint); if (sel[i].index < top.index) top = sel[i]; }
    var nm = name || (sel.length === 1 ? sel[0].name : top.name + ' +' + (sel.length - 1));
    var nc = comp.layers.precompose(idx, nm, true);
    var pl = null; for (var j = 1; j <= comp.numLayers; j++) if (comp.layer(j).source === nc) { pl = comp.layer(j); break; }
    if (trim && pl && maxOut > minIn) {
      for (var k = 1; k <= nc.numLayers; k++) { var L = nc.layer(k); var locked = L.locked; L.locked = false; L.startTime -= minIn; L.locked = locked; }
      nc.duration = maxOut - minIn;
      pl.startTime = minIn;
    }
    // The precomp layer takes the composition color from After Effects' label preferences (Sandstone by default),
    // so it stands out from the layers it contains.
    if (pl) { pl.label = nc.label > 0 ? nc.label : 15; pl.name = nm; }
    return nt_ok({ name: nm, duration: nc.duration });
  });
}

// ───────────────────────── DECOMPOSE (bring the layers of a precomp back into this comp)
function nt_isIdentity(l, inner, comp) {
  var tr = l.property('ADBE Transform Group');
  var a = tr.property('ADBE Anchor Point').value, p = tr.property('ADBE Position').value, s = tr.property('ADBE Scale').value, r = tr.property('ADBE Rotate Z').value;
  var animated = tr.property('ADBE Position').numKeys || tr.property('ADBE Scale').numKeys || tr.property('ADBE Rotate Z').numKeys || tr.property('ADBE Anchor Point').numKeys;
  return !animated && !l.parent && !l.threeDLayer && Math.abs(a[0] - p[0]) < 0.01 && Math.abs(a[1] - p[1]) < 0.01 && Math.abs(s[0] - 100) < 0.01 && Math.abs(s[1] - 100) < 0.01 && Math.abs(r) < 0.01 && inner.width === comp.width && inner.height === comp.height;
}
function nt_decompose(removeItem) {
  return nt_run('Decompose', function (comp) {
    var sel = comp.selectedLayers, l = null;
    for (var i = 0; i < sel.length; i++) if (sel[i].source instanceof CompItem) { l = sel[i]; break; }
    if (!l) return nt_err('NO_PRECOMP');
    var inner = l.source, offset = l.startTime, lost = [];
    if (l.timeRemapEnabled) lost.push('time remap');
    if (l.stretch !== 100) lost.push('time stretch');
    if (l.property('ADBE Effect Parade').numProperties) lost.push('effects');
    if (l.property('ADBE Mask Parade').numProperties) lost.push('masks');
    if (l.property('ADBE Transform Group').property('ADBE Opacity').value !== 100) lost.push('opacity');
    // a null that carries the precomp layer's transform, so everything stays exactly where it was
    var holder = null;
    if (!nt_isIdentity(l, inner, comp)) {
      holder = comp.layers.addNull(comp.duration);
      holder.name = l.name + ' (transform)';
      holder.threeDLayer = l.threeDLayer;
      var src = l.property('ADBE Transform Group'), dst = holder.property('ADBE Transform Group');
      var names = ['ADBE Anchor Point', 'ADBE Position', 'ADBE Scale', 'ADBE Rotate Z'];
      for (var n = 0; n < names.length; n++) {
        var sp = src.property(names[n]), dp = dst.property(names[n]);
        if (sp.numKeys) { for (var k = 1; k <= sp.numKeys; k++) dp.setValueAtTime(sp.keyTime(k), sp.keyValue(k)); }
        else dp.setValue(sp.value);
      }
      if (l.parent) holder.setParentWithJump(l.parent);
      holder.inPoint = l.inPoint; holder.outPoint = l.outPoint;
    }
    var copies = [];
    for (var j = inner.numLayers; j >= 1; j--) { inner.layer(j).copyToComp(comp); copies.unshift(comp.layer(1)); }
    for (var c = 0; c < copies.length; c++) {
      var L = copies[c];
      L.moveBefore(l);
      L.startTime += offset;
      try { if (L.inPoint < l.inPoint) L.inPoint = l.inPoint; if (L.outPoint > l.outPoint) L.outPoint = l.outPoint; } catch (e1) {}
      if (holder && !L.parent) L.setParentWithJump(holder);
    }
    if (holder) holder.moveBefore(copies[0]);
    var nm = l.name;
    l.remove();
    var deleted = false;
    if (removeItem && inner.usedIn.length === 0) { inner.remove(); deleted = true; }
    return nt_ok({ name: nm, count: copies.length, lost: lost, deleted: deleted, holder: !!holder });
  });
}

// ───────────────────────── SMART RENAME
function nt_kind(l) {
  if (l instanceof CameraLayer) return 'CAM';
  if (l instanceof LightLayer) return 'LIGHT';
  if (l instanceof TextLayer) return 'TXT';
  if (l instanceof ShapeLayer) return 'SHAPE';
  if (l.nullLayer) return 'NULL';
  if (l.adjustmentLayer) return 'ADJ';
  var s = l.source;
  if (s instanceof CompItem) return 'COMP';
  if (s && s.mainSource instanceof SolidSource) return 'SOLID';
  if (s && s.mainSource && s.mainSource.isStill) return 'IMG';
  if (s && !s.hasVideo && s.hasAudio) return 'AUDIO';
  return 'VID';
}
function nt_desc(l, kind) {
  try {
    if (kind === 'TXT') { var t = String(l.property('Source Text').value.text).replace(/[\r\n]+/g, ' '); return t.length > 26 ? t.substr(0, 25) + '…' : t; }
    if (kind === 'ADJ') { var fx = l.property('ADBE Effect Parade'); return fx.numProperties ? fx.property(1).name : 'Adjustment'; }
    if (kind === 'SHAPE') { var c = l.property('Contents'); return c.numProperties ? c.property(1).name : 'Shape'; }
    if (kind === 'COMP') return l.source.name;
    if (kind === 'SOLID') return l.source.name;
    if (kind === 'IMG' || kind === 'VID' || kind === 'AUDIO') { var f = l.source.file ? l.source.file.name : l.source.name; return decodeURI(f).replace(/\.[^.]+$/, ''); }
    if (kind === 'NULL') return 'Control';
    if (kind === 'CAM') return 'Camera';
    if (kind === 'LIGHT') return 'Light';
  } catch (e) {}
  return l.name;
}
function nt_rename(scope, tags) {
  return nt_run('Smart rename', function (comp) {
    var list = [];
    if (scope === 'all') { for (var i = 1; i <= comp.numLayers; i++) list.push(comp.layer(i)); } else list = comp.selectedLayers;
    if (!list.length) return nt_err('NO_SELECTION');
    var seen = {}, out = [];
    for (var j = 0; j < list.length; j++) {
      var l = list[j], kind = nt_kind(l), d = nt_desc(l, kind);
      var nm = tags ? kind + ' – ' + d : d;
      var base = nm, n = 2; while (seen[nm]) nm = base + ' ' + (n++); seen[nm] = true;
      var locked = l.locked; l.locked = false; l.name = nm; l.locked = locked;
      if (out.length < 6) out.push(nm);
    }
    return nt_ok({ count: list.length, sample: out });
  });
}

// ───────────────────────── STYLE COPY / PASTE
$.global.nt_style = $.global.nt_style || null;
// Keyframes are stored with their full speed graph (interpolation, ease speed + influence, tangents),
// so a pasted animation moves exactly like the original.
function nt_readKeys(p) {
  var ks = [], spatial = false;
  try { spatial = p.isSpatial; } catch (e0) {}
  for (var k = 1; k <= p.numKeys; k++) {
    var e = { t: p.keyTime(k), v: p.keyValue(k) };
    try { e.ii = p.keyInInterpolationType(k); e.oi = p.keyOutInterpolationType(k); } catch (e1) {}
    try {
      var ie = p.keyInTemporalEase(k), oe = p.keyOutTemporalEase(k); e.ie = []; e.oe = [];
      for (var d = 0; d < ie.length; d++) { e.ie.push([ie[d].speed, ie[d].influence]); e.oe.push([oe[d].speed, oe[d].influence]); }
    } catch (e2) {}
    try { e.tc = p.keyTemporalContinuous(k); e.ab = p.keyTemporalAutoBezier(k); } catch (e3) {}
    if (spatial) { try { e.si = p.keyInSpatialTangent(k); e.so = p.keyOutSpatialTangent(k); e.sc = p.keySpatialContinuous(k); e.sab = p.keySpatialAutoBezier(k); } catch (e4) {} }
    ks.push(e);
  }
  return ks;
}
// map: { a: source in, b: target in, k: time scale }. Speeds are divided by k so the graph keeps its shape.
function nt_writeKeys(p, ks, map) {
  var times = [], vals = [], i;
  for (i = 0; i < ks.length; i++) { times.push(map.b + (ks[i].t - map.a) * map.k); vals.push(ks[i].v); }
  p.setValuesAtTimes(times, vals);
  for (i = 0; i < ks.length; i++) {
    var e = ks[i], key = p.nearestKeyIndex(times[i]);
    try { if (e.ii !== undefined) p.setInterpolationTypeAtKey(key, e.ii, e.oi); } catch (x1) {}
    try { if (e.tc !== undefined) { p.setTemporalContinuousAtKey(key, e.tc); p.setTemporalAutoBezierAtKey(key, e.ab); } } catch (x2) {}
    if (e.ie && !e.ab) {
      try {
        var inE = [], outE = [];
        for (var d = 0; d < e.ie.length; d++) { inE.push(new KeyframeEase(e.ie[d][0] / map.k, e.ie[d][1])); outE.push(new KeyframeEase(e.oe[d][0] / map.k, e.oe[d][1])); }
        p.setTemporalEaseAtKey(key, inE, outE);
      } catch (x3) {}
    }
    if (e.si) { try { p.setSpatialTangentsAtKey(key, e.si, e.so); p.setSpatialContinuousAtKey(key, e.sc); p.setSpatialAutoBezierAtKey(key, e.sab); } catch (x4) {} }
  }
}
function nt_readProps(group, withKeys) {
  var out = [];
  for (var i = 1; i <= group.numProperties; i++) {
    var p = group.property(i), e = { i: i };
    if (p.propertyType === PropertyType.PROPERTY) {
      var vt = p.propertyValueType;
      if (vt === PropertyValueType.NO_VALUE || vt === PropertyValueType.CUSTOM_VALUE || vt === PropertyValueType.LAYER_INDEX || vt === PropertyValueType.MASK_INDEX) continue;
      try { e.v = p.value; } catch (x) { continue; }
      if (p.canSetExpression && p.expressionEnabled && p.expression) e.x = p.expression;
      if (withKeys && p.numKeys > 0) { e.k = nt_readKeys(p); $.global.nt_keyCount = ($.global.nt_keyCount || 0) + p.numKeys; }
      out.push(e);
    } else { e.g = nt_readProps(p, withKeys); if (e.g.length) out.push(e); }
  }
  return out;
}
function nt_writeProps(group, list, map) {
  for (var i = 0; i < list.length; i++) {
    var e = list[i], p; try { p = group.property(e.i); } catch (x) { continue; }
    if (!p) continue;
    if (e.g) { nt_writeProps(p, e.g, map); continue; }
    try {
      while (p.numKeys) p.removeKey(1);
      if (e.k && map) nt_writeKeys(p, e.k, map);
      else p.setValue(e.v);
      if (e.x) p.expression = e.x;
    } catch (y) {}
  }
}
function nt_styleCopy(withKeys) {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var l = comp.selectedLayers[0]; if (!l) return nt_err('NO_SELECTION');
  $.global.nt_keyCount = 0;
  var fxGroup = l.property('ADBE Effect Parade'), fx = [];
  for (var i = 1; i <= fxGroup.numProperties; i++) { var f = fxGroup.property(i); fx.push({ match: f.matchName, name: f.name, props: nt_readProps(f, withKeys) }); }
  var tr = l.property('ADBE Transform Group');
  $.global.nt_style = {
    layer: l.name, inPoint: l.inPoint, duration: l.outPoint - l.inPoint, keys: $.global.nt_keyCount, effects: fx,
    opacity: tr.property('ADBE Opacity').value, scale: tr.property('ADBE Scale').value, rotation: tr.property('ADBE Rotate Z').value,
    blend: l.blendingMode, motionBlur: l.motionBlur, threeD: l.threeDLayer
  };
  var names = []; for (var j = 0; j < fx.length; j++) names.push(fx[j].name);
  return nt_ok({ layer: l.name, effects: names, keys: $.global.nt_keyCount, duration: l.outPoint - l.inPoint });
}
// o.timing: 'shift' keeps the original timing from the clip's start; 'fit' stretches it to each clip's length.
function nt_stylePaste(o) {
  var s = $.global.nt_style; if (!s) return nt_err('NO_STYLE');
  return nt_run('Paste style', function (comp) {
    var sel = comp.selectedLayers; if (!sel.length) return nt_err('NO_SELECTION');
    var n = 0, fitted = 0;
    for (var i = 0; i < sel.length; i++) {
      var l = sel[i]; if (l instanceof CameraLayer || l instanceof LightLayer) continue;
      var map = null;
      if (o.keys && s.keys) {
        var d = l.outPoint - l.inPoint, k = (o.timing === 'fit' && s.duration > 0 && d > 0) ? d / s.duration : 1;
        map = { a: s.inPoint, b: l.inPoint, k: k };
        if (k !== 1) fitted++;
      }
      if (o.effects) {
        var fxg = l.property('ADBE Effect Parade');
        if (o.replace) for (var r = fxg.numProperties; r >= 1; r--) fxg.property(r).remove();
        for (var j = 0; j < s.effects.length; j++) {
          var fx = fxg.addProperty(s.effects[j].match);
          try { fx.name = s.effects[j].name; } catch (x) {}
          nt_writeProps(fx, s.effects[j].props, map);
        }
      }
      if (o.transform) {
        var tr = l.property('ADBE Transform Group');
        tr.property('ADBE Scale').setValue(l.threeDLayer && s.scale.length < 3 ? [s.scale[0], s.scale[1], 100] : (!l.threeDLayer && s.scale.length > 2 ? [s.scale[0], s.scale[1]] : s.scale));
        tr.property('ADBE Rotate Z').setValue(s.rotation);
      }
      if (o.blend) { l.blendingMode = s.blend; l.property('ADBE Transform Group').property('ADBE Opacity').setValue(s.opacity); l.motionBlur = s.motionBlur; }
      n++;
    }
    return nt_ok({ count: n, fitted: fitted });
  });
}

// ───────────────────────── SEQUENCE (selected layers one after another)
// order: 'stack' (top to bottom in the timeline) or 'selection' (the order you clicked them)
// start: 'first' (earliest selected clip) or 'playhead'. gap: frames between clips, negative = overlap.
function nt_sequence(order, start, gap) {
  return nt_run('Sequence layers', function (comp) {
    var sel = comp.selectedLayers, list = [], i;
    for (i = 0; i < sel.length; i++) list.push(sel[i]);
    if (list.length < 2) return nt_err('NEED_TWO');
    // 'bottom' (default): bottom layer plays first. 'stack': top layer first. 'selection' / 'selection-rev': click order.
    if (order === 'stack') list.sort(function (a, b) { return a.index - b.index; });
    else if (order === 'selection-rev') list.reverse();
    else if (order !== 'selection') list.sort(function (a, b) { return b.index - a.index; });
    var t;
    if (start === 'playhead') t = comp.time;
    else { t = list[0].inPoint; for (i = 1; i < list.length; i++) if (list[i].inPoint < t) t = list[i].inPoint; }
    var step = (gap || 0) * comp.frameDuration;
    for (i = 0; i < list.length; i++) {
      var L = list[i], locked = L.locked; L.locked = false;
      L.startTime += t - L.inPoint;
      t = L.outPoint + step;
      L.locked = locked;
    }
    return nt_ok({ count: list.length, end: t - step });
  });
}

// ───────────────────────── EFFECTS
function nt_listEffects() {
  var out = [];
  for (var i = 0; i < app.effects.length; i++) { var e = app.effects[i]; if (e.displayName) out.push({ n: e.displayName, m: e.matchName, c: e.category }); }
  return nt_ok({ effects: out });
}
function nt_applyEffect(match, name, forceAdjustment) {
  return nt_run('Apply ' + name, function (comp) {
    var sel = comp.selectedLayers, targets = [];
    for (var i = 0; i < sel.length; i++) if (!(sel[i] instanceof CameraLayer) && !(sel[i] instanceof LightLayer)) targets.push(sel[i]);
    var created = false;
    if (!targets.length || forceAdjustment) {
      var adj = comp.layers.addSolid([1, 1, 1], name, comp.width, comp.height, comp.pixelAspect, comp.duration);
      adj.adjustmentLayer = true; adj.label = 5;
      if (sel.length) adj.moveBefore(sel[0]);
      targets = [adj]; created = true;
    }
    for (var j = 0; j < targets.length; j++) {
      var fxg = targets[j].property('ADBE Effect Parade');
      if (!fxg.canAddProperty(match)) return nt_err('CANNOT_ADD');
      fxg.addProperty(match);
    }
    return nt_ok({ count: targets.length, adjustment: created });
  });
}

// ───────────────────────── UNDO (Edit > Undo)
function nt_undo() {
  try { app.executeCommand(16); return nt_ok({}); } catch (e) { return nt_err(String(e.message || e)); }
}

// ───────────────────────── SNAP / SEQUENCE LAYERS ON BEATS
// mode "snap": each selected layer starts on the nearest beat.
// mode "sequence": selected layers play one after another, one per beat (trimmed to the next beat).
function nt_snapLayers(times, mode, skipIndex) {
  return nt_run(mode === 'sequence' ? 'Sequence on beats' : 'Snap to beats', function (comp) {
    var sel = comp.selectedLayers, list = [];
    for (var i = 0; i < sel.length; i++) if (sel[i].index !== skipIndex && !(sel[i] instanceof CameraLayer) && !(sel[i] instanceof LightLayer)) list.push(sel[i]);
    if (!list.length) return nt_err('NO_SELECTION');
    if (!times || !times.length) return nt_err('NO_BEATS');
    var n = 0;
    if (mode === 'sequence') {
      list.sort(function (a, b) { return a.index - b.index; });
      var first = 0, t0 = list[0].inPoint;
      for (var f = 0; f < times.length; f++) { if (times[f] >= t0 - 0.0001) { first = f; break; } }
      for (var j = 0; j < list.length && first + j < times.length; j++) {
        var L = list[j], start = times[first + j], end = times[first + j + 1];
        var locked = L.locked; L.locked = false;
        L.startTime += start - L.inPoint;
        if (end !== undefined && end > start) { try { L.outPoint = end; } catch (e1) {} }
        L.locked = locked; n++;
      }
    } else {
      for (var k = 0; k < list.length; k++) {
        var M = list[k], best = times[0];
        for (var b = 1; b < times.length; b++) if (Math.abs(times[b] - M.inPoint) < Math.abs(best - M.inPoint)) best = times[b];
        var lk = M.locked; M.locked = false; M.startTime += best - M.inPoint; M.locked = lk; n++;
      }
    }
    return nt_ok({ count: n });
  });
}

// ───────────────────────── DUPLICATE PRECOMP (independent copy)
// Copies the comp behind each selected precomp layer, so editing the copy never changes the original.
// deep: also copies the precomps nested inside (otherwise they stay shared).
// mode 'new': adds a new layer above using the copy. mode 'unique': the selected layer itself switches to the copy.
function nt_dupComp(c, deep, memo) {
  if (memo[c.id]) return memo[c.id];
  var d = c.duplicate();
  d.name = nt_copyName(c.name);
  memo[c.id] = d;
  if (deep) {
    for (var i = 1; i <= d.numLayers; i++) {
      var L = d.layer(i);
      if (L.source && L.source instanceof CompItem) { try { L.replaceSource(nt_dupComp(L.source, deep, memo), false); } catch (e) {} }
    }
  }
  return d;
}
function nt_copyName(n) {
  var base = n.replace(/ copy( \d+)?$/, ''), name = base + ' copy', k = 2, taken = {};
  for (var i = 1; i <= app.project.numItems; i++) taken[app.project.item(i).name] = true;
  while (taken[name]) { name = base + ' copy ' + k; k++; }
  return name;
}
function nt_dupPrecomp(mode, deep) {
  return nt_run('Duplicate precomp', function (comp) {
    var sel = comp.selectedLayers, list = [], i;
    for (i = 0; i < sel.length; i++) if (sel[i].source && sel[i].source instanceof CompItem) list.push(sel[i]);
    if (!list.length) return nt_err('NO_PRECOMP');
    var memo = {}, names = [];
    for (i = 0; i < list.length; i++) {
      var L = list[i], copy = nt_dupComp(L.source, deep, memo), target = L;
      if (mode !== 'unique') { target = L.duplicate(); }
      var locked = target.locked; target.locked = false;
      target.replaceSource(copy, false);
      if (mode !== 'unique') target.name = copy.name;
      target.locked = locked;
      names.push(copy.name);
    }
    var nested = 0; for (var k in memo) if (memo.hasOwnProperty(k)) nested++;
    return nt_ok({ count: list.length, names: names, comps: nested });
  });
}

// ───────────────────────── AUDIO FROM VIDEO (MP4, MOV…)
// The panel can't read the sound inside most videos. After Effects renders the sound of the part we need
// (source time from → to, never the whole file) to the temp folder, and the panel reads that instead.
// The format comes from a built-in output-module template (WAV, else AIFF): recent versions don't let
// scripts change the "Format" setting directly.
function nt_pickTemplate(om) {
  var t = om.templates, i;
  for (i = 0; i < t.length; i++) if (/wav/i.test(t[i])) return { name: t[i], ext: 'wav' };
  for (i = 0; i < t.length; i++) if (/aif/i.test(t[i])) return { name: t[i], ext: 'aif' };
  return null;
}
function nt_extractAudio(index, from, to) {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var l = comp.layer(index); if (!l || !l.hasAudio || !l.source) return nt_err('NO_AUDIO');
  var src = l.source;
  from = Math.max(0, from || 0); to = (to && to > from) ? Math.min(to, src.duration) : src.duration;
  if (to - from < 0.05) return nt_err('This part is too short');
  var base = Folder.temp.fsName + '/nothi_audio_' + src.id + '_' + Math.round(from * 1000) + '_' + Math.round(to * 1000);
  var cached = [new File(base + '.wav'), new File(base + '.aif')];
  for (var c = 0; c < cached.length; c++) if (cached[c].exists && cached[c].length > 1000) return nt_ok({ path: cached[c].fsName, from: from, cached: true });
  // No undo group here: rendering inside one makes After Effects warn "Undo group mismatch".
  var rq = app.project.renderQueue, saved = [], tmp = null, item = null, i, out = null, tpl = null;
  try {
    tmp = app.project.items.addComp('Nothi audio (temp)', 64, 64, 1, to - from, 25);
    var t = tmp.layers.add(src); t.startTime = -from; t.enabled = false; t.audioEnabled = true;
    for (i = 1; i <= rq.numItems; i++) { saved.push(rq.item(i).render); try { rq.item(i).render = false; } catch (e0) {} }
    item = rq.items.add(tmp);
    var om = item.outputModule(1);
    tpl = nt_pickTemplate(om);
    if (tpl) om.applyTemplate(tpl.name);
    else { try { om.setSettings({ 'Format': 'WAV' }); tpl = { ext: 'wav' }; } catch (e5) { throw new Error('no WAV or AIFF output template'); } }
    try { om.setSettings({ 'Output Audio': 'On' }); } catch (e1) {}
    om.file = new File(base + '.' + tpl.ext);
    rq.render();
    out = om.file;
  } catch (e) {
    return nt_err('Can’t extract the audio here (' + (e.message || e) + '). Export it as WAV and use that layer.');
  } finally {
    try { if (item) item.remove(); } catch (e2) {}
    for (i = 0; i < saved.length && i < rq.numItems; i++) { try { rq.item(i + 1).render = saved[i]; } catch (e3) {} }
    try { if (tmp) tmp.remove(); } catch (e4) {}
  }
  // After Effects may change the extension: look for what was written
  var found = null, tries = [out, new File(base + '.' + tpl.ext), new File(base + '.wav'), new File(base + '.aif'), new File(base + '.aiff')];
  for (var k = 0; k < tries.length; k++) if (tries[k] && tries[k].exists && tries[k].length > 1000) { found = tries[k]; break; }
  if (!found) return nt_err('Can’t extract the audio here. Export it as WAV and use that layer.');
  return nt_ok({ path: found.fsName, from: from });
}

// ───────────────────────── CUT ON BEATS (like the razor: one layer per piece)
// Every selected clip is split at each beat that falls inside it. The audio layer is left alone
// unless it is the only one selected.
function nt_splitAt(times, skipIndex) {
  return nt_run('Cut on beats', function (comp) {
    var sel = comp.selectedLayers, list = [], i, k;
    for (i = 0; i < sel.length; i++) if (!(sel[i] instanceof CameraLayer) && !(sel[i] instanceof LightLayer)) list.push(sel[i]);
    if (list.length > 1) { var keep = []; for (i = 0; i < list.length; i++) if (list[i].index !== skipIndex) keep.push(list[i]); list = keep; }
    if (!list.length) return nt_err('NO_SELECTION');
    if (!times || !times.length) return nt_err('NO_BEATS');
    var fd = comp.frameDuration, cuts = 0, layers = 0, made = [];
    for (i = 0; i < list.length; i++) {
      var L = list[i], locked = L.locked, cur = L, did = false;
      L.locked = false;
      for (k = 0; k < times.length; k++) {
        var t = Math.round(times[k] / fd) * fd;
        if (t <= cur.inPoint + fd * 1.5 || t >= cur.outPoint - fd * 1.5) continue;
        var piece = cur.duplicate();
        cur.outPoint = t; piece.inPoint = t;
        made.push(cur); cur = piece; cuts++; did = true;
      }
      made.push(cur);
      if (did) layers++;
      L.locked = locked;
    }
    for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
    for (i = 0; i < made.length; i++) try { made[i].selected = true; } catch (e) {}
    if (!cuts) return nt_err('NO_CUTS');
    return nt_ok({ count: cuts, layers: layers });
  });
}

// ───────────────────────── SPLIT TEXT (each word / line / letter on its own layer, in place)
// Works on point text. Each piece keeps the look and the transform of the original layer;
// only its anchor point is shifted, so it sits exactly where it was in the full text.
function nt_textRect(m, td, s, t) {
  td.text = s; m.property('ADBE Text Properties').property('ADBE Text Document').setValue(td);
  return m.sourceRectAtTime(t, false);
}
function nt_right(r) { return r.width > 0 ? r.left + r.width : 0; }
function nt_clearKeys(p) { for (var k = p.numKeys; k >= 1; k--) p.removeKey(k); try { if (p.expression) p.expression = ''; } catch (e) {} }
function nt_splitText(mode, centerAnchor, keepOriginal) {
  return nt_run('Split text', function (comp) {
    var sel = comp.selectedLayers, list = [], i, made = [];
    for (i = 0; i < sel.length; i++) if (sel[i] instanceof TextLayer) list.push(sel[i]);
    if (!list.length) return nt_err('NO_TEXT');
    var t = comp.time, pieces = 0, boxes = 0;
    for (i = 0; i < list.length; i++) {
      var L = list[i], locked = L.locked; L.locked = false;
      var srcProp = L.property('ADBE Text Properties').property('ADBE Text Document');
      var td0 = srcProp.valueAtTime(t, false);
      if (td0.boxText) { boxes++; L.locked = locked; continue; }
      var J = td0.justification;
      // a hidden copy used only to measure the text
      var m = L.duplicate(); m.enabled = false;
      var mp = m.property('ADBE Text Properties').property('ADBE Text Document');
      nt_clearKeys(mp);
      try { var an = m.property('ADBE Text Properties').property('ADBE Text Animators'); for (var a = an.numProperties; a >= 1; a--) an.property(a).remove(); } catch (eA) {}
      var tdL = mp.value; tdL.justification = ParagraphJustification.LEFT_JUSTIFY;
      var tdJ = mp.value; tdJ.justification = J;
      var lines = String(td0.text).split(/\r\n|\r|\n|\u0003/), units = [], li;
      for (li = 0; li < lines.length; li++) {
        var line = lines[li];
        if (!/\S/.test(line)) continue;
        var rL = nt_textRect(m, tdL, line, t), rJ = nt_textRect(m, tdJ, line, t);
        var shift = rJ.left - rL.left;
        var above = lines.slice(0, li + 1).join('\r');
        var dy = li ? (function () { var a1 = nt_textRect(m, tdL, above, t), a2 = nt_textRect(m, tdL, line, t); return (a1.top + a1.height) - (a2.top + a2.height); })() : 0;
        var re = mode === 'letters' ? /\S/g : mode === 'lines' ? /\S(.*\S)?/g : /\S+/g, mt;
        while ((mt = re.exec(line)) !== null) {
          var u = mt[0], pre = line.substring(0, mt.index);
          var d = pre ? nt_right(nt_textRect(m, tdL, pre + u, t)) - nt_right(nt_textRect(m, tdL, u, t)) : 0;
          units.push({ text: u, dx: shift + d, dy: dy });
        }
      }
      m.remove();
      if (units.length < 2) { L.locked = locked; continue; } // nothing to split
      for (var k = 0; k < units.length; k++) {
        var P = L.duplicate(), sp = P.property('ADBE Text Properties').property('ADBE Text Document');
        nt_clearKeys(sp);
        var tdP = sp.value; tdP.text = units[k].text; tdP.justification = ParagraphJustification.LEFT_JUSTIFY; sp.setValue(tdP);
        P.name = units[k].text;
        var ap = P.property('ADBE Transform Group').property('ADBE Anchor Point');
        nt_offsetVec(ap, -units[k].dx, -units[k].dy);
        if (centerAnchor) nt_moveAnchor(P, 0.5, 0.5, t);
        P.enabled = true; made.push(P); pieces++;
      }
      if (keepOriginal) { L.enabled = false; L.locked = locked; } else { L.locked = false; L.remove(); }
    }
    for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
    for (i = 0; i < made.length; i++) made[i].selected = true;
    if (!pieces) return nt_err(boxes ? 'BOX_TEXT' : 'NOTHING_TO_SPLIT');
    return nt_ok({ count: pieces, layers: list.length - boxes, boxes: boxes });
  });
}

// ───────────────────────── AUTO CAPTIONS (the panel transcribes, this creates the text layers)
// items: [{ a, b, text }] in comp time. A text layer named "Caption style" is used as the look
// (font, size, effects, animation); otherwise a clean white caption with a thin outline.
function nt_findTemplate(comp) {
  for (var i = 1; i <= comp.numLayers; i++) { var L = comp.layer(i); if (L instanceof TextLayer && /^captions? style$/i.test(L.name)) return L; }
  return null;
}
function nt_captionInfo() {
  var comp = nt_comp(); if (!comp) return nt_err('NO_COMP');
  var tpl = nt_findTemplate(comp);
  return nt_ok({ template: tpl ? tpl.name : null });
}
function nt_captions(items, o) {
  o = o || {};
  return nt_run('Auto captions', function (comp) {
    if (!items || !items.length) return nt_err('NO_WORDS');
    var tpl = nt_findTemplate(comp), fd = comp.frameDuration, made = [], i;
    var w = comp.width, h = comp.height, fs = Math.round(h * (o.size || 0.06));
    var order = [];
    for (i = 0; i < items.length; i++) order.push(i);
    if (!tpl) order.reverse(); // new text layers go on top: create the last one first, so the first caption ends up on top
    for (var n = 0; n < order.length; n++) {
      var it = items[order[n]], text = o.upper ? String(it.text).toUpperCase() : String(it.text);
      var a = Math.round(it.a / fd) * fd, b = Math.min(comp.duration, Math.max(a + fd * 2, Math.round(it.b / fd) * fd)), l, src, td;
      if (a >= comp.duration - fd) continue;
      if (tpl) {
        var lk = tpl.locked; tpl.locked = false;
        l = tpl.duplicate(); tpl.locked = lk; l.locked = false;
        src = l.property('ADBE Text Properties').property('ADBE Text Document');
        nt_clearKeys(src);
        td = src.value; td.text = text; src.setValue(td);
        l.startTime += a - tpl.inPoint; // the template's animation follows each caption
        l.inPoint = a; try { l.outPoint = b; } catch (e1) {}
        l.enabled = true;
      } else {
        l = comp.layers.addText(text);
        src = l.property('ADBE Text Properties').property('ADBE Text Document');
        td = src.value;
        td.fontSize = fs; td.fillColor = [1, 1, 1]; td.justification = ParagraphJustification.CENTER_JUSTIFY;
        try { td.applyStroke = true; td.strokeColor = [0, 0, 0]; td.strokeWidth = Math.max(2, Math.round(fs * 0.07)); td.strokeOverFill = false; } catch (e2) {}
        src.setValue(td);
        l.property('ADBE Transform Group').property('ADBE Anchor Point').setValue([0, -fs * 0.35]);
        l.property('ADBE Transform Group').property('ADBE Position').setValue([w / 2, o.pos === 'center' ? h / 2 : h * 0.8]);
        l.inPoint = a; l.outPoint = b;
        l.label = 11;
      }
      l.name = text.length > 40 ? text.substring(0, 39) + '...' : text;
      made.push(l);
    }
    for (i = 1; i <= comp.numLayers; i++) comp.layer(i).selected = false;
    for (i = 0; i < made.length; i++) made[i].selected = true;
    return nt_ok({ count: made.length, template: tpl ? tpl.name : null });
  });
}

// where the panel lives (to find the transcription program shipped with it)
function nt_extPath() { try { return nt_ok({ path: File($.fileName).parent.parent.fsName }); } catch (e) { return nt_err(String(e)); } }
