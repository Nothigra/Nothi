(() => {
  "use strict";
  const CEP = !!window.__adobe_cep__;
  const IS_MAC = /Mac/i.test(navigator.platform || navigator.userAgent);
  const SITES = ["https://nothilabs.com", "https://www.nothilabs.com", "https://nothi-labs.pages.dev"];
  let SITE = SITES[0];
  const VERSION = "1.9";
  const LEGACY = true;
  const host = (fn, ...args) => new Promise((resolve) => {
    if (!CEP) return setTimeout(() => resolve(MOCK(fn, args)), 60);
    window.__adobe_cep__.evalScript(`${fn}(${args.map((a) => JSON.stringify(a)).join(",")})`, (res) => {
      try {
        resolve(JSON.parse(res));
      } catch (e) {
        resolve({ ok: false, error: res || "Script error" });
      }
    });
  });
  const store = {
    get(k, d) {
      try {
        const v = localStorage.getItem("nothi-tk2-" + k);
        return v ? JSON.parse(v) : d;
      } catch (e) {
        return d;
      }
    },
    set(k, v) {
      try {
        localStorage.setItem("nothi-tk2-" + k, JSON.stringify(v));
      } catch (e) {
      }
    }
  };
  const ERR = {
    NO_COMP: "Open a composition first",
    NO_SELECTION: "Select one or more layers",
    NO_KEYS: "Select two keyframes or more",
    NO_AUDIO: "Select a layer with audio",
    NO_STYLE: "Copy a style first",
    CANNOT_ADD: "This effect can\u2019t go on that layer",
    NO_AUDIO_SEL: "Select a layer with sound (WAV, MP3, MP4, MOV\u2026)",
    NO_PRECOMP: "Select a precomp layer",
    NO_BEATS: "Find the beats first",
    NEED_TWO: "Select two layers or more",
    NO_CUTS: "No beat falls inside the selected clips",
    NO_TEXT: "Select one or more text layers",
    BOX_TEXT: "Paragraph (box) text can\u2019t be split yet: use point text (click once with the Text tool)",
    NOTHING_TO_SPLIT: "Only one piece: nothing to split",
    NO_WORDS: "No speech found in this part"
  };
  const I = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const ICON = {
    create: I('<path d="M12 5v14M5 12h14"/>'),
    curves: I('<path d="M4 19C10 19 9 5 20 5"/>'),
    beat: I('<path d="M4 10v4M8 6v12M12 9v6M16 4v16M20 10v4"/>'),
    layers: I('<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>'),
    style: I('<path d="M14 4l6 6-9 9H5v-6z"/><path d="M12 6l6 6"/>'),
    effects: I('<path d="M12 4v4M12 16v4M4 12h4M16 12h4M6.5 6.5l2.5 2.5M15 15l2.5 2.5M6.5 17.5 9 15M15 9l2.5-2.5"/>'),
    search: I('<circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5"/>'),
    sliders: I('<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/><circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>'),
    menu: I('<circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/>'),
    text: I('<path d="M6 6h12M12 6v13"/>'),
    adjustment: I('<circle cx="12" cy="12" r="7"/><path d="M12 5a7 7 0 0 1 0 14z" fill="currentColor"/>'),
    solid: I('<rect x="5" y="5" width="14" height="14" fill="currentColor" stroke="none"/>'),
    null: I('<rect x="5" y="5" width="14" height="14" stroke-dasharray="2.5 2.5"/>'),
    shape: I('<path d="M12 4l8 14H4z"/>'),
    camera: I('<rect x="3" y="7" width="12" height="10"/><path d="m15 11 6-3v8l-6-3"/>'),
    light: I('<circle cx="12" cy="10" r="5"/><path d="M10 18h4M11 21h2"/>'),
    plus: I('<path d="M12 6v12M6 12h12"/>'),
    x: I('<path d="M7 7l10 10M17 7 7 17"/>'),
    trash: I('<path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/>'),
    copy: I('<rect x="9" y="9" width="11" height="11"/><path d="M15 9V4H4v11h5"/>'),
    paste: I('<rect x="5" y="5" width="14" height="16"/><path d="M9 3h6v4H9z"/>'),
    precomp: I('<rect x="4" y="4" width="16" height="16"/><rect x="8" y="8" width="8" height="8"/>'),
    decomp: I('<rect x="4" y="4" width="10" height="10"/><rect x="10" y="10" width="10" height="10"/>'),
    rename: I('<path d="M4 8h9M4 13h6M4 18h8"/><path d="m14 19 6-6-2-2-6 6v2z"/>'),
    anchor: I('<circle cx="12" cy="12" r="2.5"/><path d="M12 3v5M12 16v5M3 12h5M16 12h5"/>'),
    star: I('<path d="M12 4l2.4 5 5.6.8-4 3.9 1 5.5L12 16.6 7 19.2l1-5.5-4-3.9 5.6-.8z"/>'),
    starOn: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M12 4l2.4 5 5.6.8-4 3.9 1 5.5L12 16.6 7 19.2l1-5.5-4-3.9 5.6-.8z"/></svg>',
    play: I('<path d="M7 5v14l11-7z"/>'),
    marker: I('<path d="M7 4h10v9l-5 6-5-6z"/>'),
    fit: I('<path d="M3 12h18M7 8l-4 4 4 4M17 8l4 4-4 4"/>'),
    keep: I('<path d="M4 18C9 18 9 6 14 6h6"/><path d="M4 4v16"/>'),
    off: I('<circle cx="12" cy="12" r="8"/><path d="m6.5 17.5 11-11"/>'),
    dup: I('<rect x="8" y="8" width="12" height="12"/><path d="M16 8V4H4v12h4"/><path d="M14 11v6M11 14h6"/>'),
    invert: I('<path d="M7 4v16M7 20l-3-3M7 20l3-3M17 20V4M17 4l-3 3M17 4l3 3"/>'),
    stop: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="1.5" fill="currentColor"/></svg>',
    playOn: '<svg viewBox="0 0 24 24"><path fill="currentColor" d="M7 5v14l11-7z"/></svg>',
    reload: I('<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 5v6h-6"/>'),
    snap: I('<path d="M6 4v16M18 4v16"/><rect x="9" y="9" width="6" height="6"/>'),
    seq: I('<path d="M4 6h5M8 12h6M13 18h7"/>'),
    undo: I('<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>'),
    fxBlur: I('<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.5" stroke-dasharray="1.5 2.5"/><circle cx="12" cy="12" r="9.5" stroke-dasharray="1 3.5" opacity=".6"/>'),
    fxColor: I('<path d="M12 3.5c3 3.6 6 6.8 6 10.2a6 6 0 0 1-12 0c0-3.4 3-6.6 6-10.2z"/><path d="M12 19.7a6 6 0 0 0 6-6H6" fill="currentColor" stroke="none" opacity=".9"/>'),
    fxDistort: I('<path d="M3 8c3-3 6 3 9 0s6-3 9 0M3 16c3-3 6 3 9 0s6-3 9 0"/>'),
    fxGenerate: I('<path d="M12 3v4M12 17v4M3 12h4M17 12h4"/><path d="m12 8 1.3 2.7L16 12l-2.7 1.3L12 16l-1.3-2.7L8 12l2.7-1.3z" fill="currentColor"/>'),
    fxLight: I('<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>'),
    fxNoise: '<svg viewBox="0 0 24 24" fill="currentColor"><circle cx="6" cy="6" r="1.3"/><circle cx="12" cy="8" r="1.3"/><circle cx="18" cy="5" r="1.3"/><circle cx="8" cy="13" r="1.3"/><circle cx="15" cy="12" r="1.3"/><circle cx="5" cy="19" r="1.3"/><circle cx="12" cy="18" r="1.3"/><circle cx="19" cy="17" r="1.3"/></svg>',
    fxKey: I('<circle cx="8" cy="12" r="4"/><path d="M12 12h9M18 12v3M21 12v2"/>'),
    fx3d: I('<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="m4 7.5 8 4.5 8-4.5M12 12v9"/>'),
    fxTime: I('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
    fxTransition: I('<rect x="3.5" y="5" width="17" height="14" rx="2"/><path d="M12 5v14" stroke-dasharray="2 2"/><path d="M3.5 19 12 5" />'),
    fxText: I('<path d="M6 6h12M12 6v13"/>'),
    fxAudio: I('<path d="M4 10v4M8 7v10M12 4v16M16 8v8M20 11v2"/>'),
    fxShadow: I('<rect x="4" y="4" width="11" height="11" rx="2"/><path d="M19 9v8a2 2 0 0 1-2 2H9" opacity=".6"/>'),
    cut: I('<circle cx="6" cy="7" r="2.5"/><circle cx="6" cy="17" r="2.5"/><path d="M8.2 8.3 20 17M8.2 15.7 20 7"/>'),
    captions: I('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h7M16 16h1"/>'),
    split: I('<path d="M4 8h4M10 8h4M16 8h4"/><path d="M4 15h4M12 13v4M16 15h4" opacity=".55"/>'),
    zin: I('<circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5M11 8.5v5M8.5 11h5"/>'),
    zout: I('<circle cx="11" cy="11" r="6"/><path d="m20 20-4.5-4.5M8.5 11h5"/>'),
    frame: I('<path d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"/>'),
    download: I('<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>'),
    words: I('<path d="M4 7h7M4 12h5M4 17h7"/><path d="M15 7h5M15 12h5M15 17h5"/>')
  };
  function fxIcon(f) {
    const c = (f.c || "").toLowerCase(), n = (f.n || "").toLowerCase();
    if (/shadow|bevel/.test(n)) return ICON.fxShadow;
    if (/glow|light|lens flare|shine/.test(n)) return ICON.fxLight;
    if (/blur|sharp/.test(c) || /blur/.test(n)) return ICON.fxBlur;
    if (/color|lumetri|curves|levels|tint|hue|exposure/.test(c + " " + n)) return ICON.fxColor;
    if (/distort|warp|displace|transform|bulge|twirl/.test(c + " " + n)) return ICON.fxDistort;
    if (/generate|fill|ramp|gradient|stroke/.test(c + " " + n)) return ICON.fxGenerate;
    if (/stylize/.test(c)) return ICON.fxLight;
    if (/noise|grain/.test(c + " " + n)) return ICON.fxNoise;
    if (/key|matte/.test(c)) return ICON.fxKey;
    if (/perspective|3d|immersive/.test(c)) return ICON.fx3d;
    if (/time|echo|posterize time/.test(c + " " + n)) return ICON.fxTime;
    if (/transition|wipe/.test(c + " " + n)) return ICON.fxTransition;
    if (/text/.test(c)) return ICON.fxText;
    if (/audio/.test(c)) return ICON.fxAudio;
    return ICON.effects;
  }
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  let stTimer;
  function status(msg, kind = "done", undoable = false) {
    const el = $("#status");
    el.classList.remove("done", "err");
    el.classList.add(kind);
    $("#stMsg").textContent = msg;
    $("#stUndo").hidden = !undoable;
    clearTimeout(stTimer);
    stTimer = setTimeout(() => {
      el.classList.remove("done", "err");
      $("#stMsg").textContent = idleMsg();
      $("#stUndo").hidden = true;
    }, undoable ? 7e3 : 3200);
  }
  const idleMsg = () => ctx.comp ? ctx.selected ? plural(ctx.selected, "layer") + " selected" : "Ready" : "No composition open";
  function flash(el, ok) {
    if (!el) return;
    el.classList.remove("ok", "bad");
    void el.offsetWidth;
    el.classList.add(ok ? "ok" : "bad");
    setTimeout(() => el.classList.remove("ok", "bad"), 650);
  }
  async function run(btn, promise, okMsg) {
    const r = await promise;
    const ok = !!(r && r.ok);
    flash(btn, ok);
    if (ok) {
      if (okMsg) status(typeof okMsg === "function" ? okMsg(r) : okMsg, "done", true);
    } else status(ERR[r && r.error] || r && r.error || "Something went wrong", "err");
    return r;
  }
  const remember = (id) => {
    const r = store.get("recent", []).filter((x) => x !== id);
    r.unshift(id);
    store.set("recent", r.slice(0, 5));
  };
  let ctx = { comp: null }, lastAudKey = "";
  async function poll() {
    const r = await host("nt_context");
    if (!r || !r.ok) return;
    ctx = r;
    try {
      autoLoad();
    } catch (e) {
    }
    const audKey = r.aud ? `${r.aud.i}:${r.aud.id}:${r.aud.a}:${r.aud.b}` : "";
    if (audKey !== lastAudKey) {
      lastAudKey = audKey;
      try {
        if (current === "captions") Captions.refresh();
      } catch (e) {
      }
    }
    document.body.classList.toggle("nocomp", !r.comp);
    $("#status").classList.toggle("live", !!r.comp);
    $("#stCtx").textContent = r.comp || "";
    $("#stCtx").dataset.tip = r.comp ? `${r.comp} \xB7 ${r.w}\xD7${r.h} \xB7 ${r.fps} fps` : "";
    if (!$("#status").classList.contains("done") && !$("#status").classList.contains("err")) $("#stMsg").textContent = idleMsg();
  }
  const RO = window.ResizeObserver || class {
    constructor(cb) {
      this.cb = cb;
    }
    observe() {
      addEventListener("resize", () => this.cb());
      setTimeout(() => this.cb(), 0);
    }
  };
  new RO(() => {
    document.body.classList.toggle("xs", innerWidth < 250);
    document.body.classList.toggle("short", innerHeight < 300);
    document.body.classList.toggle("wide", innerWidth >= 430);
    try {
      const f = fitsAll();
      if (f !== full) {
        full = f;
        if (full && (current === "layers" || current === "style")) current = "create";
        renderTabs();
        if (current === "create" || current === "layers" || current === "style") render();
      }
    } catch (e) {
    }
    try {
      if (current === "curves") drawEditor();
      if (current === "create") fitTiles();
      if (current === "beat" && beat) drawBeat();
    } catch (e) {
    }
  }).observe(document.documentElement);
  const pop = $("#pop");
  let popFor = null;
  function openPop(anchorBtn, html, bind) {
    if (popFor === anchorBtn) return closePop();
    pop.innerHTML = html;
    pop.hidden = false;
    popFor = anchorBtn;
    const tp = document.getElementById("tip");
    if (tp) tp.classList.remove("show");
    $$(".ib").forEach((b) => b.classList.toggle("on", b === anchorBtn));
    bind && bind(pop);
  }
  function closePop() {
    pop.hidden = true;
    popFor = null;
    $$(".ib").forEach((b) => b.classList.remove("on"));
  }
  document.addEventListener("mousedown", (e) => {
    if (!pop.hidden && !pop.contains(e.target) && !e.target.closest(".ib")) closePop();
  });
  const opt = (key, label, on, sub = "", radio = false) => `<div class="opt ${on ? "on" : ""}" data-opt="${key}"><span class="box ${radio ? "radio" : ""}"></span><span class="k">${label}${sub ? `<small>${sub}</small>` : ""}</span></div>`;
  function bindOpts(root, state, save, rerender) {
    $$("[data-opt]", root).forEach((el) => el.addEventListener("click", () => {
      const [k, v] = el.dataset.opt.split("=");
      if (v !== void 0) {
        state[k] = v;
        $$(`[data-opt^="${k}="]`, root).forEach((x) => x.classList.toggle("on", x === el));
      } else {
        state[k] = !state[k];
        el.classList.toggle("on", state[k]);
      }
      save();
      rerender && rerender();
    }));
  }
  const TABS_ALL = [["create", "Create layers", "Text, adjustment, solid, null, shape, camera, light"], ["layers", "Layers", "Precompose, decompose, duplicate, sequence, anchor, rename"], ["style", "Copy style", "Copy effects and animation from one layer to others"], ["curves", "Curves", "Draw an ease on a graph and apply it to your keyframes"], ["beat", "Beat markers", "Find the beats of a song and put layers on them"], ["captions", "Captions", "Speech to text layers, and split text into words"]];
  const TABS_FULL = [["create", "Create & layers", "New layers, precomps, duplicate, sequence, anchor, copy style"], TABS_ALL[3], TABS_ALL[4], TABS_ALL[5]];
  const TABS_SMALL = [TABS_ALL[0], TABS_ALL[3], TABS_ALL[4], TABS_ALL[5], TABS_ALL[1], TABS_ALL[2]];
  let full = false;
  const fitsAll = () => innerHeight >= 470 && innerWidth >= 260;
  const tabList = () => full ? TABS_FULL : TABS_SMALL;
  const TAB_SHORT = { create: "Create", layers: "Layers", style: "Style", curves: "Curves", beat: "Beat", captions: "Captions" };
  let current = store.get("tab", "create");
  if (!TAB_SHORT[current]) current = "create";
  function renderTabs() {
    $("#tabs").innerHTML = tabList().map(([k, n, t]) => `<button class="tab ${k === current ? "on" : ""}" data-tab="${k}" title="${n} \xB7 ${t}">${ICON[k]}<span class="tl">${TAB_SHORT[k]}</span></button>`).join("");
    $$(".tab").forEach((b) => b.addEventListener("click", () => go(b.dataset.tab)));
  }
  function go(tab) {
    if (tab !== "beat") stop();
    current = tab;
    store.set("tab", tab);
    closePop();
    renderTabs();
    render();
  }
  function render() {
    const v = $("#view");
    const keep = v.dataset.tab === current ? v.scrollTop : 0;
    v.innerHTML = "";
    v.dataset.tab = current;
    v.classList.toggle("full", full);
    $("#btnTabSettings").hidden = !VIEWS[current].options;
    VIEWS[current].render(v);
    v.scrollTop = keep;
  }
  const CREATE = [["text", "Text"], ["adjustment", "Adjust"], ["solid", "Solid"], ["null", "Null"], ["shape", "Shape"], ["camera", "Camera"], ["light", "Light"]];
  const COLORS = ["#FFFFFF", "#0A0A0A", "#2A2A2E", "#8A8A93", "#FF3B30", "#FF6A3D", "#FFC83D", "#2FC6A0", "#3D8BFF", "#8E6BFF", "#FF5EA8"];
  const cState = store.get("create", { match: true, color: "#0A0A0A", name: "" });
  if (!cState.v17) {
    cState.color = "#0A0A0A";
    cState.v17 = true;
    store.set("create", cState);
  }
  const rgb = (h) => [1, 3, 5].map((i) => parseInt(h.substr(i, 2), 16) / 255);
  const doCreate = (type, btn) => (remember("create:" + type), run(btn, host("nt_create", type, { name: cState.name || void 0, color: rgb(cState.color), matchDuration: cState.match }), (r) => `${r.name} added`));
  const CREATE_TIPS = { text: "Centered, at the playhead", adjustment: "Covers the selected layer\u2019s duration", solid: "Comp size, your chosen color", null: "Handy as a controller: parent layers to it", shape: "Empty shape layer, ready for the pen", camera: "2-node camera, layers switched to 3D stay put", light: "Point light with soft shadows" };
  function solidPicker(btn) {
    openPop(btn, `<div class="ph cap">New solid</div>
      <div class="sw sw-big">${COLORS.map((c) => `<button data-c="${c}" class="${cState.color === c ? "on" : ""}" style="background:${c}" title="${c}"></button>`).join("")}<button class="custom ${COLORS.includes(cState.color) ? "" : "on"}" style="background:${COLORS.includes(cState.color) ? "conic-gradient(#ff3b30,#ffc83d,#2fc6a0,#3d8bff,#8e6bff,#ff3b30)" : cState.color}" title="Any color"><input type="color" id="oSolidColor" value="${cState.color}"></button></div>
      <div class="field row"><i class="sw-prev" id="oSolidPrev" style="background:${cState.color}"></i><input class="in grow" id="oSolidHex" value="${cState.color.toUpperCase()}" maxlength="7" spellcheck="false"></div>
      <div class="field"><button class="b main" id="oSolidGo" style="width:100%">${ICON.solid}<span class="lbl">Create solid</span></button></div>`, (p) => {
      const set = (c, keep) => {
        cState.color = c;
        store.set("create", cState);
        $("#oSolidPrev", p).style.background = c;
        if (!keep) $("#oSolidHex", p).value = c.toUpperCase();
        $$(".sw button", p).forEach((b) => b.classList.toggle("on", b.dataset.c === c));
        const d = $('.ct [data-k="solid"] .dot-c');
        if (d) d.style.background = c;
      };
      $$(".sw button[data-c]", p).forEach((b) => {
        b.addEventListener("click", () => set(b.dataset.c));
        b.addEventListener("dblclick", () => {
          set(b.dataset.c);
          go2();
        });
      });
      $("#oSolidColor", p).addEventListener("input", (e) => set(e.target.value));
      const hex = $("#oSolidHex", p);
      hex.addEventListener("keydown", (e) => {
        e.stopPropagation();
        if (e.key === "Enter") go2();
      });
      hex.addEventListener("input", () => {
        const v = hex.value.trim().replace(/^#?/, "#");
        if (/^#[0-9a-f]{6}$/i.test(v)) set(v, true);
      });
      const go2 = () => {
        closePop();
        doCreate("solid", btn);
      };
      $("#oSolidGo", p).addEventListener("click", go2);
    });
  }
  const createHTML = () => `<div class="grid ct">${CREATE.map(([k, n]) => `<button class="t needs-comp" data-k="${k}" title="${k === "adjustment" ? "Adjustment" : n} layer \xB7 ${k === "solid" ? "Pick a color, then create" : CREATE_TIPS[k]}">${ICON[k]}<span>${n}</span>${k === "solid" ? `<i class="dot-c" style="background:${cState.color}"></i>` : ""}</button>`).join("")}</div>`;
  function fitTiles() {
    const g = $("#view .ct.fill");
    if (!g) return;
    const n = g.children.length, gap = 5, W = g.clientWidth, H = Math.max(60, $("#view").clientHeight - 16);
    let best = 1, bestSide = 0;
    for (let c = 1; c <= n; c++) {
      const r = Math.ceil(n / c), w = (W - gap * (c - 1)) / c, h = (H - gap * (r - 1)) / r;
      const side = Math.min(w, h * 1.25);
      if (side > bestSide) {
        bestSide = side;
        best = c;
      }
    }
    const rows = Math.ceil(n / best), th = Math.min((H - gap * (rows - 1)) / rows, (W - gap * (best - 1)) / best * 1.1);
    g.style.setProperty("--cols", best);
    g.style.setProperty("--th", `${Math.max(48, th)}px`);
    g.style.setProperty("--ic", `${Math.round(Math.max(18, Math.min(44, th * 0.3)))}px`);
    g.style.setProperty("--lf", `${Math.round(Math.max(10.5, Math.min(15, th * 0.12)) * 10) / 10}px`);
  }
  const bindCreate = (v) => $$(".ct .t", v).forEach((b) => b.addEventListener("click", () => b.dataset.k === "solid" ? solidPicker(b) : doCreate(b.dataset.k, b)));
  const createOptions = () => `<div class="ph cap">New layers</div>
        <div class="field"><input class="in" id="oName" placeholder="Name (optional)" value="${esc(cState.name)}"></div>
        ${opt("match", "Match selected layer", cState.match, "Same start, end and position in the stack")}`;
  const bindCreateOptions = (p) => {
    const save = () => store.set("create", cState);
    $("#oName", p).addEventListener("input", (e) => {
      cState.name = e.target.value;
      save();
    });
    $("#oName", p).addEventListener("keydown", (e) => e.stopPropagation());
    bindOpts(p, cState, save);
  };
  const PRESETS = [["Linear", [0, 0, 1, 1]], ["Easy Ease", [0.33, 0, 0.67, 1]], ["Smooth", [0.65, 0, 0.35, 1]], ["Silk", [0.8, 0, 0.2, 1]], ["Expo Out", [0.16, 1, 0.3, 1]], ["Expo In", [0.7, 0, 0.84, 0]], ["Punch", [0.95, 0, 0.05, 1]], ["Snap Out", [0.05, 0.7, 0.1, 1]], ["Glide", [0.25, 0.1, 0.25, 1]], ["Back Out", [0.34, 1.4, 0.64, 1]], ["Anticipate", [0.36, -0.4, 0.66, 1]]];
  const toAE = ([x1, y1, x2, y2]) => ({ outInf: Math.max(0.1, x1 * 100), outRatio: x1 > 0 ? y1 / x1 : 0, inInf: Math.max(0.1, (1 - x2) * 100), inRatio: x2 < 1 ? (1 - y2) / (1 - x2) : 0 });
  const fromAE = (c) => {
    const x1 = c.outInf / 100, x2 = 1 - c.inInf / 100;
    return [x1, Math.min(3, x1 * c.outRatio), x2, Math.max(-2, 1 - c.inInf / 100 * c.inRatio)];
  };
  const r3 = (v) => Math.round(v * 1e3) / 1e3;
  function curveSVG(b) {
    const X = (x) => 2 + x * 36, Y = (y) => 26 - y * 24, d = `M${X(0)} ${Y(0)} C${X(b[0])} ${Y(b[1])} ${X(b[2])} ${Y(b[3])} ${X(1)} ${Y(1)}`;
    return `<svg class="g" viewBox="0 0 40 28" overflow="visible"><path d="${d}" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>`;
  }
  function easeAt(b, x) {
    const bx = (t2) => 3 * (1 - t2) * (1 - t2) * t2 * b[0] + 3 * (1 - t2) * t2 * t2 * b[2] + t2 * t2 * t2;
    const by = (t2) => 3 * (1 - t2) * (1 - t2) * t2 * b[1] + 3 * (1 - t2) * t2 * t2 * b[3] + t2 * t2 * t2;
    let lo = 0, hi = 1, t = x;
    for (let i = 0; i < 30; i++) {
      const v = bx(t);
      if (Math.abs(v - x) < 1e-5) break;
      if (v < x) lo = t;
      else hi = t;
      t = (lo + hi) / 2;
    }
    return by(t);
  }
  const cvState = store.get("curvesOpt", { live: false });
  let ed = store.get("editor", { b: [0.33, 0, 0.67, 1], name: "Easy Ease" });
  let edRange = null, edRaf = 0, edT0 = 0;
  let edDrag = -1;
  let userView = false;
  const saveEd = () => store.set("editor", ed);
  const applyCurve = (name, b, btn) => (remember("curve:" + name), run(btn, host("nt_curveApply", toAE(b)), (r) => `${name} \u2192 ${plural(r.count, "keyframe pair")}`));
  function rangeFor(b) {
    return { x0: -0.05, x1: 1.05, y0: Math.min(-0.1, b[1] - 0.12, b[3] - 0.12), y1: Math.max(1.1, b[1] + 0.12, b[3] + 0.12) };
  }
  const niceStep = (span) => [0.05, 0.1, 0.25, 0.5, 1, 2].find((st) => span / st <= 6) || 2;
  function drawEditor() {
    const svg = $("#ceG");
    if (!svg) return;
    const box = svg.getBoundingClientRect(), W = Math.max(60, box.width || 300), H = Math.max(40, box.height || 140), pad = 10;
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("preserveAspectRatio", "none");
    const v = edRange || (edRange = rangeFor(ed.b));
    const X = (x) => pad + (x - v.x0) / (v.x1 - v.x0) * (W - 2 * pad), Y = (y) => H - pad - (y - v.y0) / (v.y1 - v.y0) * (H - 2 * pad);
    const b = ed.b, d = `M${X(0)} ${Y(0)} C${X(b[0])} ${Y(b[1])} ${X(b[2])} ${Y(b[3])} ${X(1)} ${Y(1)}`;
    const sy = niceStep(v.y1 - v.y0), sx = niceStep(v.x1 - v.x0);
    let grid = "";
    for (let y = Math.ceil(v.y0 / sy) * sy; y <= v.y1; y += sy) if (Math.abs(y) > 1e-6 && Math.abs(y - 1) > 1e-6) grid += `<line x1="0" x2="${W}" y1="${Y(y)}" y2="${Y(y)}" class="ce-grid"/>`;
    for (let x = Math.max(0, Math.ceil(v.x0 / sx) * sx); x <= Math.min(1, v.x1); x += sx) if (x > 1e-6 && x < 1 - 1e-6) grid += `<line x1="${X(x)}" x2="${X(x)}" y1="0" y2="${H}" class="ce-grid"/>`;
    const out = `<rect x="0" y="0" width="${Math.max(0, X(0))}" height="${H}" class="ce-out"/><rect x="${X(1)}" y="0" width="${Math.max(0, W - X(1))}" height="${H}" class="ce-out"/>`;
    svg.innerHTML = `${out}${grid}<line x1="0" x2="${W}" y1="${Y(0)}" y2="${Y(0)}" class="ce-base"/><line x1="0" x2="${W}" y1="${Y(1)}" y2="${Y(1)}" class="ce-base"/>
      <line x1="${X(0)}" y1="${Y(0)}" x2="${X(b[0])}" y2="${Y(b[1])}" class="ce-arm"/><line x1="${X(1)}" y1="${Y(1)}" x2="${X(b[2])}" y2="${Y(b[3])}" class="ce-arm"/>
      <path d="${d}" class="ce-curve"/><circle cx="${X(0)}" cy="${Y(0)}" r="3" class="ce-end"/><circle cx="${X(1)}" cy="${Y(1)}" r="3" class="ce-end"/>
      <circle id="ceDot" r="3.5" class="ce-dot" cx="${X(0)}" cy="${Y(0)}"/>
      ${[0, 1].map((h) => `<circle cx="${X(b[h * 2])}" cy="${Y(b[h * 2 + 1])}" r="14" class="ce-hit"/><circle data-h="${h}" cx="${X(b[h * 2])}" cy="${Y(b[h * 2 + 1])}" r="6" class="ce-h ${edDrag === h ? "on" : ""}"/>`).join("")}`;
    svg._map = { X, Y, W, H, pad, v };
    const vals = $("#ceVals");
    if (vals && !vals.querySelector("input")) vals.textContent = b.map((x) => r3(x)).join(", ");
    const nm = $("#ceName");
    if (nm) nm.textContent = ed.name || "Custom";
    const z = $("#ceZoom");
    if (z) z.classList.toggle("moved", userView);
  }
  function animateDot(now) {
    const svg = $("#ceG");
    if (!svg || current !== "curves") {
      edRaf = 0;
      return;
    }
    const m = svg._map, dot = $("#ceDot");
    if (m && dot) {
      const cyc = (now - edT0) / 1e3 % 1.6, x = Math.min(1, cyc / 1.2), y = easeAt(ed.b, x);
      dot.setAttribute("cx", m.X(x));
      dot.setAttribute("cy", m.Y(y));
    }
    edRaf = requestAnimationFrame(animateDot);
  }
  function graphAt(svg, e) {
    const m = svg._map, r = svg.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width * m.W, py = (e.clientY - r.top) / r.height * m.H;
    return { px, py, x: m.v.x0 + (px - m.pad) / (m.W - 2 * m.pad) * (m.v.x1 - m.v.x0), y: m.v.y0 + (m.H - m.pad - py) / (m.H - 2 * m.pad) * (m.v.y1 - m.v.y0) };
  }
  function zoomGraph(f, cx, cy) {
    const v = edRange || rangeFor(ed.b);
    if (cx == null) {
      cx = (v.x0 + v.x1) / 2;
      cy = (v.y0 + v.y1) / 2;
    }
    const sx = (v.x1 - v.x0) * f, sy = (v.y1 - v.y0) * f;
    if (sx < 0.04 || sy < 0.04 || sx > 8 || sy > 8) return;
    edRange = { x0: cx - (cx - v.x0) * f, x1: cx + (v.x1 - cx) * f, y0: cy - (cy - v.y0) * f, y1: cy + (v.y1 - cy) * f };
    userView = true;
    drawEditor();
  }
  function fitGraph() {
    userView = false;
    edRange = null;
    drawEditor();
  }
  function bindEditor() {
    const svg = $("#ceG");
    svg.addEventListener("mousedown", (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      const m = svg._map;
      if (!m) return;
      const p = graphAt(svg, e);
      let h = -1, best = 22;
      [0, 1].forEach((i) => {
        const dd = Math.hypot(m.X(ed.b[i * 2]) - p.px, m.Y(ed.b[i * 2 + 1]) - p.py);
        if (dd < best) {
          best = dd;
          h = i;
        }
      });
      const start = { x: e.clientX, y: e.clientY, v: { ...edRange || rangeFor(ed.b) } };
      if (h >= 0) {
        edDrag = h;
        svg.classList.add("dragging");
        drawEditor();
      } else svg.classList.add("panning");
      const move = (ev) => {
        if (edDrag >= 0) {
          const q = graphAt(svg, ev);
          const x = Math.max(0, Math.min(1, q.x));
          let y = Math.max(-2, Math.min(3, q.y));
          if (ev.shiftKey) y = edDrag === 0 ? 0 : 1;
          ed.b[edDrag * 2] = r3(x);
          ed.b[edDrag * 2 + 1] = r3(y);
          ed.name = "Custom";
          drawEditor();
        } else {
          const r = svg.getBoundingClientRect(), mm = svg._map;
          const dx = (ev.clientX - start.x) / r.width * (mm.W / (mm.W - 2 * mm.pad)) * (start.v.x1 - start.v.x0);
          const dy = (ev.clientY - start.y) / r.height * (mm.H / (mm.H - 2 * mm.pad)) * (start.v.y1 - start.v.y0);
          if (Math.abs(ev.clientX - start.x) + Math.abs(ev.clientY - start.y) < 3) return;
          edRange = { x0: start.v.x0 - dx, x1: start.v.x1 - dx, y0: start.v.y0 + dy, y1: start.v.y1 + dy };
          userView = true;
          drawEditor();
        }
      };
      const up = () => {
        document.removeEventListener("mousemove", move, true);
        document.removeEventListener("mouseup", up, true);
        window.removeEventListener("blur", up);
        svg.classList.remove("dragging", "panning");
        if (edDrag < 0) return;
        edDrag = -1;
        if (!userView) edRange = null;
        drawEditor();
        saveEd();
        if (cvState.live && ctx.comp) applyCurve("Custom", ed.b);
      };
      document.addEventListener("mousemove", move, true);
      document.addEventListener("mouseup", up, true);
      window.addEventListener("blur", up);
    });
    svg.addEventListener("wheel", (e) => {
      e.preventDefault();
      const p = graphAt(svg, e), dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
      zoomGraph(Math.exp(Math.max(-60, Math.min(60, dy)) * 4e-3), p.x, p.y);
    }, { passive: false });
    svg.addEventListener("dblclick", (e) => {
      e.preventDefault();
      fitGraph();
    });
    $("#ceZin").addEventListener("click", () => zoomGraph(0.7));
    $("#ceZout").addEventListener("click", () => zoomGraph(1 / 0.7));
    $("#ceFit").addEventListener("click", fitGraph);
    $("#ceVals").addEventListener("click", () => {
      const box = $("#ceVals");
      if (box.querySelector("input")) return;
      const inp = document.createElement("input");
      inp.className = "in";
      inp.value = ed.b.join(", ");
      box.textContent = "";
      box.appendChild(inp);
      inp.focus();
      inp.select();
      const done = (ok) => {
        if (ok) {
          const n = inp.value.split(/[ ,;]+/).map(Number).filter((v) => !Number.isNaN(v));
          if (n.length === 4) {
            ed = { b: [Math.max(0, Math.min(1, n[0])), n[1], Math.max(0, Math.min(1, n[2])), n[3]], name: "Custom" };
            saveEd();
          } else status("Type 4 numbers, like 0.33, 0, 0.67, 1", "err");
        }
        box.textContent = "";
        if (!userView) edRange = null;
        drawEditor();
      };
      inp.addEventListener("keydown", (e) => {
        e.stopPropagation();
        if (e.key === "Enter") done(true);
        if (e.key === "Escape") done(false);
      });
      inp.addEventListener("blur", () => done(true));
    });
  }
  async function readCurve(btn) {
    const r = await host("nt_curveRead");
    if (!r.ok) {
      flash(btn, false);
      return status(ERR[r.error] || r.error, "err");
    }
    ed = { b: fromAE(r.curve).map(r3), name: "From keyframes" };
    userView = false;
    edRange = null;
    saveEd();
    drawEditor();
    flash(btn, true);
    status("Ease of the selected keyframes loaded in the graph");
  }
  function saveCurve() {
    const row = $("#ceRow");
    if (!row || row.dataset.naming) return;
    const list = store.get("curves", []);
    const suggestion = ed.name && !["Custom", "Linear", "From keyframes"].includes(ed.name) && !list.some((c) => c.name === ed.name) && !PRESETS.some(([n]) => n === ed.name) ? ed.name : `My curve ${list.length + 1}`;
    row.dataset.naming = "1";
    row.innerHTML = `<input class="in grow" id="ceNameIn" maxlength="32" placeholder="Name this curve" value="${esc(suggestion)}"><button class="b main" id="ceNameOk" title="Save \xB7 Adds it to your library">${ICON.plus}<span class="lbl">Save</span></button><button class="b" id="ceNameNo" title="Cancel">${ICON.x}</button>`;
    const inp = $("#ceNameIn");
    inp.focus();
    inp.select();
    const done = (ok) => {
      if (ok) {
        const name = inp.value.trim();
        if (!name) {
          inp.focus();
          return status("Give your curve a name", "err");
        }
        const l = store.get("curves", []);
        const at = l.findIndex((c) => c.name.toLowerCase() === name.toLowerCase());
        if (at >= 0) l.splice(at, 1);
        l.unshift({ name, b: ed.b.map(r3) });
        store.set("curves", l);
        ed.name = name;
        saveEd();
        status(at >= 0 ? `\u201C${name}\u201D updated` : `\u201C${name}\u201D saved in your curves`);
      }
      render();
    };
    inp.addEventListener("keydown", (e) => {
      e.stopPropagation();
      if (e.key === "Enter") done(true);
      if (e.key === "Escape") done(false);
    });
    $("#ceNameOk").addEventListener("mousedown", (e) => e.preventDefault());
    $("#ceNameOk").addEventListener("click", () => done(true));
    $("#ceNameNo").addEventListener("click", () => done(false));
  }
  const Curves = {
    render(v) {
      const mine = store.get("curves", []), hidden = store.get("hiddenPresets", []);
      const tile = (n, b, i) => `<button class="t cv" data-b="${b.join(",")}" data-n="${esc(n)}" ${i != null ? `data-i="${i}"` : ""} title="${esc(n)} \xB7 Click to load it in the graph and apply it${i != null ? ". Double-click to rename" : ""}. \xD7 to delete">${i != null ? '<i class="mine-tag"></i>' : ""}${curveSVG(b)}<span>${esc(n)}</span><i class="x" ${i != null ? `data-del="${i}"` : `data-hide="${esc(n)}"`} title="Delete">${ICON.x}</i></button>`;
      v.innerHTML = `<div class="ce">
          <div class="ce-head"><span class="ce-name" id="ceName"></span><span class="ce-vals" id="ceVals" title="Values \xB7 Click to type them (cubic-bezier)"></span></div>
          <div class="ce-wrap"><svg id="ceG" class="ce-g" title="Graph \xB7 Drag a handle to shape the ease (Shift: flat). Scroll to zoom, drag the empty space to move, double-click to fit"></svg>
          <div class="ce-zoom" id="ceZoom"><button id="ceZout" title="Zoom out">${ICON.zout}</button><button id="ceZin" title="Zoom in \xB7 Or scroll on the graph">${ICON.zin}</button><button id="ceFit" title="Fit \xB7 Show the whole curve (or double-click the graph)">${ICON.frame}</button></div></div>
        </div>
        <div class="row" id="ceRow"><button class="b main grow needs-comp" id="ceApply" title="Apply \xB7 On the selected keyframes (two or more)">${ICON.curves}<span class="lbl">Apply</span></button><button class="b needs-comp" id="ceRead" title="Read \xB7 Load the ease of the selected keyframes into the graph">${ICON.copy}</button><button class="b" id="ceSave" title="Save \xB7 Add this curve to your library, with a name">${ICON.plus}</button></div>
        <div class="grid">${mine.map((c, i) => tile(c.name, c.b, i)).join("")}${PRESETS.filter(([n]) => !hidden.includes(n)).map(([n, b]) => tile(n, b)).join("")}</div>`;
      bindEditor();
      if (!userView) edRange = null;
      requestAnimationFrame(drawEditor);
      if (!edRaf) {
        edT0 = performance.now();
        edRaf = requestAnimationFrame(animateDot);
      }
      $("#ceApply", v).addEventListener("click", (e) => applyCurve(ed.name || "Custom", ed.b, e.currentTarget));
      $("#ceRead", v).addEventListener("click", (e) => readCurve(e.currentTarget));
      $("#ceSave", v).addEventListener("click", saveCurve);
      $$(".cv[data-b]", v).forEach((t) => {
        t.addEventListener("click", (e) => {
          if (e.target.closest("[data-del],[data-hide]")) return;
          ed = { b: t.dataset.b.split(",").map(Number), name: t.dataset.n };
          userView = false;
          edRange = null;
          saveEd();
          drawEditor();
          if (ctx.comp) applyCurve(t.dataset.n, ed.b, t);
        });
        if (t.dataset.i != null) t.addEventListener("dblclick", () => {
          const span = $("span", t);
          const inp = document.createElement("input");
          inp.className = "in";
          inp.value = t.dataset.n;
          inp.style.height = "18px";
          inp.style.fontSize = "10px";
          span.replaceWith(inp);
          inp.focus();
          inp.select();
          const done = () => {
            const list = store.get("curves", []);
            list[Number(t.dataset.i)].name = inp.value.trim() || t.dataset.n;
            store.set("curves", list);
            render();
          };
          inp.addEventListener("keydown", (e) => {
            e.stopPropagation();
            if (e.key === "Enter") done();
            if (e.key === "Escape") render();
          });
          inp.addEventListener("blur", done);
        });
      });
      $$("[data-del]", v).forEach((x) => x.addEventListener("click", (e) => {
        e.stopPropagation();
        const list = store.get("curves", []);
        const [g] = list.splice(Number(x.dataset.del), 1);
        store.set("curves", list);
        status(`\u201C${g.name}\u201D deleted`);
        render();
      }));
      $$("[data-hide]", v).forEach((x) => x.addEventListener("click", (e) => {
        e.stopPropagation();
        const h = store.get("hiddenPresets", []);
        h.push(x.dataset.hide);
        store.set("hiddenPresets", h);
        status(`\u201C${x.dataset.hide}\u201D removed \xB7 bring it back in the options`);
        render();
      }));
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">Graph</div>${opt("live", "Apply while editing", cvState.live, "Each time you release a handle")}
        <div class="ph" style="color:var(--dim);font-size:10px;padding-top:0">Drag a handle (Shift: flat). Scroll to zoom, drag the empty space to move around, double-click to fit. Click the numbers to type them.</div>
        <hr><div class="ph cap">Library</div>
        <div class="opt" id="oRestore"><span class="k">Bring back the built-in curves<small>${store.get("hiddenPresets", []).length ? `${plural(store.get("hiddenPresets", []).length, "curve")} removed` : "None removed"}</small></span></div>
        <div class="opt" id="oClearMine"><span class="k" style="color:var(--err)">Delete all my curves<small>${plural(store.get("curves", []).length, "saved curve")}</small></span></div>`, (p) => {
        bindOpts(p, cvState, () => store.set("curvesOpt", cvState));
        $("#oRestore", p).addEventListener("click", () => {
          store.set("hiddenPresets", []);
          closePop();
          status("Built-in curves are back");
          render();
        });
        const del = $("#oClearMine", p);
        del.addEventListener("click", () => {
          if (!del.dataset.sure) {
            del.dataset.sure = "1";
            $(".k", del).firstChild.textContent = "Click again to delete them all";
            return;
          }
          store.set("curves", []);
          closePop();
          status("Your curves were deleted");
          render();
        });
      });
    }
  };
  const bState = store.get("beat", { sens: 55, target: "layer", numbers: false, workArea: false, replace: true });
  delete bState.mode;
  let beat = null;
  async function decodeAudio(path) {
    let buf;
    if (CEP && typeof require === "function") {
      const b = require("fs").readFileSync(path);
      buf = b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
    } else buf = await (await fetch(path)).arrayBuffer();
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    try {
      return await ac.decodeAudioData(buf);
    } finally {
      ac.close && ac.close();
    }
  }
  function readAIFF(path) {
    const b = require("fs").readFileSync(path);
    if (b.toString("ascii", 0, 4) !== "FORM") throw new Error("Not an AIFF file");
    const aifc = b.toString("ascii", 8, 12) === "AIFC";
    let ch = 0, frames = 0, bits = 16, sr = 48e3, little = false, data = -1, p = 12;
    while (p + 8 <= b.length) {
      const id = b.toString("ascii", p, p + 4), size = b.readUInt32BE(p + 4), c = p + 8;
      if (id === "COMM") {
        ch = b.readUInt16BE(c);
        frames = b.readUInt32BE(c + 2);
        bits = b.readUInt16BE(c + 6);
        const e = b.readUInt16BE(c + 8) & 32767, hi = b.readUInt32BE(c + 10), lo = b.readUInt32BE(c + 14);
        sr = Math.round((hi * 4294967296 + lo) * Math.pow(2, e - 16383 - 63));
        if (aifc) little = b.toString("ascii", c + 18, c + 22) === "sowt";
      } else if (id === "SSND") data = c + 8 + b.readUInt32BE(c);
      p = c + size + (size & 1);
    }
    if (data < 0 || !ch || !frames) throw new Error("Empty AIFF");
    const by = bits / 8, n = Math.min(frames, Math.floor((b.length - data) / (by * ch)));
    const out = new OfflineAudioContext(1, Math.max(1, n), sr).createBuffer(1, Math.max(1, n), sr), d = out.getChannelData(0);
    const rd = bits === 16 ? (o) => (little ? b.readInt16LE(o) : b.readInt16BE(o)) / 32768 : bits === 24 ? (o) => (little ? b.readIntLE(o, 3) : b.readIntBE(o, 3)) / 8388608 : (o) => (little ? b.readInt32LE(o) : b.readInt32BE(o)) / 2147483648;
    for (let i = 0, o = data; i < n; i++) {
      let v = 0;
      for (let k = 0; k < ch; k++, o += by) v += rd(o);
      d[i] = v / ch;
    }
    return out;
  }
  const VIDEO = /\.(mp4|m4v|mov|mkv|avi|mxf|mts|m2ts|webm|wmv|flv|r3d|braw|mpg|mpeg|3gp)$/i;
  function tooBig(path) {
    try {
      return require("fs").statSync(path).size > 15e7;
    } catch (e) {
      return false;
    }
  }
  let lastAudio = null;
  async function loadAudio(info, say, range) {
    const L = lastAudio;
    if (L && L.id === info.sourceId && L.path === info.path && (!range || range.from >= L.off - 0.01 && range.to <= L.end + 0.01)) return L;
    let audio = null, off = 0;
    const from = range ? Math.max(0, range.from - 0.5) : 0, to = range ? range.to + 0.5 : 0;
    const direct = !NODE || !VIDEO.test(info.path) && !tooBig(info.path);
    if (direct) {
      try {
        audio = await decodeAudio(info.path);
      } catch (e) {
      }
    }
    if (!audio && NODE) {
      try {
        audio = await ffmpegRead(info.path, from, to);
        off = from;
      } catch (e) {
        audio = null;
      }
    }
    if (!audio) {
      if (say) say("Extracting the sound\u2026");
      const ex = await host("nt_extractAudio", info.index, from, to);
      if (ex.ok) {
        try {
          audio = /\.aiff?$/i.test(ex.path) ? readAIFF(ex.path) : await decodeAudio(ex.path);
          off = ex.from || 0;
        } catch (e) {
        }
      }
      if (!audio) throw new Error(ex.ok ? "Can\u2019t read this sound. Export it as WAV and use that layer" : ERR[ex.error] || ex.error);
    }
    lastAudio = { id: info.sourceId, path: info.path, audio, off, end: off + audio.duration };
    return lastAudio;
  }
  function binPath(name) {
    const path = nreq("path"), fs = nreq("fs");
    const bin = path.join(extDir(), "bin", IS_MAC ? "mac" : "win", IS_MAC ? name : name + ".exe");
    if (!fs.existsSync(bin)) return null;
    if (IS_MAC) {
      try {
        fs.chmodSync(bin, 493);
      } catch (e) {
      }
      try {
        nreq("child_process").execFileSync("/usr/bin/xattr", ["-d", "com.apple.quarantine", bin], { stdio: "ignore" });
      } catch (e) {
      }
    }
    return bin;
  }
  function ffmpegRead(file, from, to) {
    const bin = binPath("ffmpeg");
    if (!bin) return Promise.reject(new Error("no converter"));
    const path = nreq("path"), os = nreq("os"), fs = nreq("fs");
    const out = path.join(os.tmpdir(), `nothi_snd_${Date.now()}.wav`);
    const args = ["-nostdin", "-hide_banner", "-loglevel", "error", "-ss", String(from)];
    if (to > from) args.push("-t", String(to - from));
    args.push("-i", file, "-vn", "-sn", "-dn", "-ac", "1", "-ar", "44100", "-c:a", "pcm_s16le", "-y", out);
    return new Promise((resolve, reject) => {
      nreq("child_process").execFile(bin, args, { windowsHide: true, maxBuffer: 1 << 20 }, async (err) => {
        try {
          if (err || !fs.existsSync(out) || fs.statSync(out).size < 100) throw err || new Error("no sound");
          const a = await decodeAudio(out);
          resolve(a);
        } catch (e) {
          reject(e);
        } finally {
          try {
            fs.unlinkSync(out);
          } catch (e) {
          }
        }
      });
    });
  }
  const covers = (w) => !!beat && w.srcFrom >= beat.off - 0.01 && w.srcTo <= beat.end + 0.01;
  async function envelope(audio) {
    const sr = audio.sampleRate, len = audio.length;
    const mono = new Float32Array(len);
    for (let c = 0; c < audio.numberOfChannels; c++) {
      const ch = audio.getChannelData(c);
      for (let i = 0; i < len; i++) mono[i] += ch[i] / audio.numberOfChannels;
    }
    const oc = new OfflineAudioContext(1, len, sr), s = oc.createBufferSource(), lp1 = oc.createBiquadFilter(), lp2 = oc.createBiquadFilter();
    s.buffer = audio;
    lp1.type = lp2.type = "lowpass";
    lp1.frequency.value = lp2.frequency.value = 150;
    lp1.Q.value = lp2.Q.value = 0.7;
    s.connect(lp1);
    lp1.connect(lp2);
    lp2.connect(oc.destination);
    s.start();
    const bass = (await oc.startRendering()).getChannelData(0);
    const hop = Math.round(sr / 200), win = hop * 4, n = Math.max(0, Math.floor((len - win) / hop));
    const env = new Float32Array(n);
    for (let f = 0; f < n; f++) {
      let s2 = 0;
      const o = f * hop;
      for (let i = 0; i < win; i += 2) s2 += bass[o + i] * bass[o + i];
      env[f] = Math.sqrt(s2 / (win / 2));
    }
    return { env, fps: sr / hop, duration: len / sr, data: mono, sr };
  }
  function pickBeats(e, sens) {
    const { env, fps } = e, n = env.length, k = sens / 100;
    const near = Math.round(fps * 0.07), back = Math.round(fps * 0.15), ctxW = Math.round(fps * 1.5);
    const minGap = 0.32 - k * 0.2, level = 0.9 - k * 0.6, rise = 0.5 - k * 0.38;
    const loud = new Float32Array(n), dq = [];
    for (let f = 0, j = 0; f < n; f++) {
      while (j < n && j <= f + ctxW) {
        while (dq.length && env[dq[dq.length - 1]] <= env[j]) dq.pop();
        dq.push(j);
        j++;
      }
      while (dq[0] < f - ctxW) dq.shift();
      loud[f] = env[dq[0]];
    }
    let gmax = 0;
    for (let f = 0; f < n; f++) if (env[f] > gmax) gmax = env[f];
    const cands = [];
    for (let f = 1; f < n - 1; f++) {
      const v = env[f];
      if (v < gmax * 0.04 || v < env[f - 1] || v < env[f + 1]) continue;
      let top = true;
      for (let i = Math.max(0, f - near); i <= Math.min(n - 1, f + near); i++) if (env[i] > v) {
        top = false;
        break;
      }
      if (!top) continue;
      let lo = v;
      for (let i = Math.max(0, f - back); i < f; i++) if (env[i] < lo) lo = env[i];
      if (v < loud[f] * level || v - lo < v * rise) continue;
      let at = f, best = -1;
      for (let i = Math.max(1, f - back); i <= f; i++) {
        const d = env[i] - env[i - 1];
        if (d > best) {
          best = d;
          at = i;
        }
      }
      cands.push({ t: Math.max(0, (at + 2) / fps), v });
    }
    const out = [];
    cands.forEach((c) => {
      const last = out[out.length - 1];
      if (last && c.t - last.t < minGap) {
        if (c.v > last.v) out[out.length - 1] = c;
      } else out.push(c);
    });
    return out.map((c) => c.t);
  }
  function bpmOf(times) {
    const iv = times.slice(1).map((t, i) => t - times[i]).filter((d) => d > 0.2 && d < 2).sort((a, b) => a - b);
    let bpm = iv.length ? 60 / iv[Math.floor(iv.length / 2)] : 0;
    while (bpm && bpm < 70) bpm *= 2;
    while (bpm > 180) bpm /= 2;
    return Math.round(bpm);
  }
  function windowOf(info) {
    const k = info.stretch / 100;
    let from = info.inPoint, to = info.outPoint;
    if (bState.workArea) {
      from = Math.max(from, info.workStart);
      to = Math.min(to, info.workEnd);
    }
    return { from, to, srcFrom: (from - info.startTime) / k, srcTo: (to - info.startTime) / k, k };
  }
  function computeTimes() {
    if (!beat) return;
    const w = windowOf(beat.info);
    beat.all = pickBeats(beat.env, bState.sens).map((t) => t + beat.off);
    beat.times = beat.all.filter((t) => t >= w.srcFrom && t <= w.srcTo).map((t) => beat.info.startTime + t * w.k);
    beat.w = w;
    beat.bpm = bpmOf(beat.all);
  }
  function drawBeat() {
    const zone = $("#drop");
    if (!zone || !beat) return;
    zone.classList.add("has");
    zone.title = "Click the waveform to listen from there \xB7 \u2715 to remove it and use another layer";
    zone.innerHTML = `<canvas></canvas><div class="meta"><span>${esc(beat.info.name)}</span><span><b>${beat.times.length}</b> beats${beat.bpm ? ` \xB7 <b>${beat.bpm}</b> BPM` : ""}</span></div><button class="play" id="bPlay" title="Listen \xB7 The visible part only">${player.src ? ICON.stop : ICON.playOn}</button><button class="clear" id="bClearAudio" title="Remove \xB7 Unload this audio to use another layer">${ICON.x}</button>`;
    const cv = $("canvas", zone), dpr = devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
    cv.width = W * dpr;
    cv.height = H * dpr;
    const g = cv.getContext("2d");
    g.scale(dpr, dpr);
    const { data, sr } = beat.env, a = beat.w.srcFrom, b = Math.max(a + 0.01, beat.w.srcTo);
    const X = (t) => (t - a) / (b - a) * W;
    const bars = Math.max(20, Math.floor(W / 2)), bw = W / bars, peaks = [];
    for (let i = 0; i < bars; i++) {
      const s0 = Math.max(0, Math.floor((a - beat.off + i / bars * (b - a)) * sr)), s1 = Math.min(data.length, Math.floor((a - beat.off + (i + 1) / bars * (b - a)) * sr));
      let mx = 0;
      for (let j = s0; j < s1; j += 16) {
        const v = Math.abs(data[j]);
        if (v > mx) mx = v;
      }
      peaks.push(mx);
    }
    const max = Math.max(1e-4, ...peaks);
    peaks.forEach((p, i) => {
      const h = Math.max(1, p / max * (H - 26));
      g.fillStyle = "#4C4C54";
      g.fillRect(i * bw, (H + 14 - h) / 2, Math.max(1, bw - 0.6), h);
    });
    g.fillStyle = "rgba(255,255,255,.9)";
    beat.all.forEach((t) => {
      if (t >= a && t <= b) g.fillRect(X(t) - 0.5, 18, 1, H - 22);
    });
    cv.addEventListener("click", (e) => {
      e.stopPropagation();
      const r = cv.getBoundingClientRect();
      play(a + (e.clientX - r.left) / r.width * (b - a));
    });
    $("#bPlay", zone).addEventListener("click", (e) => {
      e.stopPropagation();
      if (player.src) stop();
      else play(Math.max(a, player.at || 0));
    });
    $("#bClearAudio", zone).addEventListener("click", (e) => {
      e.stopPropagation();
      unloadBeat();
    });
    const btn = $("#bAdd");
    if (btn) {
      btn.disabled = false;
      $(".lbl", btn).textContent = `Add ${plural(beat.times.length, "marker")}`;
    }
    $$(".needs-beat").forEach((x) => {
      x.disabled = false;
    });
  }
  function unloadBeat() {
    stop();
    beat = null;
    autoBeat = { key: ctx.aud ? `${ctx.aud.i}:${ctx.aud.id}:${ctx.aud.a}:${ctx.aud.b}` : "", skip: true };
    status("Audio removed \xB7 Select another layer to load it");
    if (current === "beat") render();
  }
  const player = { ac: null, src: null, at: 0, t0: 0, raf: 0 };
  function stop() {
    var _a;
    if (player.src) {
      try {
        player.src.onended = null;
        player.src.stop();
      } catch (e) {
      }
      player.src = null;
    }
    cancelAnimationFrame(player.raf);
    (_a = $("#drop .ph-line")) == null ? void 0 : _a.remove();
    const pb = $("#bPlay");
    if (pb) pb.innerHTML = ICON.playOn;
  }
  function play(from) {
    if (!beat || !beat.audio) return;
    stop();
    from = Math.max(beat.w.srcFrom, Math.min(from, beat.w.srcTo - 0.05));
    player.ac = player.ac || new (window.AudioContext || window.webkitAudioContext)();
    const src = player.ac.createBufferSource();
    src.buffer = beat.audio;
    src.connect(player.ac.destination);
    src.start(0, Math.max(0, from - beat.off), Math.max(0.05, beat.w.srcTo - from));
    src.onended = stop;
    player.src = src;
    player.at = from;
    player.t0 = player.ac.currentTime;
    const zone = $("#drop");
    zone.insertAdjacentHTML("beforeend", '<i class="ph-line"></i>');
    const pb = $("#bPlay");
    if (pb) pb.innerHTML = ICON.stop;
    const tick = () => {
      const line = $("#drop .ph-line");
      if (!line || !player.src) return;
      const t = player.at + (player.ac.currentTime - player.t0);
      line.style.left = `${(t - beat.w.srcFrom) / Math.max(0.01, beat.w.srcTo - beat.w.srcFrom) * 100}%`;
      player.raf = requestAnimationFrame(tick);
    };
    tick();
  }
  async function analyze(quiet) {
    var _a;
    const zone = $("#drop");
    if (!zone) return;
    stop();
    const info = await host("nt_audioInfo");
    if (!info.ok) {
      if (!quiet) {
        flash(zone, false);
        status(info.error === "NO_AUDIO" ? ERR.NO_AUDIO_SEL : ERR[info.error] || info.error, "err");
      }
      return;
    }
    zone.insertAdjacentHTML("beforeend", '<div class="busy"><span class="spin"></span><span id="busyMsg">Listening\u2026</span></div>');
    let got = null;
    const w0 = windowOf(info);
    try {
      got = await loadAudio(info, (t) => {
        const m = $("#busyMsg");
        if (m) m.textContent = t;
      }, { from: w0.srcFrom, to: w0.srcTo });
    } catch (e) {
      (_a = $(".busy", zone)) == null ? void 0 : _a.remove();
      flash(zone, false);
      return status(e.message, "err");
    }
    beat = { info, audio: got.audio, off: got.off, end: got.end, env: await envelope(got.audio) };
    computeTimes();
    drawBeat();
    remember("beat:find");
    autoBeat = { key: `${info.index}:${info.sourceId}:${info.inPoint}:${info.outPoint}`, skip: false };
    status(`${info.name}: ${plural(beat.times.length, "beat")} on the timeline${info.timeRemap ? " \xB7 time remap ignored" : ""}`);
  }
  let autoBeat = { key: "", skip: false };
  function autoLoad() {
    if (current !== "beat" || !ctx.aud || $("#drop .busy")) return;
    const key = `${ctx.aud.i}:${ctx.aud.id}:${ctx.aud.a}:${ctx.aud.b}`;
    if (key === autoBeat.key) return;
    if (beat && beat.info.index === ctx.aud.i && beat.info.sourceId === ctx.aud.id) {
      beat.info.inPoint = ctx.aud.a;
      beat.info.outPoint = ctx.aud.b;
      autoBeat.key = key;
      if (covers(windowOf(beat.info))) {
        computeTimes();
        drawBeat();
      } else if (!player.src) analyze(true);
      return;
    }
    if (beat && player.src) return;
    autoBeat = { key, skip: false };
    analyze(true);
  }
  const doSnap = (mode, btn) => {
    if (!beat) return status(ERR.NO_BEATS, "err");
    remember("beat:" + mode);
    return run(btn, host("nt_snapLayers", beat.times, mode, beat.info.index), (r) => mode === "sequence" ? `${plural(r.count, "layer")} sequenced, one per beat` : `${plural(r.count, "layer")} snapped to the nearest beat`);
  };
  const doCut = (btn) => {
    if (!beat) return status(ERR.NO_BEATS, "err");
    remember("beat:cut");
    return run(btn, host("nt_splitAt", beat.times, beat.info.index), (r) => `${plural(r.count, "cut")} \xB7 ${plural(r.layers, "clip")} split on the beats`);
  };
  const Beat = {
    render(v) {
      v.innerHTML = `<div class="drop needs-comp" id="drop" title="Drop an audio layer \xB7 Drag it from the timeline, or select it and click here">
          <div class="hint"><b>Select a layer with sound</b><small>or drop it here \xB7 WAV, MP3, MP4, MOV</small></div></div>
        <div class="row"><span class="cap">Sens.</span><input type="range" class="grow" id="bSens" min="0" max="100" value="${bState.sens}" title="Sensitivity \xB7 Left: only the strong hits. Right: every beat"><span class="num" id="bSensV">${bState.sens}</span></div>
        <div class="row"><button class="b main grow needs-comp" id="bAdd" ${beat ? "" : "disabled"} title="Add markers \xB7 On the layer or on the comp (see options)">${ICON.marker}<span class="lbl">Add markers</span></button><button class="b needs-comp" id="bRe" title="Read again \xB7 Uses the selected layer">${ICON.reload}</button><button class="b needs-comp" id="bClear" title="Remove the markers \xB7 Only those on the target (layer or comp)">${ICON.trash}</button></div>
        <div class="row"><span class="cap opt-cap">Layers</span><div class="seg"><button class="needs-comp needs-beat" id="bSnap" ${beat ? "" : "disabled"} title="Snap to beats \xB7 Each selected layer starts on the nearest beat">${ICON.snap}<span>Snap</span></button><button class="needs-comp needs-beat" id="bSeq" ${beat ? "" : "disabled"} title="Sequence on beats \xB7 Selected layers play one after another, one per beat">${ICON.seq}<span>Sequence</span></button><button class="needs-comp needs-beat" id="bCut" ${beat ? "" : "disabled"} title="Cut on beats \xB7 Splits the selected clips at every beat, like the razor tool. Each piece becomes its own layer">${ICON.cut}<span>Cut</span></button></div></div>`;
      const zone = $("#drop", v);
      zone.addEventListener("click", () => {
        if (!beat) analyze();
      });
      if (!beat) setTimeout(autoLoad, 0);
      ["dragenter", "dragover"].forEach((ev) => zone.addEventListener(ev, (e) => {
        e.preventDefault();
        zone.classList.add("over");
      }));
      zone.addEventListener("dragleave", () => zone.classList.remove("over"));
      zone.addEventListener("drop", (e) => {
        e.preventDefault();
        zone.classList.remove("over");
        analyze();
      });
      $("#bSens", v).addEventListener("input", (e) => {
        bState.sens = Number(e.target.value);
        $("#bSensV").textContent = bState.sens;
        store.set("beat", bState);
        if (beat) {
          computeTimes();
          drawBeat();
        }
      });
      $("#bAdd", v).addEventListener("click", async (e) => {
        if (!beat) return;
        const btn = e.currentTarget;
        remember("beat:add");
        if (bState.replace) await host("nt_clearMarkers", beat.info.index, bState.target);
        run(btn, host("nt_beatMarkers", beat.info.index, beat.times, bState.target, bState.numbers), (r) => `${plural(r.count, "marker")} added on the ${bState.target === "comp" ? "composition" : "layer"}`);
      });
      $("#bRe", v).addEventListener("click", analyze);
      $("#bClear", v).addEventListener("click", async (e) => {
        const idx = beat ? beat.info.index : (await host("nt_audioInfo")).index || 1;
        run(e.currentTarget, host("nt_clearMarkers", idx, bState.target), (r) => `${plural(r.count, "marker")} removed`);
      });
      $("#bSnap", v).addEventListener("click", (e) => doSnap("snap", e.currentTarget));
      $("#bSeq", v).addEventListener("click", (e) => doSnap("sequence", e.currentTarget));
      $("#bCut", v).addEventListener("click", (e) => doCut(e.currentTarget));
      if (beat) requestAnimationFrame(drawBeat);
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">Markers on</div>${opt("target=layer", "The audio layer", bState.target === "layer", "", true)}${opt("target=comp", "The composition", bState.target === "comp", "", true)}
        <hr>${opt("workArea", "Work area only", bState.workArea, "Otherwise the visible part of the layer")}${opt("replace", "Replace previous markers", bState.replace)}${opt("numbers", "Number the markers", bState.numbers)}
        <div class="ph" style="color:var(--dim);font-size:10px">Beats are the peaks of the bass (kick and bass line). Fewer markers: slide Sens. to the left.</div>`, (p) => {
        bindOpts(p, bState, () => store.set("beat", bState), () => {
          if (!beat) return;
          if (covers(windowOf(beat.info))) {
            computeTimes();
            drawBeat();
          } else analyze(true);
        });
      });
    }
  };
  const capState = store.get("captions", { lang: "auto", mode: "phrase", max: 4, model: "base", pos: "bottom", upper: false, punct: true, workArea: false, split: "words", center: true });
  const MODELS = { base: { file: "ggml-base.bin", mb: 142, min: 14e7, name: "Fast" }, small: { file: "ggml-small.bin", mb: 466, min: 46e7, name: "Best" } };
  const LANGS = [["auto", "Detect the language"], ["en", "English"], ["fr", "Fran\xE7ais"], ["es", "Espa\xF1ol"], ["de", "Deutsch"], ["it", "Italiano"], ["pt", "Portugu\xEAs"], ["nl", "Nederlands"], ["pl", "Polski"], ["tr", "T\xFCrk\xE7e"], ["ru", "\u0420\u0443\u0441\u0441\u043A\u0438\u0439"], ["ar", "\u0627\u0644\u0639\u0631\u0628\u064A\u0629"], ["ja", "\u65E5\u672C\u8A9E"], ["ko", "\uD55C\uAD6D\uC5B4"], ["zh", "\u4E2D\u6587"]];
  const NODE = CEP && typeof require === "function";
  const nreq = (m) => require(m);
  function extDir() {
    try {
      let p2 = decodeURI(window.__adobe_cep__.getSystemPath("extension"));
      p2 = IS_MAC ? p2.replace("file://", "") : p2.replace("file:///", "");
      if (p2) return p2;
    } catch (e) {
    }
    let p = decodeURIComponent(location.pathname).replace(/\/[^/]*$/, "");
    if (!IS_MAC) p = p.replace(/^\//, "");
    return p;
  }
  function dataDir() {
    const path = nreq("path"), os = nreq("os"), fs = nreq("fs");
    const base = IS_MAC ? path.join(os.homedir(), "Library", "Application Support") : process.env.APPDATA || path.join(os.homedir(), "AppData", "Roaming");
    const dir = path.join(base, "NothiLabs", "whisper");
    [path.join(base, "NothiLabs"), dir].forEach((d) => {
      if (!fs.existsSync(d)) fs.mkdirSync(d);
    });
    return dir;
  }
  const modelPath = (k = capState.model) => nreq("path").join(dataDir(), MODELS[k].file);
  function modelReady(k = capState.model) {
    if (!NODE) return true;
    try {
      const st = nreq("fs").statSync(modelPath(k));
      return st.size >= MODELS[k].min;
    } catch (e) {
      return false;
    }
  }
  function download(url, dest, onProgress, job) {
    const fs = nreq("fs"), urlm = nreq("url");
    return new Promise((resolve, reject) => {
      const go2 = (u, hops) => {
        const req = httpsGet(u, { "User-Agent": `NothiToolkit/${VERSION}` }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            if (hops > 8) return reject(new Error("Too many redirects"));
            return go2(urlm.resolve(u, res.headers.location), hops + 1);
          }
          if (res.statusCode !== 200) {
            res.resume();
            return reject(new Error("Download failed (HTTP " + res.statusCode + ")"));
          }
          const total = Number(res.headers["content-length"]) || 0, tmp = dest + ".part", out = fs.createWriteStream(tmp);
          let got = 0;
          job.abort = () => {
            req.abort();
            out.destroy();
            try {
              fs.unlinkSync(tmp);
            } catch (e) {
            }
            reject(new Error("CANCELLED"));
          };
          res.on("data", (c) => {
            got += c.length;
            if (onProgress) onProgress(got, total);
          });
          res.on("error", reject);
          out.on("error", reject);
          res.pipe(out);
          out.on("finish", () => {
            if (total && got < total) return reject(new Error("The download was cut. Try again"));
            try {
              if (fs.existsSync(dest)) fs.unlinkSync(dest);
              fs.renameSync(tmp, dest);
              resolve();
            } catch (e) {
              reject(e);
            }
          });
        });
        req.on("error", (e) => reject(new Error("No connection to download the speech model (" + e.message + ")")));
        req.setTimeout(45e3, () => req.abort());
      };
      go2(url, 0);
    });
  }
  async function toWav(audio, from, to) {
    const sr = 16e3, len = Math.max(1, Math.ceil((to - from) * sr));
    const oc = new OfflineAudioContext(1, len, sr), s = oc.createBufferSource();
    s.buffer = audio;
    s.connect(oc.destination);
    s.start(0, from, to - from);
    const d = (await oc.startRendering()).getChannelData(0);
    const buf = new ArrayBuffer(44 + d.length * 2), v = new DataView(buf);
    const W = (o, str) => {
      for (let i = 0; i < str.length; i++) v.setUint8(o + i, str.charCodeAt(i));
    };
    W(0, "RIFF");
    v.setUint32(4, 36 + d.length * 2, true);
    W(8, "WAVE");
    W(12, "fmt ");
    v.setUint32(16, 16, true);
    v.setUint16(20, 1, true);
    v.setUint16(22, 1, true);
    v.setUint32(24, sr, true);
    v.setUint32(28, sr * 2, true);
    v.setUint16(32, 2, true);
    v.setUint16(34, 16, true);
    W(36, "data");
    v.setUint32(40, d.length * 2, true);
    for (let i = 0; i < d.length; i++) {
      const x = Math.max(-1, Math.min(1, d[i]));
      v.setInt16(44 + i * 2, x < 0 ? x * 32768 : x * 32767, true);
    }
    return Buffer.from(buf);
  }
  function whisperBin() {
    const bin = binPath("whisper-cli");
    if (!bin) throw new Error("The transcription program is missing. Reinstall Nothi Toolkit");
    return bin;
  }
  function runWhisper(args, onProgress, job) {
    const cp = nreq("child_process");
    return new Promise((resolve, reject) => {
      const p = cp.spawn(whisperBin(), args, { windowsHide: true });
      job.abort = () => {
        try {
          p.kill();
        } catch (e) {
        }
        reject(new Error("CANCELLED"));
      };
      let err = "";
      const read = (c) => {
        const t = String(c);
        err = (err + t).slice(-2e3);
        const m = t.match(/progress\s*=\s*(\d+)%/g);
        if (m) onProgress(Number(m[m.length - 1].replace(/\D/g, "")));
      };
      p.stdout.on("data", read);
      p.stderr.on("data", read);
      p.on("error", (e) => reject(new Error("Can\u2019t start the transcription (" + e.message + ")")));
      p.on("close", (code) => code === 0 ? resolve() : reject(new Error("Transcription failed (code " + code + ")" + (err ? ": " + err.trim().split("\n").pop() : ""))));
    });
  }
  const INK = /[^\s.,!?;:'"…»«”“()\-–—。，！？、]/;
  function wordsFromJSON(res) {
    const words = [];
    (res.transcription || []).forEach((seg, si) => {
      const segA = seg.offsets.from / 1e3, segB = seg.offsets.to / 1e3;
      if (!seg.tokens) {
        const w = String(seg.text || "").trim();
        if (w) words.push({ w, a: segA, b: segB, end: segB, seg: si });
        return;
      }
      let cur = null;
      seg.tokens.forEach((t) => {
        const txt = String(t.text || "");
        if (!txt.trim() || /^\[_|^<\|/.test(txt.trim())) return;
        const a = t.offsets.from / 1e3, z = t.offsets.to / 1e3;
        if (!cur || /^\s/.test(txt) && INK.test(txt)) {
          if (cur) words.push(cur);
          cur = { w: txt.trim(), a, end: z, seg: si };
        } else {
          cur.w += txt;
          if (INK.test(txt)) cur.end = Math.max(cur.end, z);
        }
      });
      if (cur) words.push(cur);
    });
    words.forEach((w, i) => {
      const n = words[i + 1];
      w.b = Math.max(w.a + 0.08, n ? Math.min(w.end, n.a) : Math.min(w.end, w.a + 1.5));
    });
    return words.filter((t) => t.w && !/^[[(].*[\])]$/.test(t.w) && !/^[♪*]+$/.test(t.w));
  }
  const END = /[.!?…。！？]["»”')]?$/, COMMA = /[,;:،、，]["»”')]?$/;
  function groupWords(words, o) {
    const sents = [];
    let cur = [];
    words.forEach((w) => {
      const prev = cur[cur.length - 1], gap = prev ? w.a - prev.b : 0;
      if (prev && (END.test(prev.w) || gap > 0.8 || COMMA.test(prev.w) && gap > 0.3 || w.seg !== prev.seg && gap > 0.3)) {
        sents.push(cur);
        cur = [];
      }
      cur.push(w);
    });
    if (cur.length) sents.push(cur);
    const max = o.mode === "word" ? 1 : Math.max(1, o.max), MAXC = 34;
    const len = (arr) => arr.reduce((k, w) => k + w.w.length + 1, 0) - 1;
    const score2 = (s, i) => (COMMA.test(s[i - 1].w) ? 2 : 0) + Math.min(1, Math.max(0, s[i].a - s[i - 1].b)) * 4;
    const split = (s) => {
      for (let n = Math.ceil(s.length / max); n <= s.length; n++) {
        const cuts = [];
        let last = 0;
        for (let k = 1; k < n; k++) {
          const ideal = Math.round(k * s.length / n);
          let best = -1, bs = -1e9;
          for (const d of [0, -1, 1]) {
            const i = ideal + d, left = s.length - i, chunksLeft = n - k;
            if (i - last < 1 || i - last > max || left < chunksLeft || left > chunksLeft * max) continue;
            const sc = score2(s, i) - Math.abs(d) * 0.6;
            if (sc > bs) {
              bs = sc;
              best = i;
            }
          }
          if (best < 0) best = Math.min(s.length - (n - k), Math.max(last + 1, ideal));
          cuts.push(best);
          last = best;
        }
        const parts = [];
        let i0 = 0;
        [...cuts, s.length].forEach((c) => {
          parts.push(s.slice(i0, c));
          i0 = c;
        });
        if (parts.every((p) => p.length && p.length <= max && (p.length === 1 || len(p) <= MAXC))) return parts;
      }
      return s.map((w) => [w]);
    };
    const out = [];
    sents.forEach((s) => split(s).forEach((p) => out.push({ a: p[0].a, b: p[p.length - 1].b, text: p.map((w) => w.w).join(" ") })));
    out.forEach((c, i) => {
      const n = out[i + 1];
      c.b = n ? n.a - c.b < 0.6 ? n.a : c.b + 0.25 : c.b + 0.3;
      c.b = Math.max(c.b, c.a + 0.3);
      if (n) c.b = Math.min(c.b, n.a);
    });
    if (!o.punct) out.forEach((c) => {
      c.text = c.text.replace(/[.,;:،、，。](?=\s|$)/g, "").trim();
    });
    return out.filter((c) => c.text);
  }
  let capJob = null;
  function capBusy(msg, pct) {
    const zone = $("#capZone");
    if (!zone) return;
    let b = $(".busy", zone);
    if (!b) {
      zone.insertAdjacentHTML("beforeend", '<div class="busy"><span class="spin"></span><span id="capMsg"></span><i class="bar-p"><i></i></i><button class="cancel" id="capCancel" title="Cancel">' + ICON.x + "</button></div>");
      b = $(".busy", zone);
      $("#capCancel", b).addEventListener("click", (e) => {
        e.stopPropagation();
        if (capJob && capJob.abort) capJob.abort();
      });
    }
    $("#capMsg", b).textContent = msg;
    const bar = $(".bar-p", b);
    bar.style.visibility = pct == null ? "hidden" : "visible";
    $("i", bar).style.width = `${Math.round(pct || 0)}%`;
  }
  const capDone = () => {
    const b = $("#capZone .busy");
    if (b) b.remove();
    capJob = null;
  };
  async function autoCaptions(btn) {
    if (capJob) return;
    const info = await host("nt_audioInfo");
    if (!info.ok) {
      flash(btn, false);
      return status(info.error === "NO_AUDIO" ? "Select the clip with the voice (a layer with sound)" : ERR[info.error] || info.error, "err");
    }
    const k = info.stretch / 100;
    let from = info.inPoint, to = info.outPoint;
    if (capState.workArea) {
      from = Math.max(from, info.workStart);
      to = Math.min(to, info.workEnd);
    }
    if (to - from < 0.3) return status("This part is too short", "err");
    const srcFrom = Math.max(0, Math.min((from - info.startTime) / k, (to - info.startTime) / k)), srcTo = Math.max((from - info.startTime) / k, (to - info.startTime) / k);
    const job = capJob = {};
    remember("captions");
    try {
      let words;
      if (!NODE) {
        capBusy("Writing the captions\u2026", 60);
        await new Promise((r2) => setTimeout(r2, 900));
        words = "So this is how I edit my clips , fast and clean . You just select the part and click once !".split(" ").reduce((a, w) => {
          if (/^[,.!]$/.test(w)) a[a.length - 1].w += w;
          else a.push({ w, a: a.length * 0.32, b: a.length * 0.32 + 0.28 });
          return a;
        }, []);
      } else {
        const fs = nreq("fs"), path = nreq("path"), os = nreq("os");
        if (!modelReady()) {
          const M = MODELS[capState.model];
          capBusy(`Downloading the speech model (${M.mb} MB, only once)\u2026`, 0);
          await download(`https://huggingface.co/ggerganov/whisper.cpp/resolve/main/${M.file}`, modelPath(), (g, t) => capBusy(`Downloading the speech model \xB7 ${Math.round(g / 1e6)} / ${t ? Math.round(t / 1e6) : M.mb} MB`, t ? g / t * 100 : null), job);
        }
        capBusy("Reading the sound\u2026", null);
        const got = await loadAudio(info, (t) => capBusy(t, null), { from: srcFrom, to: srcTo });
        const wav = await toWav(got.audio, Math.max(0, srcFrom - got.off), Math.min(srcTo - got.off, got.audio.duration));
        const tmp = path.join(os.tmpdir(), `nothi_cap_${Date.now()}`);
        fs.writeFileSync(tmp + ".wav", wav);
        const threads = String(Math.max(2, Math.min(8, (os.cpus() || []).length - 1)));
        const base = ["-m", modelPath(), "-f", tmp + ".wav", "-l", capState.lang, "-of", tmp, "-pp", "-t", threads];
        const precise = [...base, "-ojf"];
        const simple = [...base, "-ml", "1", "-sow", "-oj"];
        capBusy("Listening\u2026 0%", 0);
        const prog = (p) => capBusy(`Listening\u2026 ${p}%`, p);
        const attempt = async (args) => {
          try {
            await runWhisper(args, prog, job);
          } catch (e) {
            if (e.message === "CANCELLED" || !IS_MAC) throw e;
            await runWhisper([...args, "-ng"], prog, job);
          }
        };
        try {
          await attempt(precise);
        } catch (e) {
          if (e.message === "CANCELLED") throw e;
          await attempt(simple);
        }
        const res = JSON.parse(fs.readFileSync(tmp + ".json", "utf8"));
        [tmp + ".wav", tmp + ".json"].forEach((f) => {
          try {
            fs.unlinkSync(f);
          } catch (e) {
          }
        });
        words = wordsFromJSON(res);
        job.lang = res.result && res.result.language;
      }
      if (!words.length) {
        capDone();
        return status(ERR.NO_WORDS, "err");
      }
      const items = groupWords(words, capState).map((c) => ({ text: c.text, a: info.startTime + (srcFrom + c.a) * k, b: info.startTime + (srcFrom + Math.max(c.b, c.a + 0.1)) * k }));
      capBusy("Creating the text layers\u2026", 100);
      const r = await host("nt_captions", items, { pos: capState.pos, upper: capState.upper });
      capDone();
      if (!r.ok) {
        flash(btn, false);
        return status(ERR[r.error] || r.error, "err");
      }
      flash(btn, true);
      status(`${plural(r.count, "caption")} created${job.lang ? ` \xB7 ${job.lang.toUpperCase()}` : ""}${r.template ? ` \xB7 style of \u201C${r.template}\u201D` : ""}`, "done", true);
    } catch (e) {
      capDone();
      if (e.message === "CANCELLED") return status("Cancelled");
      flash(btn, false);
      status(e.message || String(e), "err");
    }
  }
  const SPLITS = [["words", "Words", "Each word on its own layer"], ["lines", "Lines", "Each line on its own layer"], ["letters", "Letters", "Each letter on its own layer"]];
  const doSplit = (btn, mode = capState.split) => (remember("split:" + mode), run(btn, host("nt_splitText", mode, capState.center, true), (r) => `${plural(r.count, mode === "lines" ? "line" : mode === "letters" ? "letter" : "word")} on their own layers \xB7 the original is turned off${r.boxes ? ` \xB7 ${r.boxes} paragraph text skipped` : ""}`));
  const capInfoHTML = () => {
    const a = ctx.aud;
    return a ? `<div class="meta"><span>${esc(a.n)}</span><span><b>${(a.b - a.a).toFixed(1)}</b> s</span></div><div class="hint"><b>Ready</b><small>${capState.workArea ? "Work area only" : "The visible part of the clip"}</small></div>` : '<div class="hint"><b>Select the clip with the voice</b><small>Video or audio layer \xB7 trim it to caption a part</small></div>';
  };
  const Captions = {
    render(v) {
      const M = MODELS[capState.model], ready = modelReady();
      v.innerHTML = `<div class="drop cap-zone needs-comp" id="capZone" title="Clip to caption \xB7 The selected layer with sound. Only the part visible in the timeline is used">${capInfoHTML()}</div>
        <div class="row"><select class="in grow" id="capLang" title="Language \xB7 Detect works for most videos. Pick it if words come out wrong">${LANGS.map(([c, n]) => `<option value="${c}" ${capState.lang === c ? "selected" : ""}>${n}</option>`).join("")}</select></div>
        <div class="row"><div class="seg" id="capMode"><button data-m="phrase" class="${capState.mode === "phrase" ? "on" : ""}" title="Phrases \xB7 A few words per caption, cut on punctuation and pauses">${ICON.captions}<span>Phrases</span></button><button data-m="word" class="${capState.mode === "word" ? "on" : ""}" title="Word by word \xB7 One word at a time, the TikTok style">${ICON.words}<span>Word by word</span></button></div></div>
        <div class="row" id="capMaxRow" ${capState.mode === "word" ? "hidden" : ""}><span class="cap opt-cap">Words</span><input type="range" class="grow" id="capMax" min="2" max="10" value="${capState.max}" title="Words per caption \xB7 The most words on screen at once"><span class="num" id="capMaxV">${capState.max}</span></div>
        <button class="b main big needs-comp" id="capGo" title="Auto captions \xB7 Listens to the clip and creates one text layer per caption">${ICON.captions}<span class="lbl">Auto captions</span></button>
        <div class="mdl">${NODE ? ready ? `Speech model ready \xB7 ${M.name}` : `First time: downloads the speech model (${M.mb} MB, once)` : "Preview mode"} \xB7 runs on your computer</div>
        <div class="sec-h cap split-h">Split text</div>
        <div class="row" id="capSplitRow"><div class="seg" id="capSplit">${SPLITS.map(([k, n, t]) => `<button data-s="${k}" class="${capState.split === k ? "on" : ""}" title="${n} \xB7 ${t}">${n}</button>`).join("")}</div><button class="b needs-comp grow" id="capSplitGo" title="Split \xB7 Selected text layers: each piece gets its own layer, exactly in place. The original is turned off">${ICON.split}<span class="lbl">Split</span></button></div>`;
      $("#capLang", v).addEventListener("change", (e) => {
        capState.lang = e.target.value;
        store.set("captions", capState);
      });
      $("#capLang", v).addEventListener("keydown", (e) => e.stopPropagation());
      $$("#capMode button", v).forEach((b) => b.addEventListener("click", () => {
        capState.mode = b.dataset.m;
        store.set("captions", capState);
        $$("#capMode button", v).forEach((x) => x.classList.toggle("on", x === b));
        $("#capMaxRow", v).hidden = capState.mode === "word";
      }));
      $("#capMax", v).addEventListener("input", (e) => {
        capState.max = Number(e.target.value);
        $("#capMaxV").textContent = capState.max;
        store.set("captions", capState);
      });
      $("#capGo", v).addEventListener("click", (e) => autoCaptions(e.currentTarget));
      $$("#capSplit button", v).forEach((b) => b.addEventListener("click", () => {
        capState.split = b.dataset.s;
        store.set("captions", capState);
        $$("#capSplit button", v).forEach((x) => x.classList.toggle("on", x === b));
      }));
      $("#capSplitGo", v).addEventListener("click", (e) => doSplit(e.currentTarget));
    },
    refresh() {
      const z = $("#capZone");
      if (z && !$(".busy", z)) z.innerHTML = capInfoHTML();
    },
    options(btn) {
      openPop(btn, `<div class="ph cap">Accuracy</div>${Object.entries(MODELS).map(([k, m]) => opt("model=" + k, m.name, capState.model === k, `${k === "base" ? "Quick, good for clear voices" : "Slower, better with accents, music, noise"} \xB7 ${m.mb} MB${modelReady(k) ? ", downloaded" : ""}`, true)).join("")}
        <hr><div class="ph cap">Captions</div>${opt("pos=bottom", "Bottom of the frame", capState.pos === "bottom", "", true)}${opt("pos=center", "Center", capState.pos === "center", "", true)}${opt("upper", "UPPERCASE", capState.upper)}${opt("punct", "Keep punctuation", capState.punct, "Off: no commas or periods")}${opt("workArea", "Work area only", capState.workArea, "Otherwise the visible part of the clip")}
        <div class="ph" style="color:var(--dim);font-size:10px">Your own look: name a text layer <b style="color:var(--text)">Caption style</b>. Every caption copies its font, size, effects and animation.</div>
        <hr><div class="ph cap">Split text</div>${opt("center", "Center the anchor of each piece", capState.center, "Handy to scale or rotate each word")}`, (p) => {
        bindOpts(p, capState, () => store.set("captions", capState), () => {
          if (current === "captions") render();
        });
      });
    }
  };
  const lState = store.get("layers", { trim: true, scope: "selected", tags: true, deleteItem: false });
  Object.assign(lState, { dupMode: lState.dupMode || "new", dupDeep: lState.dupDeep !== false, seqOrder: lState.seqV2 ? lState.seqOrder : "bottom", seqV2: true, seqStart: lState.seqStart || "first", seqGap: lState.seqGap || 0 });
  const ANCHORS = [[0, 0, "top left"], [0.5, 0, "top"], [1, 0, "top right"], [0, 0.5, "left"], [0.5, 0.5, "center"], [1, 0.5, "right"], [0, 1, "bottom left"], [0.5, 1, "bottom"], [1, 1, "bottom right"]];
  const doAnchor = (x, y, btn) => (remember(`anchor:${x},${y}`), run(btn, host("nt_anchor", x, y), (r) => `Anchor moved \xB7 ${plural(r.count, "layer")}${r.skipped ? ` (${r.skipped} skipped)` : ""}`));
  const doPrecomp = (btn) => (remember("precomp"), run(btn, host("nt_precompose", "", lState.trim), (r) => `Precomposed as \u201C${r.name}\u201D`));
  const doDecomp = (btn) => (remember("decomp"), run(btn, host("nt_decompose", lState.deleteItem), (r) => `${plural(r.count, "layer")} back in the comp${r.lost.length ? ` \xB7 not kept: ${r.lost.join(", ")}` : ""}`));
  const doDuplicate = (btn) => (remember("dupcomp"), run(btn, host("nt_dupPrecomp", lState.dupMode, lState.dupDeep), (r) => `${r.count === 1 ? `\u201C${r.names[0]}\u201D created` : `${plural(r.count, "precomp")} duplicated`} \xB7 independent from the original${r.comps > r.count ? ` (+${r.comps - r.count} nested)` : ""}`));
  const FLIP = { bottom: "stack", stack: "bottom", selection: "selection-rev", "selection-rev": "selection" };
  const ORDER_NAME = { bottom: "bottom layer first", stack: "top layer first", selection: "click order", "selection-rev": "reverse click order" };
  const doInvert = (btn) => {
    lState.seqOrder = FLIP[lState.seqOrder] || "stack";
    store.set("layers", lState);
    remember("invert");
    return run(btn, host("nt_sequence", lState.seqOrder, lState.seqStart, Number(lState.seqGap) || 0), (r) => `Order inverted \xB7 ${plural(r.count, "clip")}, ${ORDER_NAME[lState.seqOrder]}`);
  };
  const doSequence = (btn) => (remember("sequence"), run(btn, host("nt_sequence", lState.seqOrder, lState.seqStart, Number(lState.seqGap) || 0), (r) => `${plural(r.count, "clip")} in sequence${Number(lState.seqGap) ? ` \xB7 ${Math.abs(lState.seqGap)} frame${Math.abs(lState.seqGap) === 1 ? "" : "s"} ${lState.seqGap > 0 ? "gap" : "overlap"}` : ""}`));
  const doRename = (btn, scope = lState.scope) => (remember("rename:" + scope), run(btn, host("nt_rename", scope, lState.tags), (r) => `${plural(r.count, "layer")} renamed`));
  const layersHTML = () => `<div class="row" style="align-items:stretch">
        <div class="anchor needs-comp" title="Anchor point \xB7 The layer doesn\u2019t move, even when scaled or rotated">${ANCHORS.map(([x, y, n]) => `<button data-x="${x}" data-y="${y}" title="Anchor: ${n}"><i></i></button>`).join("")}</div>
        <div class="bgrid">
          <button class="b needs-comp" id="lPre" title="Precompose \xB7 Selected layers go into a new comp, trimmed to their length">${ICON.precomp}<span class="lbl">Precomp</span></button>
          <button class="b needs-comp" id="lDec" title="Decompose \xB7 Brings a precomp\u2019s layers back into this comp, timing kept">${ICON.decomp}<span class="lbl">Decomp</span></button>
          <button class="b needs-comp" id="lDup" title="Duplicate \xB7 An independent copy of the selected precomp. Editing inside it never changes the original">${ICON.dup}<span class="lbl">Duplicate</span></button>
          <button class="b needs-comp" id="lRen" title="Rename \xB7 By type and content: \u201CTXT \u2013 Title\u201D, \u201CVID \u2013 Clip 04\u201D\u2026">${ICON.rename}<span class="lbl">Rename</span></button>
          <button class="b needs-comp" id="lSeq" title="Sequence \xB7 Selected clips one after another. The bottom layer comes first (left), the top layer last (right)">${ICON.seq}<span class="lbl">Sequence</span></button>
          <button class="b needs-comp" id="lInv" title="Invert \xB7 Flips the order of the sequence: the first clip becomes the last">${ICON.invert}<span class="lbl">Invert</span></button>
        </div></div>`;
  function bindLayers(v) {
    $$(".anchor button", v).forEach((b) => b.addEventListener("click", () => doAnchor(Number(b.dataset.x), Number(b.dataset.y), b)));
    $("#lPre", v).addEventListener("click", (e) => doPrecomp(e.currentTarget));
    $("#lDec", v).addEventListener("click", (e) => doDecomp(e.currentTarget));
    $("#lDup", v).addEventListener("click", (e) => doDuplicate(e.currentTarget));
    $("#lSeq", v).addEventListener("click", (e) => doSequence(e.currentTarget));
    $("#lInv", v).addEventListener("click", (e) => doInvert(e.currentTarget));
    $("#lRen", v).addEventListener("click", (e) => doRename(e.currentTarget));
  }
  const layersOptions = () => `<div class="ph cap">Sequence</div>${opt("seqOrder=bottom", "Bottom layer first", lState.seqOrder === "bottom", "The top layer ends up last, on the right", true)}${opt("seqOrder=stack", "Top layer first", lState.seqOrder === "stack", "", true)}${opt("seqOrder=selection", "Click order", lState.seqOrder === "selection", "The first clip you selected plays first", true)}
        ${opt("seqStart=first", "Start at the first clip", lState.seqStart === "first", "", true)}${opt("seqStart=playhead", "Start at the playhead", lState.seqStart === "playhead", "", true)}
        <div class="field row"><span class="k grow">Gap between clips</span><input class="in" id="oGap" type="number" step="1" value="${Number(lState.seqGap) || 0}" style="width:64px;text-align:right"><span class="num" style="min-width:0">fr</span></div>
        <div class="ph" style="color:var(--dim);font-size:10px;padding-top:0">Negative = overlap, for crossfades.</div>
        <hr><div class="ph cap">Duplicate precomp</div>${opt("dupMode=new", "New layer above", lState.dupMode === "new", "The original layer stays as it is", true)}${opt("dupMode=unique", "Make this layer independent", lState.dupMode === "unique", "The selected layer switches to the copy", true)}${opt("dupDeep", "Copy nested precomps too", lState.dupDeep, "Otherwise precomps inside stay shared")}
        <hr><div class="ph cap">Precompose</div>${opt("trim", "Trim to the layers", lState.trim, "The precomp starts and ends with them")}
        <hr><div class="ph cap">Decompose</div>${opt("deleteItem", "Delete the precomp from the project", lState.deleteItem, "Only if it isn\u2019t used anywhere else")}
        <hr><div class="ph cap">Rename</div>${opt("scope=selected", "Selected layers", lState.scope === "selected", "", true)}${opt("scope=all", "Whole composition", lState.scope === "all", "", true)}${opt("tags", "Type tags", lState.tags, "TXT \u2013 , VID \u2013 , ADJ \u2013 \u2026")}`;
  function bindLayersOptions(p) {
    bindOpts(p, lState, () => store.set("layers", lState));
    const g = $("#oGap", p);
    g.addEventListener("keydown", (e) => e.stopPropagation());
    g.addEventListener("input", () => {
      lState.seqGap = Math.round(Number(g.value) || 0);
      store.set("layers", lState);
    });
  }
  const sState = store.get("style", { effects: true, replace: false, blend: true, transform: false, keys: false });
  if (!sState.anim) sState.anim = "fit";
  const syncAnim = () => {
    sState.keys = sState.anim !== "off";
    sState.timing = sState.anim;
    store.set("style", sState);
  };
  syncAnim();
  const ANIM = [["off", "Off", "No animation \xB7 Pastes the effects with their current values"], ["shift", "Keep", "Keep timing \xB7 Same keyframe timing, from each clip\u2019s start"], ["fit", "Fit to clip", "Fit to clip \xB7 Keyframes stretch or squeeze to each clip\u2019s length. The speed graph keeps its exact shape"]];
  let copied = null;
  const doCopy = async (btn) => {
    remember("copy");
    const r = await run(btn, host("nt_styleCopy", true), (x) => `Copied the style of \u201C${x.layer}\u201D${x.keys ? ` \xB7 ${plural(x.keys, "keyframe")}` : ""}`);
    if (r.ok) {
      copied = r;
      if (current === "create" || current === "style") render();
    }
  };
  const doPaste = (btn, timing) => {
    remember(timing === "fit" ? "paste:fit" : "paste");
    return run(btn, host("nt_stylePaste", { ...sState, ...timing ? { timing, keys: true } : {} }), (r) => `Style pasted on ${plural(r.count, "layer")}${r.fitted ? ` \xB7 animation fitted to ${plural(r.fitted, "clip")}` : ""}`);
  };
  const styleHTML = () => `<div class="pair"><button class="b needs-comp" id="sCopy" title="Copy style \xB7 Effects, animation and look of the selected layer">${ICON.copy}<span>Copy</span></button><button class="b needs-comp" id="sPaste" ${copied ? "" : "disabled"} title="Paste style \xB7 On every selected layer. Choose what in the options">${ICON.paste}<span>Paste</span></button></div>
        <div class="clip">${copied ? `<b>${esc(copied.layer)}</b><span class="fx">${copied.effects.length ? esc(copied.effects.join(", ")) : "no effects"}${copied.keys ? ` \xB7 ${plural(copied.keys, "keyframe")} over ${(+copied.duration || 0).toFixed(1)} s` : ""}</span>` : "<span>Nothing copied yet</span>"}</div>
        <div class="row"><span class="cap opt-cap">Animation</span><div class="seg" id="sAnim">${ANIM.map(([k, n, t]) => `<button data-anim="${k}" class="${sState.anim === k ? "on" : ""}" title="${t}">${ICON[k === "shift" ? "keep" : k]}<span>${n}</span></button>`).join("")}</div></div>`;
  function bindStyle(v) {
    $("#sCopy", v).addEventListener("click", (e) => doCopy(e.currentTarget));
    $("#sPaste", v).addEventListener("click", (e) => doPaste(e.currentTarget));
    $$("#sAnim button", v).forEach((b) => b.addEventListener("click", () => {
      sState.anim = b.dataset.anim;
      syncAnim();
      $$("#sAnim button", v).forEach((x) => x.classList.toggle("on", x === b));
      const t = ANIM.find((a) => a[0] === b.dataset.anim)[2];
      status(t.replace(" \xB7 ", ": "));
    }));
  }
  const styleOptions = () => `<div class="ph cap">Paste style</div>${opt("effects", "Effects", sState.effects)}${opt("replace", "Replace existing effects", sState.replace)}${opt("blend", "Blend mode, opacity, motion blur", sState.blend)}${opt("transform", "Scale & rotation", sState.transform)}`;
  const Create = {
    render(v) {
      if (!full) {
        v.innerHTML = createHTML();
        bindCreate(v);
        $(".ct", v).classList.add("fill");
        requestAnimationFrame(fitTiles);
        return;
      }
      v.innerHTML = `<section class="sec">${createHTML()}</section>
        <section class="sec"><div class="sec-h cap">Layers</div>${layersHTML()}</section>
        <section class="sec"><div class="sec-h cap">Copy style</div>${styleHTML()}</section>`;
      bindCreate(v);
      bindLayers(v);
      bindStyle(v);
    },
    options(btn) {
      if (!full) return openPop(btn, `<div id="oC">${createOptions()}</div>`, (p) => bindCreateOptions($("#oC", p)));
      openPop(btn, `<div id="oC">${createOptions()}</div><hr><div id="oL">${layersOptions()}</div><hr><div id="oS">${styleOptions()}</div>`, (p) => {
        bindCreateOptions($("#oC", p));
        bindLayersOptions($("#oL", p));
        bindOpts($("#oS", p), sState, () => store.set("style", sState));
      });
    }
  };
  const Layers = {
    render(v) {
      v.innerHTML = layersHTML();
      bindLayers(v);
    },
    options(btn) {
      openPop(btn, `<div id="oL">${layersOptions()}</div>`, (p) => bindLayersOptions($("#oL", p)));
    }
  };
  const Style = {
    render(v) {
      v.innerHTML = styleHTML();
      bindStyle(v);
    },
    options(btn) {
      openPop(btn, `<div id="oS">${styleOptions()}</div>`, (p) => bindOpts($("#oS", p), sState, () => store.set("style", sState)));
    }
  };
  const VIEWS = { create: Create, layers: Layers, style: Style, curves: Curves, beat: Beat, captions: Captions };
  const DEFAULT_KEY = { key: "K", code: "KeyK", ctrl: !IS_MAC, meta: IS_MAC, shift: false, alt: false };
  let hotkey = store.get("hotkey", DEFAULT_KEY);
  const keyLabel = (k) => [k.ctrl && (IS_MAC ? "\u2303" : "Ctrl"), k.alt && (IS_MAC ? "\u2325" : "Alt"), k.shift && (IS_MAC ? "\u21E7" : "Shift"), k.meta && (IS_MAC ? "\u2318" : "Win"), k.key === " " ? "Space" : k.key].filter(Boolean).join(IS_MAC ? "" : "+");
  const MAC_CODES = { A: 0, S: 1, D: 2, F: 3, H: 4, G: 5, Z: 6, X: 7, C: 8, V: 9, B: 11, Q: 12, W: 13, E: 14, R: 15, Y: 16, T: 17, 1: 18, 2: 19, 3: 20, 4: 21, 6: 22, 5: 23, 9: 25, 7: 26, 8: 28, 0: 29, O: 31, U: 32, I: 34, P: 35, L: 37, J: 38, K: 40, N: 45, M: 46, " ": 49 };
  function registerHotkey() {
    if (!CEP || !window.__adobe_cep__.registerKeyEventsInterest) return;
    const k = hotkey, code = IS_MAC ? MAC_CODES[k.key.toUpperCase()] : k.key === " " ? 32 : k.key.toUpperCase().charCodeAt(0);
    if (code == null) return;
    const ev = { keyCode: code, ctrlKey: !!k.ctrl, altKey: !!k.alt, shiftKey: !!k.shift, metaKey: !!k.meta };
    window.__adobe_cep__.registerKeyEventsInterest(JSON.stringify([ev, { keyCode: IS_MAC ? 53 : 27 }, { keyCode: IS_MAC ? 125 : 40 }, { keyCode: IS_MAC ? 126 : 38 }, { keyCode: IS_MAC ? 36 : 13 }]));
  }
  const matches = (e, k) => e.key.toUpperCase() === k.key.toUpperCase() && !!e.ctrlKey === !!k.ctrl && !!e.metaKey === !!k.meta && !!e.shiftKey === !!k.shift && !!e.altKey === !!k.alt;
  function commands() {
    const c = [];
    CREATE.forEach(([k, n]) => c.push({ id: "create:" + k, g: "Create", n: `New ${n === "Adjust" ? "adjustment" : n.toLowerCase()} layer`, i: ICON[k], run: () => doCreate(k) }));
    ANCHORS.forEach(([x, y, n]) => c.push({ id: `anchor:${x},${y}`, g: "Anchor", n: `Anchor ${n}`, i: ICON.anchor, run: () => doAnchor(x, y) }));
    c.push({ id: "precomp", g: "Layers", n: "Precompose", i: ICON.precomp, run: () => doPrecomp() });
    c.push({ id: "decomp", g: "Layers", n: "Decompose precomp", i: ICON.decomp, run: () => doDecomp() });
    c.push({ id: "rename:selected", g: "Layers", n: "Rename selected layers", i: ICON.rename, run: () => doRename(null, "selected") });
    c.push({ id: "rename:all", g: "Layers", n: "Rename all layers", i: ICON.rename, run: () => doRename(null, "all") });
    c.push({ id: "copy", g: "Style", n: "Copy style", i: ICON.copy, run: () => doCopy() });
    c.push({ id: "paste", g: "Style", n: "Paste style", i: ICON.paste, run: () => doPaste() });
    c.push({ id: "paste:fit", g: "Style", n: "Paste style, animation fitted to clip", i: ICON.fit, run: () => doPaste(null, "fit") });
    c.push({ id: "dupcomp", g: "Layers", n: "Duplicate precomp (independent)", i: ICON.dup, run: () => doDuplicate() });
    c.push({ id: "invert", g: "Layers", n: "Invert sequence order", i: ICON.invert, run: () => doInvert() });
    c.push({ id: "solid", g: "Create", n: "New solid (pick a color)", i: ICON.solid, run: () => {
      go("create");
      setTimeout(() => solidPicker($('.ct [data-k="solid"]')), 60);
    } });
    c.push({ id: "sequence", g: "Layers", n: "Sequence selected clips", i: ICON.seq, run: () => doSequence() });
    c.push({ id: "beat:find", g: "Beat", n: "Find beats in selected layer", i: ICON.beat, run: () => {
      go("beat");
      setTimeout(analyze, 50);
    } });
    c.push({ id: "beat:snap", g: "Beat", n: "Snap layers to beats", i: ICON.snap, run: () => doSnap("snap") });
    c.push({ id: "beat:sequence", g: "Beat", n: "Sequence layers on beats", i: ICON.seq, run: () => doSnap("sequence") });
    c.push({ id: "beat:cut", g: "Beat", n: "Cut selected clips on the beats", i: ICON.cut, run: () => doCut() });
    c.push({ id: "captions", g: "Captions", n: "Auto captions (speech to text)", i: ICON.captions, run: () => {
      go("captions");
      setTimeout(() => autoCaptions($("#capGo")), 60);
    } });
    SPLITS.forEach(([k, n]) => c.push({ id: "split:" + k, g: "Text", n: `Split text into ${n.toLowerCase()}`, i: ICON.split, run: () => doSplit(null, k) }));
    store.get("curves", []).forEach((cv) => c.push({ id: "curve:" + cv.name, g: "Curve", n: cv.name, i: ICON.curves, run: () => applyCurve(cv.name, cv.b) }));
    PRESETS.forEach(([n, b]) => c.push({ id: "curve:" + n, g: "Curve", n, i: ICON.curves, run: () => applyCurve(n, b) }));
    tabList().forEach(([k, n]) => c.push({ id: "go:" + k, g: "Go to", n, i: ICON[k], run: () => go(k) }));
    c.push({ id: "guide", g: "Help", n: "Show the quick guide", i: ICON.search, run: () => showGuide(0) });
    return c;
  }
  function score(q, s) {
    if (!q) return 1;
    s = s.toLowerCase();
    q = q.toLowerCase();
    const at = s.indexOf(q);
    if (at === 0) return 100;
    if (at > 0) return 80 - at;
    let i = 0;
    for (const ch of s) if (ch === q[i]) i++;
    return i === q.length ? 20 : 0;
  }
  const hl = (s, q) => {
    if (!q) return esc(s);
    const at = s.toLowerCase().indexOf(q.toLowerCase());
    return at < 0 ? esc(s) : esc(s.slice(0, at)) + `<mark>${esc(s.slice(at, at + q.length))}</mark>` + esc(s.slice(at + q.length));
  };
  let palItems = [], palSel = 0, palRecent = 0;
  function openPal() {
    closePop();
    $("#pal").hidden = false;
    $("#palQ").value = "";
    $("#palKey").textContent = keyLabel(hotkey);
    listPal();
    setTimeout(() => $("#palQ").focus(), 0);
  }
  const closePal = () => {
    $("#pal").hidden = true;
  };
  function listPal() {
    const q = $("#palQ").value.trim();
    const all = commands();
    palItems = all.map((c) => ({ ...c, s: score(q, c.n) + (c.low ? -5 : 0) })).filter((c) => c.s > 0 && (q || !c.low)).sort((a, b) => b.s - a.s).slice(0, 40);
    palRecent = 0;
    if (!q) {
      const rec = store.get("recent", []).map((id) => all.find((c) => c.id === id)).filter(Boolean);
      palItems = [...rec, ...palItems.filter((c) => !rec.includes(c) && !rec.some((r) => r.id === c.id))];
      palRecent = rec.length;
    }
    palSel = 0;
    drawPal(q);
  }
  function drawPal(q = $("#palQ").value.trim()) {
    var _a;
    const head = (i) => palRecent && !q ? i === 0 ? '<div class="pal-h cap">Recent</div>' : i === palRecent ? '<div class="pal-h cap">All actions</div>' : "" : "";
    $("#palList").innerHTML = palItems.length ? palItems.map((c, i) => `${head(i)}<div class="pi ${i === palSel ? "sel" : ""}" data-i="${i}">${c.i}<span class="nm">${hl(c.n, q)}</span><span class="grp">${c.g}</span></div>`).join("") : '<div class="pal-empty">No action found</div>';
    $$(".pi").forEach((el) => {
      el.addEventListener("mousemove", () => {
        if (palSel !== Number(el.dataset.i)) {
          palSel = Number(el.dataset.i);
          drawPal();
        }
      });
      el.addEventListener("click", () => runPal(Number(el.dataset.i)));
    });
    (_a = $(".pi.sel")) == null ? void 0 : _a.scrollIntoView({ block: "nearest" });
  }
  function runPal(i) {
    const c = palItems[i];
    if (!c) return;
    closePal();
    if (!ctx.comp && c.g !== "Go to" && c.g !== "Help") return status(ERR.NO_COMP, "err");
    c.run();
  }
  $("#palQ").addEventListener("input", listPal);
  $("#palQ").addEventListener("keydown", (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      palSel = Math.min(palItems.length - 1, palSel + 1);
      drawPal();
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      palSel = Math.max(0, palSel - 1);
      drawPal();
    } else if (e.key === "Enter") {
      e.preventDefault();
      runPal(palSel);
    } else if (e.key === "Escape") {
      e.preventDefault();
      closePal();
    }
  });
  $("#pal").addEventListener("mousedown", (e) => {
    if (e.target.id === "pal") closePal();
  });
  let recording = false;
  function openMenu(btn) {
    openPop(btn, `<div class="ph cap">Search shortcut</div>
      <div class="opt" id="mKeyRow"><span class="k">Open the search</span><kbd id="mKey">${esc(keyLabel(hotkey))}</kbd></div>
      <div class="opt" id="mKeyReset"><span class="k" style="color:var(--muted)">Reset to ${esc(keyLabel(DEFAULT_KEY))}</span></div>
      <div class="ph" style="color:var(--dim);font-size:10px;padding-top:0">The shortcut works while the panel is focused.</div>
      <hr><div class="ph cap">Icon size</div>
      <div class="sizes">${[["s", "Small"], ["m", "Medium"], ["l", "Large"]].map(([k, n]) => `<button data-size="${k}" class="${uiSize === k ? "on" : ""}">${n}</button>`).join("")}</div>
      ${update ? `<hr><div class="opt" id="mUpd"><span class="k"><b style="color:var(--on)">Version ${esc(update.version)} is out</b><small>Click to download it, then run the installer again</small></span><span style="color:var(--dim)">\u2197</span></div>` : ""}
      <hr><div class="opt" id="mGuide"><span class="k">Quick guide</span></div>
      <div class="opt" id="mSite"><span class="k">Nothi Labs</span><span style="color:var(--dim)">\u2197</span></div>
      <div class="ph" style="color:var(--dim);font-size:10px">Nothi Toolkit ${VERSION} \xB7 free</div>`, (p) => {
      var _a;
      $("#mGuide", p).addEventListener("click", () => {
        closePop();
        showGuide(0);
      });
      $$("[data-size]", p).forEach((b) => b.addEventListener("click", () => {
        setSize(b.dataset.size);
        $$("[data-size]", p).forEach((x) => x.classList.toggle("on", x === b));
      }));
      (_a = $("#mUpd", p)) == null ? void 0 : _a.addEventListener("click", openUpdate);
      $("#mKeyRow", p).addEventListener("click", () => {
        recording = true;
        const k = $("#mKey", p);
        k.textContent = "Press keys\u2026";
        k.classList.add("rec");
      });
      $("#mKeyReset", p).addEventListener("click", () => {
        hotkey = { ...DEFAULT_KEY };
        store.set("hotkey", hotkey);
        registerHotkey();
        $("#mKey", p).textContent = keyLabel(hotkey);
        status(`Search shortcut: ${keyLabel(hotkey)}`);
      });
      $("#mSite", p).addEventListener("click", () => openURL(SITE));
    });
  }
  document.addEventListener("keydown", (e) => {
    if (recording) {
      e.preventDefault();
      if (["Control", "Shift", "Alt", "Meta"].includes(e.key)) return;
      if (e.key === "Escape") {
        recording = false;
        $("#mKey") && ($("#mKey").textContent = keyLabel(hotkey));
        return;
      }
      const k = { key: e.key.length === 1 ? e.key.toUpperCase() : e.key, code: e.code, ctrl: e.ctrlKey, meta: e.metaKey, shift: e.shiftKey, alt: e.altKey };
      if (!k.ctrl && !k.meta && !k.alt && !/^F\d+$/.test(k.key)) {
        const el2 = $("#mKey");
        if (el2) el2.textContent = "Add Ctrl, Alt or \u2318";
        return;
      }
      hotkey = k;
      store.set("hotkey", k);
      registerHotkey();
      recording = false;
      const el = $("#mKey");
      if (el) {
        el.textContent = keyLabel(k);
        el.classList.remove("rec");
      }
      status(`Search shortcut: ${keyLabel(k)}`);
      return;
    }
    if (matches(e, hotkey)) {
      e.preventDefault();
      if ($("#pal").hidden) openPal();
      else closePal();
    } else if (e.key === "Escape") {
      closePop();
      closePal();
      hideGuide();
    }
  });
  let uiSize = store.get("size", "m");
  function setSize(k) {
    uiSize = k;
    store.set("size", k);
    document.body.classList.remove("sz-s", "sz-l");
    if (k !== "m") document.body.classList.add("sz-" + k);
    if (current === "beat" && beat) requestAnimationFrame(drawBeat);
  }
  const openURL = (u) => {
    if (CEP && window.cep && window.cep.util) window.cep.util.openURLInDefaultBrowser(u);
    else window.open(u, "_blank");
  };
  let update = null;
  const newer = (a, b) => {
    const x = String(a).split(".").map(Number), y = String(b).split(".").map(Number);
    for (let i = 0; i < 3; i++) {
      if ((x[i] || 0) > (y[i] || 0)) return true;
      if ((x[i] || 0) < (y[i] || 0)) return false;
    }
    return false;
  };
  const httpsGet = (u, headers, cb) => require("https").get(Object.assign(require("url").parse(u), { headers }), cb);
  function getJSON(url) {
    if (CEP && typeof require === "function") {
      return new Promise((resolve, reject) => {
        httpsGet(url, { "Cache-Control": "no-cache" }, (res) => {
          if (res.statusCode !== 200) {
            res.resume();
            return reject(new Error("HTTP " + res.statusCode));
          }
          let d = "";
          res.setEncoding("utf8");
          res.on("data", (c) => {
            d += c;
          });
          res.on("end", () => {
            try {
              resolve(JSON.parse(d));
            } catch (e) {
              reject(e);
            }
          });
        }).on("error", reject);
      });
    }
    return fetch(url, { cache: "no-store" }).then((r) => r.ok ? r.json() : Promise.reject(new Error("HTTP " + r.status)));
  }
  function showUpdate(info) {
    update = info;
    const b = $("#stUpd");
    b.hidden = false;
    b.textContent = `Update ${info.version}`;
    b.dataset.tip = `Version ${info.version} is out \xB7 ${info.notes ? info.notes + " " : ""}Click to download it, then run the installer again. Your settings stay.`;
  }
  const openUpdate = () => {
    openURL(`${SITE}/get/${IS_MAC ? "mac" : "windows"}${LEGACY ? "-legacy" : ""}.html?from=panel`);
    status(`Downloading Nothi Toolkit ${update ? update.version : ""} \xB7 Close After Effects, then run the installer in the zip`);
  };
  async function checkUpdate() {
    const last = store.get("updCheck", { t: 0, info: null });
    if (last.site) SITE = last.site;
    if (Date.now() - last.t < 6 * 36e5) {
      if (last.info && newer(last.info.version, VERSION)) showUpdate(last.info);
      return;
    }
    try {
      let info = null;
      for (const base of SITES) {
        try {
          info = await getJSON(base + "/updates/toolkit.json");
          SITE = base;
          break;
        } catch (e) {
        }
      }
      if (!info) return;
      store.set("updCheck", { t: Date.now(), info, site: SITE });
      if (info && info.version && newer(info.version, VERSION)) showUpdate(info);
    } catch (e) {
    }
  }
  const GUIDE = () => [
    { i: '<i class="logo" style="width:22px;height:17px;margin:0"></i>', h: "A panel that fits its window", p: "In a tall window, Create holds everything for layers. In a small one, Layers and Copy style get their own tabs. Hover anything to see what it does." },
    { i: ICON.search, h: "Search every action", p: `Press <kbd>${esc(keyLabel(hotkey))}</kbd> while the panel is focused, type a few letters, hit Enter. You can change the shortcut in the \xB7\xB7\xB7 menu.` },
    { i: ICON.undo, h: "Options and undo", p: 'The sliders icon holds each tool\u2019s options. After every action, <b style="color:var(--text)">Undo</b> appears at the bottom, and Ctrl/Cmd+Z works as usual.' }
  ];
  let guideAt = -1;
  function showGuide(i) {
    const steps = GUIDE(), st = steps[i], g = $("#guide");
    guideAt = i;
    g.hidden = false;
    g.innerHTML = `<div class="guide-box"><div class="guide-step"><span>${i + 1} / ${steps.length}</span><span class="guide-dots">${steps.map((_, j) => `<i class="${j === i ? "on" : ""}"></i>`).join("")}</span></div>
      <div class="gi">${st.i}</div><h3>${st.h}</h3><p>${st.p}</p>
      <div class="guide-nav"><button class="skip" id="gSkip">${i === steps.length - 1 ? "" : "Skip"}</button><button class="b main" id="gNext">${i === steps.length - 1 ? "Start" : "Next"}</button></div></div>`;
    $("#gSkip", g).addEventListener("click", hideGuide);
    $("#gNext", g).addEventListener("click", () => i < steps.length - 1 ? showGuide(i + 1) : hideGuide());
    setTimeout(() => {
      var _a;
      return (_a = $("#gNext", g)) == null ? void 0 : _a.focus();
    }, 0);
  }
  function hideGuide() {
    if (guideAt < 0) return;
    guideAt = -1;
    $("#guide").hidden = true;
    store.set("guided", true);
  }
  $("#guide").addEventListener("mousedown", (e) => {
    if (e.target.id === "guide") hideGuide();
  });
  const tip = $("#tip");
  let tipEl = null, tipTimer = 0;
  document.addEventListener("mouseover", (e) => {
    const el = e.target.closest("[title],[data-tip]");
    if (el === tipEl) return;
    clearTimeout(tipTimer);
    tip.classList.remove("show");
    tipEl = el;
    if (!el) return;
    if (el.hasAttribute("title")) {
      el.dataset.tip = el.getAttribute("title");
      el.removeAttribute("title");
    }
    tipTimer = setTimeout(() => {
      if (!document.contains(el) || !$("#pal").hidden) return;
      const [h, ...rest] = el.dataset.tip.split(" \xB7 ");
      tip.innerHTML = `<b>${esc(h)}</b>${rest.length ? `<small>${esc(rest.join(" \xB7 "))}</small>` : ""}`;
      const r = el.getBoundingClientRect(), tw = tip.offsetWidth, th = tip.offsetHeight;
      let x = Math.min(innerWidth - tw - 4, Math.max(4, r.left + r.width / 2 - tw / 2));
      let y = r.bottom + 6;
      if (y + th > innerHeight - 4) y = r.top - th - 6;
      tip.style.left = `${x}px`;
      tip.style.top = `${Math.max(4, y)}px`;
      tip.classList.add("show");
    }, 550);
  });
  document.addEventListener("mousedown", () => {
    clearTimeout(tipTimer);
    tip.classList.remove("show");
  });
  document.addEventListener("mouseleave", () => {
    clearTimeout(tipTimer);
    tip.classList.remove("show");
    tipEl = null;
  });
  function MOCK(fn, args) {
    const ok = (o = {}) => ({ ok: true, ...o });
    switch (fn) {
      case "nt_context":
        return ok({ comp: "Edit_Final", w: 1920, h: 1080, fps: 30, selected: 2, aud: { i: 1, n: "Phonk_Edit.wav", id: 7, a: 1.5, b: 10.5 } });
      case "nt_create":
        return ok({ name: args[1] && args[1].name || { text: "Your text", adjustment: "Adjustment Layer", solid: "Solid", null: "Control", shape: "Shape", camera: "Camera", light: "Light" }[args[0]] });
      case "nt_curveRead":
        return ok({ curve: { outInf: 82, inInf: 64, outRatio: 0, inRatio: 0 } });
      case "nt_curveApply":
        return ok({ count: 3 });
      case "nt_audioInfo":
        return ok({ path: "demo.wav", sourceId: 7, name: "Phonk_Edit.wav", index: 1, startTime: 0, inPoint: 1.5, outPoint: 10.5, stretch: 100, workStart: 2, workEnd: 8 });
      case "nt_beatMarkers":
        return ok({ count: args[1].length });
      case "nt_clearMarkers":
        return ok({ count: 0 });
      case "nt_anchor":
        return ok({ count: 2, skipped: 0 });
      case "nt_precompose":
        return ok({ name: "Clip 04 +1" });
      case "nt_decompose":
        return ok({ name: "Intro", count: 5, lost: [], deleted: false });
      case "nt_rename":
        return ok({ count: 8 });
      case "nt_styleCopy":
        return ok({ layer: "Title Glow", effects: ["Glow", "Gaussian Blur", "Fill", "Turbulent Displace"], keys: 6, duration: 2 });
      case "nt_stylePaste":
        return ok({ count: 3, fitted: args[0].timing === "fit" && args[0].keys ? 3 : 0 });
      case "nt_sequence":
        return ok({ count: 4 });
      case "nt_dupPrecomp":
        return ok({ count: 1, names: ["Intro copy"], comps: 2 });
      case "nt_listEffects":
        return ok({ effects: [["Gaussian Blur", "ADBE Gaussian Blur 2", "Blur & Sharpen"], ["Camera Lens Blur", "ADBE Camera Lens Blur", "Blur & Sharpen"], ["Glow", "ADBE Glo2", "Stylize"], ["Gradient Ramp", "ADBE Ramp", "Generate"], ["Fractal Noise", "ADBE Fractal Noise", "Noise & Grain"], ["Wave Warp", "ADBE Wave Warp", "Distort"], ["CC Light Rays", "CC Light Rays", "Generate"]].map(([n, m, c]) => ({ n, m, c })) });
      case "nt_applyEffect":
        return ok({ count: 2, adjustment: !!args[2] });
      case "nt_snapLayers":
        return ok({ count: 3 });
      case "nt_splitAt":
        return ok({ count: 7, layers: 2 });
      case "nt_splitText":
        return ok({ count: 5, layers: 1, boxes: 0 });
      case "nt_captions":
        return ok({ count: args[0].length, template: null });
      default:
        return ok();
    }
  }
  $("#btnSearch").innerHTML = ICON.search;
  $("#btnTabSettings").innerHTML = ICON.sliders;
  $("#btnMenu").innerHTML = ICON.menu;
  $("#palIcon").innerHTML = ICON.search;
  $("#btnSearch").title = `Search \xB7 Every action of the toolkit (${keyLabel(hotkey)})`;
  $("#btnTabSettings").title = "Options \xB7 Settings of the current tool";
  $("#btnMenu").title = "Toolkit \xB7 Shortcut, quick guide, website";
  $("#stUndo").addEventListener("click", async () => {
    const r = await host("nt_undo");
    $("#stUndo").hidden = true;
    status(r.ok ? "Undone" : "Nothing to undo", r.ok ? "done" : "err");
  });
  $("#btnSearch").addEventListener("click", openPal);
  $("#btnTabSettings").addEventListener("click", (e) => {
    const o = VIEWS[current].options;
    if (o) o(e.currentTarget);
    else status("No options for this tool");
  });
  $("#btnMenu").addEventListener("click", (e) => openMenu(e.currentTarget));
  setSize(uiSize);
  $("#stUpd").addEventListener("click", openUpdate);
  full = fitsAll();
  if (full && (current === "layers" || current === "style")) current = "create";
  renderTabs();
  render();
  registerHotkey();
  setTimeout(checkUpdate, 2500);
  if (!store.get("guided", false) && !/noguide/.test(location.search)) setTimeout(() => showGuide(0), 400);
  poll();
  setInterval(poll, 1500);
  window.__nothi = { go, openPal, analyze, status, setSize, showUpdate, showGuide, hideGuide, play, stop, doSnap, openOptions: () => $("#btnTabSettings").click(), openMenu: () => $("#btnMenu").click() };
})();
