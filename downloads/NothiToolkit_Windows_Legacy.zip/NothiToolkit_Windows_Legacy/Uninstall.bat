@echo off
rmdir /s /q "%APPDATA%\Adobe\CEP\extensions\com.nothi.toolkit"
echo Nothi Toolkit removed.
pause
