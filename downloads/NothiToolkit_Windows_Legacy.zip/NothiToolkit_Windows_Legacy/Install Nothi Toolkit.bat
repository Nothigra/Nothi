@echo off
setlocal
title Nothi Toolkit installer
echo Installing Nothi Toolkit...
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.nothi.toolkit"
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%~dp0com.nothi.toolkit" "%DEST%\" /e /i /q /y >nul
if errorlevel 1 (echo. & echo Something went wrong. Did you extract the zip first? & pause & exit /b 1)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:APPDATA\Adobe\CEP\extensions\com.nothi.toolkit -Recurse | Unblock-File" >nul 2>&1
echo.
echo Done. Restart After Effects, then open Window ^> Extensions ^> Nothi Toolkit
echo.
pause
